import { API_ENDPOINTS } from "@/config/api";

export interface RemoteFittingData {
  id: string;
  date: string;
  puttingStyle: string;
  putterType: string;
  length: string;
  lie: string;
  loft: string;
  purchased: boolean;
  timeToPurchase: number | null;
  customerEmail: string;
  // Additional fields from CSV data
  firstName?: string;
  lastName?: string;
  playerHeight?: string;
  reviewStatus?: string;
  status?: string;
  orderId?: string;
  video?: string;
  shopifyCustomerId?: string;
}

export interface DataSource {
  _id: string;
  name: string;
  type: string;
  status: 'connected' | 'disconnected' | 'error' | 'pending';
  metadata?: {
    lastUpdated?: string;
    totalRecords?: number;
  };
}

export interface CSVFile {
  id: string;
  name: string;
  type: string;
  size: number;
  lastModified: string;
  path: string;
}

export interface CSVData {
  filename: string;
  headers: string[];
  data: any[];
  totalRows: number;
}

export interface RemoteFittingResponse {
  data: RemoteFittingData[];
  pagination: {
    page: number;
    limit: number;
    totalRecords: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

export const fetchRemoteFittingCombinedData = async (page: number = 1, limit: number = 1000): Promise<RemoteFittingResponse> => {
  try {
    const response = await fetch(`/api/remote-fitting/combined?page=${page}&limit=${limit}`);
    if (!response.ok) {
      throw new Error('Failed to fetch combined fitting data');
    }
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('❌ Error fetching combined fitting data:', error);
    throw new Error('Failed to fetch combined fitting data');
  }
};
