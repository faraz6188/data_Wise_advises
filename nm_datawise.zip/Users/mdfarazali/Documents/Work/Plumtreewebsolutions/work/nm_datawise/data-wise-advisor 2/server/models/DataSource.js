import mongoose from 'mongoose';

const dataSourceSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  name: {
    type: String,
    required: [true, 'Data source name is required'],
    trim: true
  },
  type: {
    type: String,
    required: [true, 'Data source type is required'],
    enum: ['shopify', 'bigcommerce', 'google_analytics', 'meta_ads', 'klaviyo', 'custom'],
    lowercase: true
  },
  status: {
    type: String,
    enum: ['connected', 'disconnected', 'error', 'pending'],
    default: 'pending'
  },
  credentials: {
    // Shopify
    shopifyDomain: String,
    shopifyAccessToken: String,
    shopifyApiKey: String,
    shopifyApiSecret: String,
    
    // BigCommerce
    bigcommerceStoreHash: String,
    bigcommerceAccessToken: String,
    bigcommerceClientId: String,
    bigcommerceClientSecret: String,
    
    // Google Analytics
    gaPropertyId: String,
    gaClientId: String,
    gaClientSecret: String,
    gaRefreshToken: String,
    gaAccessToken: String,
    
    // Meta Ads
    metaAccessToken: String,
    metaAppId: String,
    metaAppSecret: String,
    metaAdAccountId: String,
    
    // Klaviyo
    klaviyoApiKey: String,
    klaviyoPublicKey: String,
    
    // Custom
    apiUrl: String,
    apiKey: String,
    headers: mongoose.Schema.Types.Mixed,
    authType: {
      type: String,
      enum: ['api_key', 'bearer_token', 'basic_auth', 'oauth2'],
      default: 'api_key'
    }
  },
  settings: {
    syncFrequency: {
      type: String,
      enum: ['real_time', 'hourly', 'daily', 'weekly'],
      default: 'daily'
    },
    autoSync: {
      type: Boolean,
      default: true
    },
    dataTypes: [{
      type: String,
      // For Shopify: orders, products, customers, analytics
      // For GA: traffic, conversions, demographics
      // For Meta: campaigns, ads, insights
      // For Klaviyo: campaigns, flows, profiles
    }]
  },
  metadata: {
    lastSyncAt: Date,
    lastSyncStatus: String,
    lastSyncError: String,
    totalRecords: {
      type: Number,
      default: 0
    },
    dataRange: {
      startDate: Date,
      endDate: Date
    }
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

// Index for better query performance
dataSourceSchema.index({ user: 1, type: 1 });
dataSourceSchema.index({ user: 1, status: 1 });
dataSourceSchema.index({ user: 1, isActive: 1 });

// Virtual for connection health
dataSourceSchema.virtual('isHealthy').get(function() {
  if (this.status === 'connected' && this.metadata.lastSyncAt) {
    const hoursSinceLastSync = (Date.now() - this.metadata.lastSyncAt.getTime()) / (1000 * 60 * 60);
    return hoursSinceLastSync <= 24; // Consider healthy if synced within 24 hours
  }
  return false;
});

// Method to test connection
dataSourceSchema.methods.testConnection = async function() {
  try {
    let isValid = false;
    
    switch (this.type) {
      case 'shopify':
        if (this.credentials.shopifyDomain && this.credentials.shopifyAccessToken) {
          // Test Shopify connection
          const fetch = (await import('node-fetch')).default;
          const response = await fetch(
            `https://${this.credentials.shopifyDomain}/admin/api/2023-10/shop.json`,
            {
              headers: {
                'X-Shopify-Access-Token': this.credentials.shopifyAccessToken
              }
            }
          );
          isValid = response.ok;
        }
        break;
        
      case 'bigcommerce':
        if (this.credentials.bigcommerceStoreHash && this.credentials.bigcommerceAccessToken) {
          // Test BigCommerce connection
          const fetch = (await import('node-fetch')).default;
          const response = await fetch(
            `https://api.bigcommerce.com/stores/${this.credentials.bigcommerceStoreHash}/v2/store`,
            {
              headers: {
                'X-Auth-Token': this.credentials.bigcommerceAccessToken,
                'Accept': 'application/json'
              }
            }
          );
          isValid = response.ok;
        }
        break;
        
      case 'google_analytics':
        // Test GA connection (simplified)
        isValid = !!(this.credentials.gaPropertyId && this.credentials.gaAccessToken);
        break;
        
      case 'meta_ads':
        // Test Meta connection (simplified)
        isValid = !!(this.credentials.metaAccessToken && this.credentials.metaAdAccountId);
        break;
        
      case 'klaviyo':
        // Test Klaviyo connection (simplified)
        isValid = !!this.credentials.klaviyoApiKey;
        break;
        
      case 'custom':
        // Test custom API connection
        if (this.credentials.apiUrl) {
          const fetch = (await import('node-fetch')).default;
          const headers = { ...this.credentials.headers };
          
          if (this.credentials.authType === 'api_key' && this.credentials.apiKey) {
            headers['Authorization'] = `Bearer ${this.credentials.apiKey}`;
          }
          
          const response = await fetch(this.credentials.apiUrl, { headers });
          isValid = response.ok;
        }
        break;
    }
    
    this.status = isValid ? 'connected' : 'error';
    this.metadata.lastSyncAt = new Date();
    this.metadata.lastSyncStatus = isValid ? 'success' : 'failed';
    
    if (!isValid) {
      this.metadata.lastSyncError = 'Connection test failed';
    }
    
    await this.save();
    return isValid;
    
  } catch (error) {
    this.status = 'error';
    this.metadata.lastSyncError = error.message;
    await this.save();
    return false;
  }
};

// Method to get required fields for a data source type
dataSourceSchema.statics.getRequiredFields = function(type) {
  const fieldMappings = {
    shopify: [
      { name: 'shopifyDomain', label: 'Shopify Domain', type: 'text', placeholder: 'your-store.myshopify.com', required: true },
      { name: 'shopifyAccessToken', label: 'Access Token', type: 'password', placeholder: 'shpat_...', required: true },
      { name: 'shopifyApiKey', label: 'API Key', type: 'text', placeholder: 'Your API Key', required: false },
      { name: 'shopifyApiSecret', label: 'API Secret', type: 'password', placeholder: 'Your API Secret', required: false }
    ],
    bigcommerce: [
      { name: 'bigcommerceStoreHash', label: 'Store Hash', type: 'text', placeholder: 'abc123def', required: true },
      { name: 'bigcommerceAccessToken', label: 'Access Token', type: 'password', placeholder: 'Your Access Token', required: true },
      { name: 'bigcommerceClientId', label: 'Client ID', type: 'text', placeholder: 'Your Client ID', required: false },
      { name: 'bigcommerceClientSecret', label: 'Client Secret', type: 'password', placeholder: 'Your Client Secret', required: false }
    ],
    google_analytics: [
      { name: 'gaPropertyId', label: 'Property ID', type: 'text', placeholder: 'GA4 Property ID', required: true },
      { name: 'gaClientId', label: 'Client ID', type: 'text', placeholder: 'OAuth Client ID', required: true },
      { name: 'gaClientSecret', label: 'Client Secret', type: 'password', placeholder: 'OAuth Client Secret', required: true },
      { name: 'gaAccessToken', label: 'Access Token', type: 'password', placeholder: 'OAuth Access Token', required: true }
    ],
    meta_ads: [
      { name: 'metaAccessToken', label: 'Access Token', type: 'password', placeholder: 'Meta Access Token', required: true },
      { name: 'metaAppId', label: 'App ID', type: 'text', placeholder: 'Meta App ID', required: true },
      { name: 'metaAdAccountId', label: 'Ad Account ID', type: 'text', placeholder: 'act_...', required: true },
      { name: 'metaAppSecret', label: 'App Secret', type: 'password', placeholder: 'Meta App Secret', required: false }
    ],
    klaviyo: [
      { name: 'klaviyoApiKey', label: 'Private API Key', type: 'password', placeholder: 'pk_...', required: true },
      { name: 'klaviyoPublicKey', label: 'Public API Key', type: 'text', placeholder: 'Public API Key', required: false }
    ],
    custom: [
      { name: 'apiUrl', label: 'API URL', type: 'url', placeholder: 'https://api.example.com', required: true },
      { name: 'apiKey', label: 'API Key', type: 'password', placeholder: 'Your API Key', required: false },
      { name: 'authType', label: 'Auth Type', type: 'select', options: ['api_key', 'bearer_token', 'basic_auth'], required: true }
    ]
  };
  
  return fieldMappings[type] || [];
};

// Transform output (remove sensitive fields)
dataSourceSchema.methods.toJSON = function() {
  const dataSourceObject = this.toObject();
  
  // Remove sensitive credential fields
  if (dataSourceObject.credentials) {
    Object.keys(dataSourceObject.credentials).forEach(key => {
      if (key.includes('Token') || key.includes('Secret') || key.includes('Key')) {
        if (dataSourceObject.credentials[key]) {
          // Show only first 4 and last 4 characters
          const value = dataSourceObject.credentials[key];
          if (value.length > 8) {
            dataSourceObject.credentials[key] = `${value.slice(0, 4)}...${value.slice(-4)}`;
          } else {
            dataSourceObject.credentials[key] = '***';
          }
        }
      }
    });
  }
  
  return dataSourceObject;
};

const DataSource = mongoose.model('DataSource', dataSourceSchema);

export default DataSource; 