import React, { useEffect, useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { RefreshCw, AlertCircle, Settings } from "lucide-react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/AppLayout";
import StatCard from "@/components/dashboard/StatCard";
import AiInsightCard from "@/components/dashboard/AiInsightCard";
import FileUploadCard from "@/components/dashboard/FileUploadCard";
import DocumentsList from "@/components/dashboard/DocumentsList";
import QuickActions from "@/components/dashboard/QuickActions";
import DataSourceSelector from "@/components/ui/data-source-selector";
import axios from "axios";
import { ChartContainer } from "@/components/ui/chart";
import * as RechartsPrimitive from "recharts";

const TIME_RANGES_OPTIONS = [
  { label: "MTD", value: "mtd", fullLabel: "Month to Date" },
  { label: "YTD", value: "ytd", fullLabel: "Year to Date" },
  { label: "3M", value: "3m", fullLabel: "Last 3 Months" },
  { label: "6M", value: "6m", fullLabel: "Last 6 Months" },
  { label: "12M", value: "12m", fullLabel: "Last 12 Months" },
  { label: "Custom", value: "custom", fullLabel: "Custom Range" },
];

function getDateRange(rangeValue) {
  const today = new Date();
  let start, end;
  end = new Date(today);
  end.setHours(23, 59, 59, 999);

  const startOfToday = new Date(today);
  startOfToday.setHours(0, 0, 0, 0);

  switch (rangeValue) {
    case "mtd":
      start = new Date(today.getFullYear(), today.getMonth(), 1);
      start.setHours(0, 0, 0, 0);
      break;
    case "ytd":
      start = new Date(today.getFullYear(), 0, 1);
      start.setHours(0, 0, 0, 0);
      break;
    case "3m":
      start = new Date(today);
      start.setMonth(today.getMonth() - 3);
      start.setDate(today.getDate() + 1);
      start.setHours(0, 0, 0, 0);
      break;
    case "6m":
      start = new Date(today);
      start.setMonth(today.getMonth() - 6);
      start.setDate(today.getDate() + 1);
      start.setHours(0, 0, 0, 0);
      break;
    case "12m":
      start = new Date(today);
      start.setFullYear(today.getFullYear() - 1);
      start.setDate(today.getDate() + 1);
      start.setHours(0, 0, 0, 0);
      break;
    case "custom":
      return { start: "", end: "" };
    default:
      start = new Date(today.getFullYear(), today.getMonth(), 1);
      start.setHours(0, 0, 0, 0);
  }

  if (start > today) {
      start = startOfToday;
  }

  return {
    start: start.toISOString().slice(0, 10),
    end: end.toISOString().slice(0, 10),
  };
}

const Dashboard = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [selectedDataSource, setSelectedDataSource] = useState(null);
  const [stats, setStats] = useState(null);
  const [timeRange, setTimeRange] = useState("mtd");
  const [customRange, setCustomRange] = useState({ start: "", end: "" });
  const statsCache = useRef({}); // { [key: string]: stats }

  const fetchEcommerceStats = async () => {
    if (!selectedDataSource) {
      setStats(null);
      return;
    }
    
    let start, end;
    if (timeRange === "custom") {
      start = customRange.start;
      end = customRange.end;
    } else {
      const range = getDateRange(timeRange);
      start = range.start;
      end = range.end;
    }
    const cacheKey = `${selectedDataSource._id}:${start}:${end}`;
    if (statsCache.current[cacheKey]) {
      setStats(statsCache.current[cacheKey]);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError("");
    try {
      const response = await axios.get(`/api/ecommerce/metrics/${selectedDataSource._id}`, {
        params: { start, end }
      });
      const newStats = {
        ...response.data.metrics,
        dataSource: response.data.dataSource,
        recordCount: response.data.recordCount
      };
      statsCache.current[cacheKey] = newStats;
      setStats(newStats);
    } catch (err) {
      console.error('Error fetching stats:', err);
      setError(err.response?.data?.message || 'Failed to fetch data from selected source');
      setStats(null);
    }
    setLoading(false);
  };

  useEffect(() => {
    // Only fetch if we have a data source and valid date range
    if (selectedDataSource && 
        ((timeRange === "custom" && customRange.start && customRange.end) || timeRange !== "custom")) {
      fetchEcommerceStats();
    }
  }, [selectedDataSource, timeRange, customRange]);

  const handleDataSourceChange = (dataSourceId, dataSource) => {
    setSelectedDataSource(dataSource);
    setStats(null);
    setError("");
  };

  const renderNoDataSourceMessage = () => (
    <div className="text-center py-12">
      <AlertCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
      <h3 className="text-xl font-semibold mb-2">No Data Source Selected</h3>
      <p className="text-muted-foreground mb-6 max-w-md mx-auto">
        Select an ecommerce data source above to view your business metrics and analytics.
      </p>
      <Button onClick={() => navigate('/sources')} className="mb-4">
        <Settings className="w-4 h-4 mr-2" />
        Connect Data Sources
      </Button>
      <p className="text-sm text-muted-foreground">
        Connect Shopify, BigCommerce, or other platforms to get started
      </p>
    </div>
  );

  const renderNoDataMessage = () => (
    <div className="text-center py-12">
      <AlertCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
      <h3 className="text-xl font-semibold mb-2">No Data Available</h3>
      <p className="text-muted-foreground mb-6 max-w-md mx-auto">
        No data found for the selected date range in {selectedDataSource?.name}.
        Try selecting a different time period or check your data source connection.
      </p>
      <Button onClick={fetchEcommerceStats} variant="outline">
        <RefreshCw className="w-4 h-4 mr-2" />
        Retry
      </Button>
    </div>
  );

  let start, end;
  if (timeRange === "custom") {
    start = customRange.start;
    end = customRange.end;
  } else {
    const range = getDateRange(timeRange);
    start = range.start;
    end = range.end;
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold">Data Wise Advisor</h1>
          <p className="text-muted-foreground">Your intelligent business analysis dashboard.</p>
        </div>

        {/* Data Source Selector */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Select Data Source</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4">
              <div className="w-80">
                <DataSourceSelector
                  onDataSourceChange={handleDataSourceChange}
                  selectedDataSourceId={selectedDataSource?._id}
                  filterTypes={['shopify', 'bigcommerce']}
                  placeholder="Choose your ecommerce platform"
                  className="w-full"
                />
              </div>
              {selectedDataSource && (
                <div className="text-sm text-muted-foreground flex items-center space-x-2">
                  <span>Using: <span className="font-medium">{selectedDataSource.name}</span></span>
                  {stats?.recordCount !== undefined && (
                    <span>• {stats.recordCount} records</span>
                  )}
                  <div className="flex items-center space-x-1 text-green-600">
                    <div className="h-2 w-2 rounded-full bg-green-500" />
                    <span className="text-xs font-medium">Synced Data</span>
                  </div>
                  {stats?.dataSource && (
                    <span className="text-xs text-muted-foreground">
                      ({stats.dataSource.type})
                    </span>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {!selectedDataSource ? (
          renderNoDataSourceMessage()
        ) : (
          <>
            {/* Time Range Controls */}
            <div className="flex items-center justify-between">
              <div className="flex gap-2 items-center">
                <div className="flex rounded-md border border-gray-200 overflow-hidden">
                  {TIME_RANGES_OPTIONS.map((range, index) => (
                    <Button
                      key={range.value}
                      variant="ghost"
                      size="sm"
                      className={`
                        ${timeRange === range.value
                          ? 'bg-gray-200 text-gray-800'
                          : 'text-gray-600 hover:bg-gray-100'
                        }
                        ${index === 0 ? 'rounded-l-md' : ''}
                        ${index === TIME_RANGES_OPTIONS.length - 2 ? 'rounded-r-md' : ''}
                        ${range.value !== 'custom' && index < TIME_RANGES_OPTIONS.length -1 ? 'border-r border-gray-200' : ''}
                        rounded-none h-8 px-4
                      `}
                      onClick={() => setTimeRange(range.value)}
                    >
                      {range.label}
                    </Button>
                  ))}
                </div>
                <span className="text-muted-foreground text-sm">
                  {timeRange === 'custom'
                    ? (customRange.start && customRange.end
                        ? `${customRange.start} - ${customRange.end}`
                        : 'Select custom range')
                    : TIME_RANGES_OPTIONS.find(range => range.value === timeRange)?.fullLabel
                  }
                </span>
                {timeRange === "custom" && (
                  <>
                    <input
                      type="date"
                      value={customRange.start}
                      onChange={e => setCustomRange(r => ({ ...r, start: e.target.value }))}
                      className="border rounded px-2 py-1 text-sm h-8"
                    />
                    <span>to</span>
                    <input
                      type="date"
                      value={customRange.end}
                      onChange={e => setCustomRange(r => ({ ...r, end: e.target.value }))}
                      className="border rounded px-2 py-1 text-sm h-8"
                    />
                  </>
                )}
              </div>
              <div className="flex items-center gap-4">
                <Button variant="outline" onClick={fetchEcommerceStats} disabled={loading}>
                  <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                </Button>
              </div>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {[...Array(8)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-6">
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-8 bg-gray-200 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : stats ? (
              <>
                {/* Analytics Section: Trends, Deltas, Top Products, Sales by Channel, Conversion Rate, Alerts */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                  {/* Trends & Deltas */}
                  <div className="col-span-2 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Sales Trend Sparkline */}
                      <Card>
                        <CardHeader className="pb-2"><CardTitle>Sales Trend</CardTitle></CardHeader>
                        <CardContent>
                          {stats.sales_over_time?.current_year && (
                            <ChartContainer config={{ sales: { color: '#2563eb', label: 'Sales' } }}>
                              <RechartsPrimitive.LineChart data={Object.entries(stats.sales_over_time.current_year).map(([month, value]) => ({ month, value }))}>
                                <RechartsPrimitive.Line type="monotone" dataKey="value" stroke="#2563eb" strokeWidth={2} dot={false} />
                                <RechartsPrimitive.XAxis dataKey="month" hide />
                                <RechartsPrimitive.YAxis hide />
                              </RechartsPrimitive.LineChart>
                            </ChartContainer>
                          )}
                        </CardContent>
                      </Card>
                      {/* Orders Trend Sparkline */}
                      <Card>
                        <CardHeader className="pb-2"><CardTitle>Orders Trend</CardTitle></CardHeader>
                        <CardContent>
                          {stats.sales_over_time?.current_year && (
                            <ChartContainer config={{ orders: { color: '#059669', label: 'Orders' } }}>
                              <RechartsPrimitive.LineChart data={Object.entries(stats.sales_over_time.current_year).map(([month, value]) => ({ month, value }))}>
                                <RechartsPrimitive.Line type="monotone" dataKey="value" stroke="#059669" strokeWidth={2} dot={false} />
                                <RechartsPrimitive.XAxis dataKey="month" hide />
                                <RechartsPrimitive.YAxis hide />
                              </RechartsPrimitive.LineChart>
                            </ChartContainer>
                          )}
                        </CardContent>
                      </Card>
                    </div>
                    {/* Deltas for main metrics */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <StatCard title="Total Revenue" value={`$${stats.total_revenue.toLocaleString(undefined, { maximumFractionDigits: 2 })}`} icon="💰" change={typeof stats.total_revenue_delta === 'number' ? `${stats.total_revenue_delta > 0 ? '+' : ''}${stats.total_revenue_delta.toFixed(2)}%` : 'N/A'} trend={typeof stats.total_revenue_delta === 'number' ? (stats.total_revenue_delta > 0 ? 'up' : 'down') : undefined} />
                      <StatCard title="Net Sales" value={`$${stats.net_sales.toLocaleString(undefined, { maximumFractionDigits: 2 })}`} icon="📈" change={typeof stats.net_sales_delta === 'number' ? `${stats.net_sales_delta > 0 ? '+' : ''}${stats.net_sales_delta.toFixed(2)}%` : 'N/A'} trend={typeof stats.net_sales_delta === 'number' ? (stats.net_sales_delta > 0 ? 'up' : 'down') : undefined} />
                      <StatCard title="Total Orders" value={stats.total_orders.toLocaleString()} icon="📦" change={typeof stats.total_orders_delta === 'number' ? `${stats.total_orders_delta > 0 ? '+' : ''}${stats.total_orders_delta.toFixed(2)}%` : 'N/A'} trend={typeof stats.total_orders_delta === 'number' ? (stats.total_orders_delta > 0 ? 'up' : 'down') : undefined} />
                      <StatCard title="Total Customers" value={stats.unique_customers.toLocaleString()} icon="👥" change={typeof stats.unique_customers_delta === 'number' ? `${stats.unique_customers_delta > 0 ? '+' : ''}${stats.unique_customers_delta.toFixed(2)}%` : 'N/A'} trend={typeof stats.unique_customers_delta === 'number' ? (stats.unique_customers_delta > 0 ? 'up' : 'down') : undefined} />
                    </div>
                  </div>
                  {/* Top Products & Sales by Channel */}
                  <div className="space-y-4">
                    {/* Top Products */}
                    <Card>
                      <CardHeader className="pb-2"><CardTitle>Top Products</CardTitle></CardHeader>
                      <CardContent>
                        {stats.sales_by_product ? (
                          <ul className="space-y-1">
                            {Object.entries(stats.sales_by_product).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([product, value]) => (
                              <li key={product} className="flex justify-between"><span>{product}</span><span className="font-semibold">${value.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span></li>
                            ))}
                          </ul>
                        ) : <span className="text-muted-foreground">No product data</span>}
                      </CardContent>
                    </Card>
                    {/* Sales by Channel */}
                    <Card>
                      <CardHeader className="pb-2"><CardTitle>Sales by Channel</CardTitle></CardHeader>
                      <CardContent>
                        {stats.sales_by_channel ? (
                          <ChartContainer config={{ channel: { color: '#a21caf', label: 'Channel' } }}>
                            <RechartsPrimitive.PieChart>
                              <RechartsPrimitive.Pie data={Object.entries(stats.sales_by_channel).map(([channel, value]) => ({ channel, value }))} dataKey="value" nameKey="channel" cx="50%" cy="50%" outerRadius={40} fill="#a21caf" label />
                            </RechartsPrimitive.PieChart>
                          </ChartContainer>
                        ) : <span className="text-muted-foreground">No channel data</span>}
                      </CardContent>
                    </Card>
                    {/* Conversion Rate */}
                    {stats.conversion_rate && (
                      <Card>
                        <CardHeader className="pb-2"><CardTitle>Conversion Rate</CardTitle></CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold">{(stats.conversion_rate * 100).toFixed(2)}%</div>
                        </CardContent>
                      </Card>
                    )}
                    {/* Mini Alerts */}
                    <div className="flex flex-wrap gap-2 mt-2">
                      {stats.total_revenue > 100000 && <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">Record Sales!</span>}
                      {stats.total_discounts > 20000 && <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs">Unusual Discount Spike</span>}
                      {/* Add more alerts as needed */}
                    </div>
                  </div>
                </div>
                {/* End Analytics Section */}

                {/* AI Insights and Upload */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="col-span-2">
                    <AiInsightCard 
                      stats={stats} 
                      dataSource={stats?.dataSource}
                      dateRange={{ start, end }}
                    />
                  </div>
                </div>

                {/* Documents and Quick Actions */}
                <QuickActions 
                  stats={stats}
                  dataSource={stats?.dataSource}
                  dateRange={{ start, end }}
                />
              </>
            ) : (
              renderNoDataMessage()
            )}
          </>
        )}
      </div>
    </AppLayout>
  );
};

export default Dashboard;
