import { useState, useEffect, useMemo } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Download, Target, TrendingUp, Users, Clock, ShoppingCart, AlertTriangle, ChevronLeft, ChevronRight } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

import { fetchRemoteFittingCombinedData, type RemoteFittingData, type RemoteFittingResponse } from "@/services/remoteFittingService";

const RemoteFittingPage = () => {
  const [dateFilter, setDateFilter] = useState("week");
  const [selectedSubmission, setSelectedSubmission] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submissions, setSubmissions] = useState<RemoteFittingData[]>([]);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 1000,
    totalRecords: 0,
    totalPages: 0,
    hasNext: false,
    hasPrev: false
  });
  const [summaryData, setSummaryData] = useState({
    totalSubmissions: 0,
    purchaseRate: 0,
    averageTimeToPurchase: 0,
    topPuttingStyle: "-"
  });

  useEffect(() => {
    loadCombinedFittingData();
  }, []);

  const loadCombinedFittingData = async (page: number = 1) => {
    try {
      setLoading(true);
      const response: RemoteFittingResponse = await fetchRemoteFittingCombinedData(page, 1000);
      setSubmissions(response.data);
      setPagination(response.pagination);
      
      // Calculate summary data with better logic
      const purchased = response.data.filter(d => d.purchased);
      const purchaseRate = response.data.length > 0 ? (purchased.length / response.data.length) * 100 : 0;
      const avgTimeToPurchase = purchased.length > 0 
        ? purchased.reduce((acc, curr) => acc + (curr.timeToPurchase || 0), 0) / purchased.length 
        : 0;
      
      // Calculate top putting style with better fallback
      const styles = response.data.reduce((acc, curr) => {
        const style = curr.puttingStyle || 'Unknown';
        acc[style] = (acc[style] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      
      const topStyle = Object.keys(styles).length > 0 
        ? Object.entries(styles).sort((a, b) => b[1] - a[1])[0][0]
        : "Unknown";
      
      setSummaryData({
        totalSubmissions: response.pagination.totalRecords,
        purchaseRate: Math.round(purchaseRate * 10) / 10,
        averageTimeToPurchase: Math.round(avgTimeToPurchase * 10) / 10,
        topPuttingStyle: topStyle
      });
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load fitting data');
    } finally {
      setLoading(false);
    }
  };

  const handlePageChange = (newPage: number) => {
    loadCombinedFittingData(newPage);
  };

  // Use the submissions data directly
  const submissionsData = submissions;

  const timeToPurchaseData = useMemo(() => {
    const ranges = {
      "1-2": { min: 1, max: 2, count: 0 },
      "3-5": { min: 3, max: 5, count: 0 },
      "6-10": { min: 6, max: 10, count: 0 },
      "11-15": { min: 11, max: 15, count: 0 },
      "16+": { min: 16, max: Infinity, count: 0 }
    };
    submissions.forEach(submission => {
      if (submission.timeToPurchase) {
        const range = Object.entries(ranges).find(([_, { min, max }]) => 
          submission.timeToPurchase! >= min && submission.timeToPurchase! <= max
        );
        if (range) {
          ranges[range[0]].count++;
        }
      }
    });
    return Object.entries(ranges).map(([days, { count }]) => ({ days, count }));
  }, [submissions]);

  const exportToCSV = () => {
    if (!submissions.length) return;
    const headers = ['Date', 'Putting Style', 'Putter Type', 'Length', 'Lie', 'Loft', 'Purchase Status', 'Time to Purchase', 'Customer Email'];
    const csvContent = [
      headers.join(','),
      ...submissions.map(submission => [
        new Date(submission.date).toLocaleDateString(),
        submission.puttingStyle,
        submission.putterType,
        submission.length,
        submission.lie,
        submission.loft,
        submission.purchased ? 'Purchased' : 'No Purchase',
        submission.timeToPurchase || '-',
        submission.customerEmail
      ].map(field => `"${String(field).replace(/"/g, '""')}"`).join(','))
    ].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `fitting-data-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Loading fitting data...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  if (error) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <div className="text-center text-red-600">
            <AlertTriangle className="h-12 w-12 mx-auto mb-4" />
            <p>Error loading fitting data: {error}</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => loadCombinedFittingData()}
            >
              Retry
            </Button>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Target className="h-8 w-8" />
            Remote Fitting Analytics
          </h1>
          <p className="text-muted-foreground">
            Track and analyze fitting data submissions for insights into user behavior and conversion rates. (All CSVs combined)
          </p>
        </div>
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Submissions</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.totalSubmissions}</div>
              <p className="text-xs text-muted-foreground">From all CSVs</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Purchase Rate</CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.purchaseRate}%</div>
              <p className="text-xs text-muted-foreground">Conversion rate</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg. Time to Purchase</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.averageTimeToPurchase} days</div>
              <p className="text-xs text-muted-foreground">For converted leads</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Top Putting Style</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.topPuttingStyle}</div>
              <p className="text-xs text-muted-foreground">Most common style</p>
            </CardContent>
          </Card>
        </div>
        <Tabs defaultValue="table" className="space-y-4">
          <TabsList>
            <TabsTrigger value="table">Submissions Data</TabsTrigger>
            <TabsTrigger value="charts">Time to Purchase</TabsTrigger>
          </TabsList>
          <TabsContent value="table" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Fitting Submissions</CardTitle>
                <CardDescription>
                  Detailed view of all fitting submissions with sortable columns
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Customer Name</TableHead>
                      <TableHead>Putting Style</TableHead>
                      <TableHead>Putter Type</TableHead>
                      <TableHead>Length</TableHead>
                      <TableHead>Lie</TableHead>
                      <TableHead>Loft</TableHead>
                      <TableHead>Purchase Status</TableHead>
                      <TableHead>Time to Purchase</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {submissionsData.map((submission) => (
                      <TableRow key={submission.id}>
                        <TableCell>
                          {submission.date ? 
                            new Date(submission.date).toLocaleDateString() : 
                            'N/A'
                          }
                        </TableCell>
                        <TableCell>
                          {submission.firstName && submission.lastName ? 
                            `${submission.firstName} ${submission.lastName}` : 
                            submission.customerEmail || 'N/A'
                          }
                        </TableCell>
                        <TableCell>{submission.puttingStyle || 'Unknown'}</TableCell>
                        <TableCell>{submission.putterType || 'Standard'}</TableCell>
                        <TableCell>{submission.length || 'N/A'}</TableCell>
                        <TableCell>{submission.lie || 'N/A'}</TableCell>
                        <TableCell>{submission.loft || 'N/A'}</TableCell>
                        <TableCell>
                          <Badge variant={submission.purchased ? "default" : "secondary"}>
                            {submission.purchased ? "Purchased" : "No Purchase"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {submission.timeToPurchase ? `${submission.timeToPurchase} days` : "-"}
                        </TableCell>
                        <TableCell>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => setSelectedSubmission(submission.id)}
                          >
                            View Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
            
            {/* Pagination Controls */}
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                Showing {((pagination.page - 1) * pagination.limit) + 1} to {Math.min(pagination.page * pagination.limit, pagination.totalRecords)} of {pagination.totalRecords} results
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePageChange(pagination.page - 1)}
                  disabled={!pagination.hasPrev}
                >
                  <ChevronLeft className="h-4 w-4" />
                  Previous
                </Button>
                <div className="text-sm">
                  Page {pagination.page} of {pagination.totalPages}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePageChange(pagination.page + 1)}
                  disabled={!pagination.hasNext}
                >
                  Next
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="charts" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Time to Purchase Distribution</CardTitle>
                <CardDescription>
                  Analysis of how long customers take to purchase after fitting submission
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={timeToPurchaseData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="days" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default RemoteFittingPage;
