import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode | string;
  change?: number | string | null;
  trend?: "up" | "down";
}

export function StatCard({ title, value, change, icon, trend = "up" }: StatCardProps) {
  const TrendIcon = trend === "up" ? TrendingUp : TrendingDown;
  const changeColor = trend === "up" ? "text-green-600" : "text-red-600";

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="flex items-center space-x-1">
          {icon}
          <div className="h-1 w-1 rounded-full bg-green-500" title="Using synced data for fast performance" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className={`text-xs ${changeColor} flex items-center`}>
          <TrendIcon className="mr-1 h-3 w-3" />
          {change}
        </div>
      </CardContent>
    </Card>
  );
}

export default StatCard;
