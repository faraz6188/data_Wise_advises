import axios from 'axios';

// Updated interfaces to match Shopify data structure
export interface LeadTimeOrder {
  orderId: string;
  orderNumber: string;
  customer: string;
  putterType: string;
  orderDate: string;
  shipDate: string;
  leadTime: number;
  status: 'Delayed' | 'Early' | 'On Time';
  productName: string;
  shaftType: string;
  shaftLength: string;
  putterColor: string;
  gripType: string;
  puttingStyle: string;
  hand: string;
  lieAngle: string;
  headWeight: string;
  buildTime: string;
  // Additional Shopify context
  totalPrice?: string;
  currency?: string;
  financialStatus?: string;
  fulfillmentStatus?: string;
  tags?: string;
  note?: string;
}

export interface LeadTimeSummary {
  averageLeadTime: number;
  medianLeadTime: number;
  longestLeadTime: number;
  shortestLeadTime: number;
  totalOrders: number;
  byProductType: Record<string, number>;
  byPuttingStyle: Record<string, number>;
  byHand: Record<string, number>;
  byBuildTime: Record<string, number>;
}

export interface LeadTimeData {
  category: string;
  averageLeadTime: number;
  medianLeadTime: number;
  orderCount: number;
  delayedOrders: number;
  earlyOrders: number;
}

export interface LeadTimeResponse {
  data: LeadTimeOrder[];
  summary: {
    totalOrders: number;
    averageLeadTime: number;
    medianLeadTime: number;
    longestLeadTime: number;
    shortestLeadTime: number;
  };
}

const determineOrderStatus = (leadTime: number): 'Delayed' | 'Early' | 'On Time' => {
  if (leadTime > 7) return 'Delayed';
  if (leadTime < 2) return 'Early';
  return 'On Time';
};

export const fetchLeadTimeData = async (startDate: string, endDate: string): Promise<LeadTimeResponse> => {
  try {
    const response = await axios.get('/api/lead-time/data', {
      params: {
        start_date: startDate,
        end_date: endDate
      }
    });
    
    if (response.data?.data) {
      return response.data;
    }
    
    return { data: [], summary: { totalOrders: 0, averageLeadTime: 0, medianLeadTime: 0, longestLeadTime: 0, shortestLeadTime: 0 } };
  } catch (error) {
    console.error('Error fetching lead time data:', error);
    return { data: [], summary: { totalOrders: 0, averageLeadTime: 0, medianLeadTime: 0, longestLeadTime: 0, shortestLeadTime: 0 } };
  }
};

export const calculateLeadTimeMetrics = (orders: LeadTimeOrder[]): LeadTimeSummary => {
  if (!orders.length) {
    return {
      averageLeadTime: 0,
      medianLeadTime: 0,
      longestLeadTime: 0,
      shortestLeadTime: 0,
      totalOrders: 0,
      byProductType: {},
      byPuttingStyle: {},
      byHand: {},
      byBuildTime: {}
    };
  }

  const leadTimes = orders.map(order => order.leadTime).sort((a, b) => a - b);
  const totalLeadTime = leadTimes.reduce((sum, time) => sum + time, 0);
  
  // Calculate metrics by category
  const byProductType: Record<string, number> = {};
  const byPuttingStyle: Record<string, number> = {};
  const byHand: Record<string, number> = {};
  const byBuildTime: Record<string, number> = {};

  orders.forEach(order => {
    byProductType[order.productName] = (byProductType[order.productName] || 0) + 1;
    byPuttingStyle[order.puttingStyle] = (byPuttingStyle[order.puttingStyle] || 0) + 1;
    byHand[order.hand] = (byHand[order.hand] || 0) + 1;
    byBuildTime[order.buildTime] = (byBuildTime[order.buildTime] || 0) + 1;
  });

  return {
    averageLeadTime: totalLeadTime / orders.length,
    medianLeadTime: leadTimes[Math.floor(orders.length / 2)],
    longestLeadTime: Math.max(...leadTimes),
    shortestLeadTime: Math.min(...leadTimes),
    totalOrders: orders.length,
    byProductType,
    byPuttingStyle,
    byHand,
    byBuildTime
  };
};

export const groupLeadTimeData = (orders: LeadTimeOrder[], groupBy: string): LeadTimeData[] => {
  const groupedData = new Map<string, LeadTimeOrder[]>();
  
  orders.forEach(order => {
    const key = order[groupBy as keyof LeadTimeOrder] as string;
    if (!groupedData.has(key)) {
      groupedData.set(key, []);
    }
    groupedData.get(key)?.push(order);
  });

  return Array.from(groupedData.entries()).map(([category, categoryOrders]) => {
    const leadTimes = categoryOrders.map(order => order.leadTime);
    const totalLeadTime = leadTimes.reduce((sum, time) => sum + time, 0);
    
    return {
      category,
      averageLeadTime: totalLeadTime / categoryOrders.length,
      medianLeadTime: leadTimes.sort((a, b) => a - b)[Math.floor(categoryOrders.length / 2)],
      orderCount: categoryOrders.length,
      delayedOrders: categoryOrders.filter(order => order.status === 'Delayed').length,
      earlyOrders: categoryOrders.filter(order => order.status === 'Early').length
    };
  });
}; 