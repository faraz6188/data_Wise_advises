import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { authenticate } from '../middleware/auth.js';
import { GoogleGenerativeAI } from '@google/generative-ai';

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    // Generate unique filename
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const fileFilter = (req, file, cb) => {
  const allowedTypes = [
    'text/csv',
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-excel',
    'application/json',
    'text/plain'
  ];
  
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only CSV, PDF, XLSX, JSON, and TXT files are allowed.'), false);
  }
};

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
    files: 10 // Maximum 10 files per upload
  },
  fileFilter: fileFilter
});

// Initialize Gemini AI
const genAI = process.env.GEMINI_API_KEY ? new GoogleGenerativeAI(process.env.GEMINI_API_KEY) : null;

const ANALYSIS_PROMPT = `You are an expert AI Business Analyst. Analyze the uploaded business data file and provide insights.

Please provide a structured analysis with the following sections:

**Data Overview:**
- File type and size
- Number of records/rows
- Key data fields identified

**Key Insights:**
- Main trends and patterns
- Notable findings
- Potential data quality issues

**Business Recommendations:**
- Actionable next steps
- Areas for improvement
- Strategic opportunities

**Summary:**
- Brief executive summary

Focus on business-relevant insights and be specific with numbers and recommendations.`;

// File upload endpoint
router.post('/', authenticate, (req, res, next) => {
  upload.array('files', 10)(req, res, (err) => {
    if (err) {
      console.error('Multer upload error:', err);
      
      // Handle specific multer errors
      if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
          return res.status(400).json({ 
            message: 'File too large. Maximum file size is 50MB.',
            error: 'FILE_TOO_LARGE' 
          });
        }
        if (err.code === 'LIMIT_FILE_COUNT') {
          return res.status(400).json({ 
            message: 'Too many files. Maximum 10 files per upload.',
            error: 'TOO_MANY_FILES' 
          });
        }
        if (err.code === 'LIMIT_UNEXPECTED_FILE') {
          return res.status(400).json({ 
            message: 'Unexpected field name for file upload.',
            error: 'UNEXPECTED_FIELD' 
          });
        }
      }
      
      // Handle file filter errors
      if (err.message && err.message.includes('Invalid file type')) {
        return res.status(400).json({ 
          message: err.message,
          error: 'INVALID_FILE_TYPE' 
        });
      }
      
      // Generic upload error
      return res.status(400).json({ 
        message: 'File upload failed: ' + err.message,
        error: 'UPLOAD_ERROR' 
      });
    }
    
    // Continue to the actual upload handler
    next();
  });
}, async (req, res) => {
  try {
    console.log('📁 Upload request received:', {
      filesCount: req.files?.length || 0,
      user: req.user?.id
    });
    
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ 
        message: 'No files uploaded',
        error: 'NO_FILES' 
      });
    }

    const results = [];
    
    for (const file of req.files) {
      console.log(`📁 Processing file: ${file.originalname} (${file.mimetype})`);
      
      let analysis = null;
      
      // Analyze file with Gemini if API key is available
      if (genAI) {
        try {
          const fileContent = await readFileContent(file);
          if (fileContent) {
            const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
            const prompt = `${ANALYSIS_PROMPT}\n\nFile: ${file.originalname}\nContent:\n${fileContent}`;
            const result = await model.generateContent(prompt);
            const response = await result.response;
            analysis = response.text();
            console.log(`✅ AI analysis completed for ${file.originalname}`);
          }
        } catch (aiError) {
          console.error('AI analysis error:', aiError);
          analysis = 'File uploaded successfully, but AI analysis is not available at this time.';
        }
      } else {
        analysis = 'File uploaded successfully. AI analysis requires GEMINI_API_KEY configuration.';
      }

      results.push({
        filename: file.originalname,
        path: file.path,
        size: file.size,
        mimetype: file.mimetype,
        uploadedAt: new Date(),
        analysis: analysis
      });
    }

    console.log(`✅ Upload completed: ${req.files.length} files processed`);
    
    res.json({
      message: `${req.files.length} file(s) uploaded successfully`,
      files: results
    });

  } catch (error) {
    console.error('Upload processing error:', error);
    
    // Clean up uploaded files on error
    if (req.files) {
      req.files.forEach(file => {
        try {
          fs.unlinkSync(file.path);
        } catch (cleanupError) {
          console.error('Error cleaning up file:', cleanupError);
        }
      });
    }
    
    res.status(500).json({ 
      message: 'File upload processing failed',
      error: error.message 
    });
  }
});

// Get uploaded files for user
router.get('/files', authenticate, async (req, res) => {
  try {
    const uploadDir = 'uploads/';
    
    if (!fs.existsSync(uploadDir)) {
      return res.json({ files: [] });
    }
    
    const files = fs.readdirSync(uploadDir).map(filename => {
      const filePath = path.join(uploadDir, filename);
      const stats = fs.statSync(filePath);
      
      return {
        filename: filename,
        size: stats.size,
        uploadedAt: stats.mtime,
        path: filePath
      };
    });
    
    // Sort by upload date (newest first)
    files.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());
    
    res.json({ files });
  } catch (error) {
    console.error('Error fetching files:', error);
    res.status(500).json({ 
      message: 'Failed to fetch files',
      error: error.message 
    });
  }
});

// Delete uploaded file
router.delete('/files/:filename', authenticate, async (req, res) => {
  try {
    const { filename } = req.params;
    const filePath = path.join('uploads/', filename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: 'File not found' });
    }
    
    fs.unlinkSync(filePath);
    
    res.json({ message: 'File deleted successfully' });
  } catch (error) {
    console.error('Error deleting file:', error);
    res.status(500).json({ 
      message: 'Failed to delete file',
      error: error.message 
    });
  }
});

// Helper function to read file content based on file type
async function readFileContent(file) {
  try {
    const content = fs.readFileSync(file.path, 'utf8');
    
    // For CSV files, limit content to first 100 lines for analysis
    if (file.mimetype === 'text/csv') {
      const lines = content.split('\n');
      if (lines.length > 100) {
        return lines.slice(0, 100).join('\n') + '\n... (truncated for analysis)';
      }
    }
    
    // For other text files, limit to first 10000 characters
    if (content.length > 10000) {
      return content.substring(0, 10000) + '... (truncated for analysis)';
    }
    
    return content;
  } catch (error) {
    console.error('Error reading file content:', error);
    return null;
  }
}

export default router; 