import express from 'express';
import { authenticate } from '../middleware/auth.js';
import { SyncService } from '../services/syncService.js';
import DataSource from '../models/DataSource.js';
import SyncJob from '../models/SyncJob.js';

const router = express.Router();

// Trigger sync for a data source
router.post('/:dataSourceId/sync', authenticate, async (req, res) => {
  try {
    console.log(`🔄 Sync request received for dataSource: ${req.params.dataSourceId}, user: ${req.user.id}`);
    
    const { dataSourceId } = req.params;
    const { 
      jobType = 'manual_sync',
      startDate,
      endDate,
      dataTypes,
      batchSize = 100,
      maxRequests = 100
    } = req.body;

    console.log(`📋 Sync options:`, { jobType, startDate, endDate, dataTypes, batchSize, maxRequests });

    // Verify data source belongs to user
    const dataSource = await DataSource.findOne({
      _id: dataSourceId,
      user: req.user.id,
      isActive: true,
      status: 'connected'
    });

    if (!dataSource) {
      console.log(`❌ Data source not found or not accessible for user ${req.user.id}`);
      return res.status(404).json({ message: 'Data source not found or not accessible' });
    }

    console.log(`✅ Found data source: ${dataSource.name} (${dataSource.type})`);

    // Check if user has required credentials for this data source type
    if (dataSource.type === 'shopify') {
      const hasCredentials = dataSource.credentials?.shopifyAccessToken && dataSource.credentials?.shopifyDomain;
      if (!hasCredentials) {
        console.log(`❌ Missing Shopify credentials for data source ${dataSourceId}`);
        return res.status(400).json({ message: 'Missing Shopify credentials. Please configure your Shopify connection.' });
      }
      console.log(`✅ Shopify credentials verified for domain: ${dataSource.credentials.shopifyDomain}`);
    }

    // Check if there's already an active sync job
    const activeJobs = await SyncJob.find({
      user: req.user.id,
      dataSource: dataSourceId,
      status: { $in: ['pending', 'running'] }
    });

    if (activeJobs.length > 0) {
      return res.status(409).json({ 
        message: 'Sync already in progress',
        activeJob: activeJobs[0]._id
      });
    }

    const options = {
      jobType,
      startDate,
      endDate,
      dataTypes,
      batchSize,
      maxRequests
    };

    const result = await SyncService.syncDataSource(req.user.id, dataSourceId, options);

    res.json({
      message: 'Sync started successfully',
      jobId: result.jobId,
      dataSource: {
        id: dataSource._id,
        name: dataSource.name,
        type: dataSource.type
      }
    });

  } catch (error) {
    console.error('Sync trigger error:', error);
    res.status(500).json({ 
      message: 'Failed to start sync',
      error: error.message 
    });
  }
});

// Get active sync jobs for user
router.get('/jobs/active', authenticate, async (req, res) => {
  try {
    const activeJobs = await SyncJob.find({
      user: req.user.id,
      status: { $in: ['pending', 'running'] }
    })
    .populate('dataSource', 'name type')
    .sort({ createdAt: -1 });

    res.json(activeJobs);

  } catch (error) {
    console.error('Error fetching active sync jobs:', error);
    res.status(500).json({ 
      message: 'Failed to fetch active sync jobs',
      error: error.message 
    });
  }
});

// Get sync job status
router.get('/jobs/:jobId', authenticate, async (req, res) => {
  try {
    const { jobId } = req.params;

    const job = await SyncJob.findOne({
      _id: jobId,
      user: req.user.id
    }).populate('dataSource', 'name type');

    if (!job) {
      return res.status(404).json({ message: 'Sync job not found' });
    }

    res.json(job);

  } catch (error) {
    console.error('Error fetching sync job:', error);
    res.status(500).json({ 
      message: 'Failed to fetch sync job',
      error: error.message 
    });
  }
});

// Get sync job history for a data source
router.get('/:dataSourceId/history', authenticate, async (req, res) => {
  try {
    const { dataSourceId } = req.params;
    const { limit = 20, page = 1 } = req.query;

    // Verify data source belongs to user
    const dataSource = await DataSource.findOne({
      _id: dataSourceId,
      user: req.user.id
    });

    if (!dataSource) {
      return res.status(404).json({ message: 'Data source not found' });
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const jobs = await SyncJob.find({
      user: req.user.id,
      dataSource: dataSourceId
    })
    .populate('dataSource', 'name type')
    .sort({ createdAt: -1 })
    .limit(parseInt(limit))
    .skip(skip);

    const totalJobs = await SyncJob.countDocuments({
      user: req.user.id,
      dataSource: dataSourceId
    });

    res.json({
      jobs,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: totalJobs,
        pages: Math.ceil(totalJobs / parseInt(limit))
      }
    });

  } catch (error) {
    console.error('Error fetching sync history:', error);
    res.status(500).json({ 
      message: 'Failed to fetch sync history',
      error: error.message 
    });
  }
});

// Cancel a sync job
router.post('/jobs/:jobId/cancel', authenticate, async (req, res) => {
  try {
    const { jobId } = req.params;
    const { reason = 'Cancelled by user' } = req.body;

    const job = await SyncJob.findOne({
      _id: jobId,
      user: req.user.id,
      status: { $in: ['pending', 'running'] }
    });

    if (!job) {
      return res.status(404).json({ message: 'Active sync job not found' });
    }

    await job.cancel(reason);

    res.json({
      message: 'Sync job cancelled successfully',
      job
    });

  } catch (error) {
    console.error('Error cancelling sync job:', error);
    res.status(500).json({ 
      message: 'Failed to cancel sync job',
      error: error.message 
    });
  }
});

// Get synced data for a data source
router.get('/:dataSourceId/data/:dataType', authenticate, async (req, res) => {
  try {
    const { dataSourceId, dataType } = req.params;
    const { 
      limit = 100, 
      page = 1, 
      startDate, 
      endDate,
      sortBy = 'lastUpdated',
      sortOrder = 'desc'
    } = req.query;

    // Verify data source belongs to user
    const dataSource = await DataSource.findOne({
      _id: dataSourceId,
      user: req.user.id
    });

    if (!dataSource) {
      return res.status(404).json({ message: 'Data source not found' });
    }

    const options = {
      limit: parseInt(limit),
      skip: (parseInt(page) - 1) * parseInt(limit),
      startDate,
      endDate,
      sortBy,
      sortOrder
    };

    const data = await SyncService.getSyncedData(req.user.id, dataSourceId, dataType, options);

    res.json({
      dataSource: {
        id: dataSource._id,
        name: dataSource.name,
        type: dataSource.type
      },
      dataType,
      data,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: data.length
      }
    });

  } catch (error) {
    console.error('Error fetching synced data:', error);
    res.status(500).json({ 
      message: 'Failed to fetch synced data',
      error: error.message 
    });
  }
});

// Get sync data statistics for a data source
router.get('/:dataSourceId/stats', authenticate, async (req, res) => {
  try {
    const { dataSourceId } = req.params;

    // Verify data source belongs to user
    const dataSource = await DataSource.findOne({
      _id: dataSourceId,
      user: req.user.id
    });

    if (!dataSource) {
      return res.status(404).json({ message: 'Data source not found' });
    }

    const stats = await SyncService.getDataStats(req.user.id, dataSourceId);

    res.json({
      dataSource: {
        id: dataSource._id,
        name: dataSource.name,
        type: dataSource.type
      },
      stats
    });

  } catch (error) {
    console.error('Error fetching sync data stats:', error);
    res.status(500).json({ 
      message: 'Failed to fetch sync data stats',
      error: error.message 
    });
  }
});

// Get metrics calculated from synced data
router.get('/:dataSourceId/metrics', authenticate, async (req, res) => {
  try {
    const { dataSourceId } = req.params;
    const { startDate, endDate } = req.query;

    // Verify data source belongs to user
    const dataSource = await DataSource.findOne({
      _id: dataSourceId,
      user: req.user.id
    });

    if (!dataSource) {
      return res.status(404).json({ message: 'Data source not found' });
    }

    // Only support ecommerce platforms for metrics
    if (!['shopify', 'bigcommerce'].includes(dataSource.type)) {
      return res.status(400).json({ message: 'Metrics not supported for this data source type' });
    }

    const options = { startDate, endDate };
    const metrics = await SyncService.calculateMetricsFromSyncedData(req.user.id, dataSourceId, options);

    res.json({
      dataSource: {
        id: dataSource._id,
        name: dataSource.name,
        type: dataSource.type
      },
      metrics,
      dateRange: { startDate, endDate }
    });

  } catch (error) {
    console.error('Error calculating metrics from synced data:', error);
    res.status(500).json({ 
      message: 'Failed to calculate metrics',
      error: error.message 
    });
  }
});

export default router; 