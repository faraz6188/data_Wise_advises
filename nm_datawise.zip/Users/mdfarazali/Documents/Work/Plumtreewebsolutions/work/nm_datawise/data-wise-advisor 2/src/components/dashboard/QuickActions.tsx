import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Users, BarChart, Database } from "lucide-react";
import { geminiService } from "@/lib/gemini";

const AI_PROMPT_BASE = `You are an expert AI Business Analyst. When generating a report, use clear headings, subheadings, and tables. Do not use markdown bold (**), asterisks, or stars. Use plain text for all formatting. Keep the response concise, structured, and visually clear for business users.

Only use these metrics in your analysis and recommendations:
- Total Sales
- Net Sales
- Discounts
- Shipping
- Taxes
- AOV (Average Order Value)
- Total Orders
- Total Customers

If an API key is missing, clearly state which data is unavailable and what is used as a placeholder. Use only plain text headings and tables.`;

interface QuickActionsProps {
  stats?: {
    total_revenue?: number;
    net_sales?: number;
    total_discounts?: number;
    total_shipping?: number;
    total_taxes?: number;
    average_order_value?: number;
    total_orders?: number;
    unique_customers?: number;
  };
  dataSource?: { name: string; type: string };
  dateRange?: { start: string; end: string };
}

const QuickActions = ({ stats, dataSource, dateRange }: QuickActionsProps) => {
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState<string | null>(null);
  const [resultTitle, setResultTitle] = useState<string>("");

  const shopifyKey = import.meta.env.VITE_SHOPIFY_API_KEY;
  const gaKey = import.meta.env.VITE_GA_API_KEY;

  const dashboardMetrics = stats ? `
Total Sales: $${stats.total_revenue?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
Net Sales: $${stats.net_sales?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
Discounts: $${stats.total_discounts?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
Shipping: $${stats.total_shipping?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
Taxes: $${stats.total_taxes?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
AOV: $${stats.average_order_value?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
Total Orders: ${stats.total_orders}
Total Customers: ${stats.unique_customers}
` : "(No stats available)";

  const sourceName = dataSource?.name || "Unknown Source";
  const sourceType = dataSource?.type || "Unknown Type";
  const dateRangeStr = dateRange ? `${dateRange.start} to ${dateRange.end}` : "(date range not specified)";

  const handleAction = async (type: string) => {
    setLoading(type);
    setResult(null);
    let prompt = AI_PROMPT_BASE;
    let title = "";
    if (type === "report") {
      prompt += `\n\nGenerate a detailed, structured monthly business report for the last 30 days using all available data from ${sourceName} (${sourceType}) for the period ${dateRangeStr}. Include sections for Sales Overview, Customer Overview, Product Overview, and a 'What changed vs last month?' section. Use tables for top products/customers if possible.\nHere are the latest metrics:\n${dashboardMetrics}`;
      title = "Detailed Monthly Business Report";
    } else if (type === "cohort") {
      prompt += `\n\nPerform a customer cohort analysis for the last 6 months using data from ${sourceName} (${sourceType}). Identify cohort trends, retention, and actionable insights.\nHere are the latest metrics:\n${dashboardMetrics}`;
      title = "Customer Cohort Analysis (6 months)";
    } else if (type === "product") {
      prompt += `\n\nAnalyze product performance trends for the last 3 months using data from ${sourceName} (${sourceType}). Highlight top and underperforming products, trends, and recommendations.\nHere are the latest metrics:\n${dashboardMetrics}`;
      title = "Product Performance Trends (3 months)";
    } else if (type === "churn") {
      prompt += `\n\nIdentify customers at risk of churning based on the last 6 months of data from ${sourceName} (${sourceType}). Suggest retention strategies.\nHere are the latest metrics:\n${dashboardMetrics}`;
      title = "Churn Risk Analysis";
    } else if (type === "opportunities") {
      prompt += `\n\nHighlight the top 3 growth opportunities for the business based on recent data from ${sourceName} (${sourceType}).\nHere are the latest metrics:\n${dashboardMetrics}`;
      title = "Top Growth Opportunities";
    } else if (type === "inventory") {
      prompt += `\n\nList products with low inventory or declining sales based on the last 3 months of data from ${sourceName} (${sourceType}).\nHere are the latest metrics:\n${dashboardMetrics}`;
      title = "Inventory Alert";
    }
    setResultTitle(title);
    try {
      const aiResponse = await geminiService.sendMessage(prompt);
      setResult(aiResponse);
    } catch (err) {
      setResult("Sorry, could not complete the action at this time.");
    }
    setLoading(null);
  };
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="pt-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Button variant="outline" className="h-auto py-6 flex flex-col items-center justify-center gap-3" onClick={() => handleAction("report")} disabled={loading !== null}>
            <FileText className="h-6 w-6 text-bizoracle-blue" />
            <span>Detailed monthly report</span>
          </Button>
          <Button variant="outline" className="h-auto py-6 flex flex-col items-center justify-center gap-3" onClick={() => handleAction("cohort")} disabled={loading !== null}>
            <Users className="h-6 w-6 text-bizoracle-green" />
            <span>Customer cohort analysis</span>
          </Button>
          <Button variant="outline" className="h-auto py-6 flex flex-col items-center justify-center gap-3" onClick={() => handleAction("product")} disabled={loading !== null}>
            <BarChart className="h-6 w-6 text-bizoracle-yellow" />
            <span>Product performance trends</span>
          </Button>
          <Button variant="outline" className="h-auto py-6 flex flex-col items-center justify-center gap-3" onClick={() => handleAction("churn")} disabled={loading !== null}>
            <Users className="h-6 w-6 text-bizoracle-red" />
            <span>Churn risk analysis</span>
          </Button>
          <Button variant="outline" className="h-auto py-6 flex flex-col items-center justify-center gap-3" onClick={() => handleAction("opportunities")} disabled={loading !== null}>
            <BarChart className="h-6 w-6 text-bizoracle-blue" />
            <span>Top growth opportunities</span>
          </Button>
          <Button variant="outline" className="h-auto py-6 flex flex-col items-center justify-center gap-3" onClick={() => handleAction("inventory")} disabled={loading !== null}>
            <Database className="h-6 w-6 text-bizoracle-purple" />
            <span>Inventory alert</span>
          </Button>
        </div>
        {loading && (
          <div className="mt-6 text-center text-blue-600">Analyzing...</div>
        )}
        {result && (
          <div className="mt-6 p-4 bg-blue-50 border border-blue-100 rounded text-base" style={{ fontFamily: 'Inter, Arial, sans-serif', lineHeight: 1.7, letterSpacing: 0.1, color: '#1a202c' }}>
            <div className="font-semibold text-lg mb-2 text-bizoracle-blue">{resultTitle}</div>
            <pre style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word', background: 'none', fontFamily: 'inherit', fontSize: '1rem', margin: 0 }}>{result}</pre>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default QuickActions;
