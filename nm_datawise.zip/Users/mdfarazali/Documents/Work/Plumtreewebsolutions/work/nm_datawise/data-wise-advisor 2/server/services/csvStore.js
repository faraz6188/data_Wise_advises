import fs from 'fs';
import path from 'path';

// Simple CSV/NDJSON cache for fast, file-based storage and retrieval
// We write both:
// 1) raw NDJSON: one JSON record per line for lossless retrieval
// 2) summary CSV: common fields for quick inspection

const CACHE_ROOT = path.join(process.cwd(), 'data-cache');

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function getCacheDir(userId, dataSourceId) {
  const dir = path.join(CACHE_ROOT, 'shopify', String(userId), String(dataSourceId));
  ensureDir(dir);
  return dir;
}

function getFiles(cacheDir, type) {
  const ndjsonFile = path.join(cacheDir, `${type}.ndjson`);
  const csvFile = path.join(cacheDir, `${type}_summary.csv`);
  return { ndjsonFile, csvFile };
}

function toCsvRow(values) {
  return values
    .map((v) => {
      if (v === null || v === undefined) return '';
      const s = String(v).replace(/"/g, '""');
      return `"${s}"`;
    })
    .join(',');
}

function writeSummaryHeaderIfNeeded(csvFile, headers) {
  if (!fs.existsSync(csvFile)) {
    fs.writeFileSync(csvFile, headers.join(',') + '\n', 'utf-8');
  }
}

// Helper to get record ID consistently
function getRecordId(rec) {
  return rec.id || rec.order_id || rec.customer_id || rec.product_id || Math.random().toString(36).slice(2);
}

// Helper to get record timestamp consistently
function getRecordTimestamp(rec) {
  return rec.updated_at || rec.updatedAt || rec.date_modified || rec.created_at || rec.createdAt || new Date().toISOString();
}

export const CsvStore = {
  // Append records to cache (ndjson + csv summary) - with duplicate detection
  async appendRecords(userId, dataSourceId, type, records) {
    if (!records || records.length === 0) return;
    
    const cacheDir = getCacheDir(userId, dataSourceId);
    const { ndjsonFile, csvFile } = getFiles(cacheDir, type);

    console.log(`📝 Appending ${records.length} ${type} records to CSV cache...`);

    // Read existing records to detect duplicates
    const existingRecords = new Map();
    if (fs.existsSync(ndjsonFile)) {
      try {
        const content = fs.readFileSync(ndjsonFile, 'utf-8');
        const lines = content.split(/\n+/).filter(Boolean);
        
        for (const line of lines) {
          try {
            const rec = JSON.parse(line);
            const id = getRecordId(rec);
            const timestamp = getRecordTimestamp(rec);
            existingRecords.set(id, { record: rec, timestamp });
          } catch (e) {
            // Skip bad lines
          }
        }
        console.log(`📖 Found ${existingRecords.size} existing ${type} records in cache`);
      } catch (e) {
        console.log(`⚠️ Error reading existing cache: ${e.message}`);
      }
    }

    // Prepare CSV headers per type (minimal, extensible)
    const headers = ['id', 'created_at', 'updated_at', 'extra'];
    writeSummaryHeaderIfNeeded(csvFile, headers);

    const ndjsonStream = fs.createWriteStream(ndjsonFile, { flags: 'a' });
    const csvStream = fs.createWriteStream(csvFile, { flags: 'a' });

    let newRecords = 0;
    let updatedRecords = 0;
    let skippedRecords = 0;

    for (const rec of records) {
      try {
        const id = getRecordId(rec);
        const createdAt = rec.created_at || rec.order_date || rec.date_created || rec.createdAt;
        const updatedAt = getRecordTimestamp(rec);
        
        // Check if record already exists and if new version is newer
        const existing = existingRecords.get(id);
        if (existing) {
          const existingTimestamp = existing.timestamp;
          if (new Date(updatedAt) <= new Date(existingTimestamp)) {
            // Skip if existing record is newer or same age
            skippedRecords++;
            continue;
          }
          // Update existing record
          updatedRecords++;
        } else {
          newRecords++;
        }

        ndjsonStream.write(JSON.stringify(rec) + '\n');
        csvStream.write(
          toCsvRow([
            id || '',
            createdAt || '',
            updatedAt || '',
            // Keep a compact extra field for quick glance
            type === 'orders'
              ? (rec.financial_status || rec.fulfillment_status || rec.status || '')
              : (rec.title || rec.email || '')
          ]) + '\n'
        );
      } catch (e) {
        // Skip problematic record
        console.log(`⚠️ Skipping problematic ${type} record: ${e.message}`);
        continue;
      }
    }

    ndjsonStream.end();
    csvStream.end();

    console.log(`✅ CSV cache updated: ${newRecords} new, ${updatedRecords} updated, ${skippedRecords} skipped ${type} records`);
  },

  // Read records from ndjson with optional date filter; deduplicate by id keeping last occurrence
  async readRecords(userId, dataSourceId, type, { startDate = null, endDate = null } = {}) {
    const cacheDir = getCacheDir(userId, dataSourceId);
    const { ndjsonFile } = getFiles(cacheDir, type);
    if (!fs.existsSync(ndjsonFile)) {
      console.log(`📁 No ${type} cache file found: ${ndjsonFile}`);
      return [];
    }

    console.log(`📖 Reading ${type} records from cache: ${ndjsonFile}`);
    const content = fs.readFileSync(ndjsonFile, 'utf-8');
    const lines = content.split(/\n+/).filter(Boolean);
    const byId = new Map();

    const startDt = startDate ? new Date(startDate) : null;
    const endDt = endDate ? new Date(endDate) : null;

    for (const line of lines) {
      try {
        const rec = JSON.parse(line);
        const id = getRecordId(rec);
        const createdAt = rec.created_at || rec.order_date || rec.date_created || rec.createdAt;
        
        if (startDt || endDt) {
          if (!createdAt) continue;
          const dt = new Date(createdAt);
          if (startDt && dt < startDt) continue;
          if (endDt && dt > endDt) continue;
        }
        
        // Keep the latest occurrence by updated_at
        const prev = byId.get(id);
        const prevUpdated = prev?.updated_at || prev?.updatedAt || prev?.date_modified || '';
        const currUpdated = getRecordTimestamp(rec);
        
        if (!prev || (currUpdated && (!prevUpdated || new Date(currUpdated) >= new Date(prevUpdated)))) {
          byId.set(id, rec);
        }
      } catch (e) {
        // ignore bad line
        console.log(`⚠️ Skipping bad ${type} cache line: ${e.message}`);
      }
    }

    const results = Array.from(byId.values());
    console.log(`📦 Read ${results.length} unique ${type} records from cache`);
    return results;
  },

  // Get cache statistics
  async getCacheStats(userId, dataSourceId) {
    const cacheDir = getCacheDir(userId, dataSourceId);
    const stats = {};
    
    for (const type of ['orders', 'products', 'customers']) {
      const { ndjsonFile } = getFiles(cacheDir, type);
      if (fs.existsSync(ndjsonFile)) {
        try {
          const content = fs.readFileSync(ndjsonFile, 'utf-8');
          const lines = content.split(/\n+/).filter(Boolean);
          stats[type] = lines.length;
        } catch (e) {
          stats[type] = 0;
        }
      } else {
        stats[type] = 0;
      }
    }
    
    return stats;
  }
};

export default CsvStore;

