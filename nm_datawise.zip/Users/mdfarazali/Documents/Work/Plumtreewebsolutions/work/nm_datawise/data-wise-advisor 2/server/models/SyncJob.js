import mongoose from 'mongoose';

const syncJobSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  dataSource: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'DataSource',
    required: true,
    index: true
  },
  jobType: {
    type: String,
    required: true,
    enum: ['full_sync', 'incremental_sync', 'manual_sync', 'scheduled_sync'],
    default: 'manual_sync'
  },
  status: {
    type: String,
    enum: ['pending', 'running', 'completed', 'failed', 'cancelled'],
    default: 'pending',
    index: true
  },
  dataTypes: [{
    type: String,
    enum: [
      'orders', 'products', 'customers', 'inventory',
      'traffic', 'conversions', 'demographics', 'sessions',
      'campaigns', 'ads', 'insights', 'audiences',
      'email_campaigns', 'flows', 'profiles', 'events',
      'custom'
    ]
  }],
  progress: {
    totalRecords: {
      type: Number,
      default: 0
    },
    processedRecords: {
      type: Number,
      default: 0
    },
    successfulRecords: {
      type: Number,
      default: 0
    },
    failedRecords: {
      type: Number,
      default: 0
    },
    percentage: {
      type: Number,
      default: 0,
      min: 0,
      max: 100
    }
  },
  dateRange: {
    startDate: Date,
    endDate: Date
  },
  settings: {
    batchSize: {
      type: Number,
      default: 100
    },
    retryAttempts: {
      type: Number,
      default: 3
    },
    skipExisting: {
      type: Boolean,
      default: true
    }
  },
  startedAt: Date,
  completedAt: Date,
  duration: Number,
  error: {
    message: String,
    code: String,
    details: mongoose.Schema.Types.Mixed
  },
  logs: [{
    timestamp: {
      type: Date,
      default: Date.now
    },
    level: {
      type: String,
      enum: ['info', 'warning', 'error', 'debug'],
      default: 'info'
    },
    message: String,
    data: mongoose.Schema.Types.Mixed
  }],
  metadata: {
    apiCallsUsed: {
      type: Number,
      default: 0
    },
    dataVolume: {
      type: Number,
      default: 0
    },
    lastApiCall: Date,
    rateLimitHits: {
      type: Number,
      default: 0
    }
  }
}, {
  timestamps: true
});

// Indexes for efficient querying
syncJobSchema.index({ user: 1, dataSource: 1, createdAt: -1 });
syncJobSchema.index({ status: 1, createdAt: -1 });
syncJobSchema.index({ jobType: 1, status: 1 });

// Virtual for job duration calculation
syncJobSchema.virtual('durationFormatted').get(function() {
  if (!this.duration) return null;
  
  const seconds = Math.floor(this.duration / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  
  if (hours > 0) {
    return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
  } else if (minutes > 0) {
    return `${minutes}m ${seconds % 60}s`;
  } else {
    return `${seconds}s`;
  }
});

// Virtual for progress percentage
syncJobSchema.virtual('progressPercentage').get(function() {
  if (this.progress.totalRecords === 0) return 0;
  return Math.round((this.progress.processedRecords / this.progress.totalRecords) * 100);
});

// Instance methods
syncJobSchema.methods.start = function() {
  this.status = 'running';
  this.startedAt = new Date();
  this.addLog('info', 'Sync job started');
  return this.save();
};

syncJobSchema.methods.complete = function() {
  this.status = 'completed';
  this.completedAt = new Date();
  this.duration = this.completedAt - this.startedAt;
  this.progress.percentage = 100;
  this.addLog('info', 'Sync job completed successfully');
  return this.save();
};

syncJobSchema.methods.fail = function(error) {
  this.status = 'failed';
  this.completedAt = new Date();
  this.duration = this.completedAt - this.startedAt;
  this.error = {
    message: error.message,
    code: error.code || 'UNKNOWN_ERROR',
    details: error.details || error.stack
  };
  this.addLog('error', `Sync job failed: ${error.message}`, { error: error.details || error.stack });
  return this.save();
};

syncJobSchema.methods.cancel = function(reason = 'Cancelled by user') {
  this.status = 'cancelled';
  this.completedAt = new Date();
  this.duration = this.completedAt - this.startedAt;
  this.addLog('warning', `Sync job cancelled: ${reason}`);
  return this.save();
};

syncJobSchema.methods.updateProgress = function(processedRecords, successfulRecords = null, failedRecords = null) {
  this.progress.processedRecords = processedRecords;
  
  if (successfulRecords !== null) {
    this.progress.successfulRecords = successfulRecords;
  }
  
  if (failedRecords !== null) {
    this.progress.failedRecords = failedRecords;
  }
  
  if (this.progress.totalRecords > 0) {
    this.progress.percentage = Math.round((this.progress.processedRecords / this.progress.totalRecords) * 100);
  }
  
  return this.save();
};

syncJobSchema.methods.setTotalRecords = function(totalRecords) {
  this.progress.totalRecords = totalRecords;
  return this.save();
};

syncJobSchema.methods.addLog = function(level, message, data = null) {
  this.logs.push({
    timestamp: new Date(),
    level: level,
    message: message,
    data: data
  });
  
  if (this.logs.length > 100) {
    this.logs = this.logs.slice(-100);
  }
  
  return this;
};

syncJobSchema.methods.incrementApiCalls = function(count = 1) {
  this.metadata.apiCallsUsed += count;
  this.metadata.lastApiCall = new Date();
  return this;
};

syncJobSchema.methods.incrementRateLimitHits = function() {
  this.metadata.rateLimitHits += 1;
  return this;
};

// Static methods
syncJobSchema.statics.createJob = async function(userId, dataSourceId, jobType, dataTypes, options = {}) {
  const job = new this({
    user: userId,
    dataSource: dataSourceId,
    jobType: jobType,
    dataTypes: dataTypes,
    dateRange: options.dateRange || {},
    settings: {
      batchSize: options.batchSize || 100,
      retryAttempts: options.retryAttempts || 3,
      skipExisting: options.skipExisting !== false
    }
  });
  
  await job.save();
  job.addLog('info', 'Sync job created', { dataTypes, options });
  await job.save();
  
  return job;
};

syncJobSchema.statics.getActiveJobs = function(userId, dataSourceId = null) {
  const filter = {
    user: userId,
    status: { $in: ['pending', 'running'] }
  };
  
  if (dataSourceId) {
    filter.dataSource = dataSourceId;
  }
  
  return this.find(filter).sort({ createdAt: -1 });
};

syncJobSchema.statics.getJobHistory = function(userId, dataSourceId = null, limit = 50) {
  const filter = { user: userId };
  
  if (dataSourceId) {
    filter.dataSource = dataSourceId;
  }
  
  return this.find(filter)
    .populate('dataSource', 'name type')
    .sort({ createdAt: -1 })
    .limit(limit);
};

syncJobSchema.statics.getJobStats = async function(userId, dataSourceId = null) {
  const matchFilter = { user: new mongoose.Types.ObjectId(userId) };
  
  if (dataSourceId) {
    matchFilter.dataSource = new mongoose.Types.ObjectId(dataSourceId);
  }
  
  const pipeline = [
    { $match: matchFilter },
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 },
        totalRecords: { $sum: '$progress.totalRecords' },
        totalApiCalls: { $sum: '$metadata.apiCallsUsed' },
        avgDuration: { $avg: '$duration' }
      }
    }
  ];
  
  return this.aggregate(pipeline);
};

// Transform output
syncJobSchema.methods.toJSON = function() {
  const obj = this.toObject();
  
  // Add virtual properties
  obj.durationFormatted = this.durationFormatted;
  obj.progressPercentage = this.progressPercentage;
  
  // Remove sensitive or internal fields
  delete obj.__v;
  
  return obj;
};

const SyncJob = mongoose.model('SyncJob', syncJobSchema);

export default SyncJob; 