import { useState, useEffect } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Download, Clock, TrendingUp, AlertTriangle, CheckCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { fetchLeadTimeData, calculateLeadTimeMetrics, groupLeadTimeData, LeadTimeOrder } from "@/services/leadTimeService";
import { format, subMonths, parseISO, getMonth, getYear } from "date-fns";

const LeadTimePage = () => {
  const [groupBy, setGroupBy] = useState("putterType");
  const [showDelayedOnly, setShowDelayedOnly] = useState(false);
  const [showEarlyOnly, setShowEarlyOnly] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [orders, setOrders] = useState<LeadTimeOrder[]>([]);
  const [summaryData, setSummaryData] = useState({
    averageLeadTime: 0,
    medianLeadTime: 0,
    longestLeadTime: 0,
    shortestLeadTime: 0,
    totalOrders: 0
  });
  const [trendData, setTrendData] = useState<{ month: string; avgLeadTime: number; orders: number }[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // Fetch data for the last 6 months for better trend analysis
        const endDate = format(new Date(), 'yyyy-MM-dd');
        const sixMonthsAgo = subMonths(new Date(), 6);
        const startDate = format(sixMonthsAgo, 'yyyy-MM-dd');
        
        const data = await fetchLeadTimeData(startDate, endDate);
        setOrders(data);
        setSummaryData(calculateLeadTimeMetrics(data));
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch lead time data');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (orders.length > 0) {
      const monthlyData: { [key: string]: { totalLeadTime: number; count: number; } } = {};
      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

      orders.forEach(order => {
        const orderDate = parseISO(order.orderDate);
        const monthYearKey = `${months[getMonth(orderDate)]}-${getYear(orderDate)}`;
        
        if (!monthlyData[monthYearKey]) {
          monthlyData[monthYearKey] = { totalLeadTime: 0, count: 0 };
        }
        monthlyData[monthYearKey].totalLeadTime += order.leadTime;
        monthlyData[monthYearKey].count += 1;
      });

      const sortedMonths = Object.keys(monthlyData).sort((a, b) => {
        const [monthA, yearA] = a.split('-');
        const [monthB, yearB] = b.split('-');
        const dateA = new Date(parseInt(yearA), months.indexOf(monthA));
        const dateB = new Date(parseInt(yearB), months.indexOf(monthB));
        return dateA.getTime() - dateB.getTime();
      });

      const newTrendData = sortedMonths.map(key => ({
        month: key,
        avgLeadTime: monthlyData[key].totalLeadTime / monthlyData[key].count,
        orders: monthlyData[key].count,
      }));
      setTrendData(newTrendData);
    }
  }, [orders]);

  const leadTimeData = groupLeadTimeData(orders, groupBy);

  const filteredOrders = orders.filter(order => {
    if (showDelayedOnly) return order.status === 'Delayed';
    if (showEarlyOnly) return order.status === 'Early';
    return true;
  });

  const exportToCSV = () => {
    const headers = ['Order ID', 'Customer', 'Putter Type', 'Order Date', 'Ship Date', 'Lead Time', 'Status', 'Reason', 'Product Name', 'Shaft Type', 'Shaft Length', 'Putter Color', 'Grip Type', 'Putting Style', 'Hand', 'Lie Angle', 'Head Weight', 'Build Time'];
    const csvContent = [
      headers.join(','),
      ...filteredOrders.map(order => [
        order.orderId,
        order.customer,
        order.putterType,
        order.orderDate,
        order.shipDate,
        order.leadTime,
        order.status,
        order.reason || '',
        order.productName,
        order.shaftType,
        order.shaftLength,
        order.putterColor,
        order.gripType,
        order.puttingStyle,
        order.hand,
        order.lieAngle,
        order.headWeight,
        order.buildTime
      ].map(field => `"${String(field).replace(/"/g, '""')}"`).join(',')) // Wrap fields in quotes and escape internal quotes
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `lead-time-data-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    link.click();
  };

  const getGroupByOptions = () => [
    { value: "putterType", label: "Putter Type" },
    { value: "productName", label: "Product Name" },
    { value: "shaftType", label: "Shaft Type" },
    { value: "shaftLength", label: "Shaft Length" },
    { value: "putterColor", label: "Putter Color" },
    { value: "gripType", label: "Grip Type" },
    { value: "puttingStyle", label: "Putting Style" },
    { value: "hand", label: "Hand" },
    { value: "lieAngle", label: "Lie Angle" },
    { value: "headWeight", label: "Head Weight" },
    { value: "buildTime", label: "Putter Build Time" }
  ];

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Loading lead time data...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  if (error) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <div className="text-center text-red-600">
            <AlertTriangle className="h-12 w-12 mx-auto mb-4" />
            <p>Error loading lead time data: {error}</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Clock className="h-8 w-8" />
            Lead Time Analytics
          </h1>
          <p className="text-muted-foreground">
            Track production timelines and fulfillment performance across custom order variables.
          </p>
        </div>

        {/* Filter Controls */}
        <Card>
          <CardHeader>
            <CardTitle>Filters & Options</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center gap-2">
                <label className="text-sm font-medium">Group by:</label>
                <Select value={groupBy} onValueChange={setGroupBy}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {getGroupByOptions().map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="delayed-only"
                  checked={showDelayedOnly}
                  onCheckedChange={setShowDelayedOnly}
                />
                <Label htmlFor="delayed-only">Show delayed orders only</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="early-only"
                  checked={showEarlyOnly}
                  onCheckedChange={setShowEarlyOnly}
                />
                <Label htmlFor="early-only">Show early orders only</Label>
              </div>
              
              <Button onClick={exportToCSV} variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Lead Time</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.averageLeadTime.toFixed(1)} days</div>
              <p className="text-xs text-muted-foreground">Last 30 days</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Median Lead Time</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.medianLeadTime.toFixed(1)} days</div>
              <p className="text-xs text-muted-foreground">Last 30 days</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Longest Lead Time</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.longestLeadTime} days</div>
              <p className="text-xs text-muted-foreground">Last 30 days</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Shortest Lead Time</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.shortestLeadTime} days</div>
              <p className="text-xs text-muted-foreground">Last 30 days</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.totalOrders}</div>
              <p className="text-xs text-muted-foreground">Last 30 days</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="summary" className="space-y-4">
          <TabsList>
            <TabsTrigger value="summary">Lead Time Summary</TabsTrigger>
            <TabsTrigger value="trends">Trend Analysis</TabsTrigger>
            <TabsTrigger value="outliers">Outlier Orders</TabsTrigger>
          </TabsList>
          
          <TabsContent value="summary" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Lead Time by {getGroupByOptions().find(opt => opt.value === groupBy)?.label}</CardTitle>
                <CardDescription>
                  Performance metrics grouped by selected category
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Category</TableHead>
                      <TableHead>Average Lead Time</TableHead>
                      <TableHead>Median Lead Time</TableHead>
                      <TableHead>Order Count</TableHead>
                      <TableHead>Delayed Orders</TableHead>
                      <TableHead>Early Orders</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {leadTimeData.map((item, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{item.category}</TableCell>
                        <TableCell>{item.averageLeadTime.toFixed(1)} days</TableCell>
                        <TableCell>{item.medianLeadTime.toFixed(1)} days</TableCell>
                        <TableCell>{item.orderCount}</TableCell>
                        <TableCell>
                          <Badge variant="destructive">{item.delayedOrders}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="default">{item.earlyOrders}</Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trends" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Lead Time Trends</CardTitle>
                <CardDescription>
                  Monthly trend analysis of average lead times and order volume
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis yAxisId="left" label={{ value: 'Avg Lead Time (days)', angle: -90, position: 'insideLeft' }} />
                    <YAxis yAxisId="right" orientation="right" label={{ value: 'Order Count', angle: 90, position: 'insideRight' }} />
                    <Tooltip formatter={(value: number, name: string) => [`${value.toFixed(1)} ${name.includes('Time') ? 'days' : ''}`, name]} />
                    <Line yAxisId="left" type="monotone" dataKey="avgLeadTime" stroke="#8884d8" name="Avg Lead Time" />
                    <Line yAxisId="right" type="monotone" dataKey="orders" stroke="#82ca9d" name="Order Count" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="outliers" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Outlier Orders</CardTitle>
                <CardDescription>
                  Orders with exceptionally long or short lead times requiring attention
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order ID</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Putter Type</TableHead>
                      <TableHead>Order Date</TableHead>
                      <TableHead>Ship Date</TableHead>
                      <TableHead>Lead Time</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Reason</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredOrders.map((order) => (
                      <TableRow key={order.orderId}>
                        <TableCell className="font-medium">{order.orderId}</TableCell>
                        <TableCell>{order.customer}</TableCell>
                        <TableCell>{order.putterType}</TableCell>
                        <TableCell>{new Date(order.orderDate).toLocaleDateString()}</TableCell>
                        <TableCell>{new Date(order.shipDate).toLocaleDateString()}</TableCell>
                        <TableCell>{order.leadTime} days</TableCell>
                        <TableCell>
                          <Badge variant={order.status === "Delayed" ? "destructive" : "default"}>
                            {order.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{order.reason}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default LeadTimePage;
