import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, TrendingUp, Users, ShoppingCart, Target, Database } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export default function ConversionInsightsPage() {
  return (
    <AppLayout>
      <ConversionInsightsPageContent />
    </AppLayout>
  );
}

function ConversionInsightsPageContent() {
  // Initialize state to reflect sample data usage
  const [hasShopify] = useState<boolean>(false);
  const [checkingConnections] = useState(false);

  // Calculate insights from sample data
  const getConversionInsights = () => {
    return {
      topProducts: [
        { name: "Premium Headphones", revenue: 45000, conversionRate: 8.2 },
        { name: "Smart Watch", revenue: 38000, conversionRate: 6.1 },
        { name: "Wireless Earbuds", revenue: 32000, conversionRate: 5.8 },
      ],
      customerSegments: [
        { segment: "New Customers", count: 420, value: 65, conversion: 2.1 },
        { segment: "Returning Customers", count: 380, value: 85, conversion: 5.8 },
        { segment: "VIP Customers", count: 120, value: 150, conversion: 12.3 },
      ],
      funnelData: [
        { stage: "Visitors", count: 12500, percentage: 100 },
        { stage: "Add to Cart", count: 3750, percentage: 30 },
        { stage: "Checkout", count: 1875, percentage: 15 },
        { stage: "Purchase", count: 312, percentage: 2.5 },
      ]
    };
  };

  const { topProducts, customerSegments, funnelData } = getConversionInsights();

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const COLORS = ['#0967f5', '#6366f1', '#8b5cf6', '#a855f7'];

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Conversion Insights</h1>
        <p className="text-muted-foreground">
          Detailed analysis of your store's conversion performance
        </p>
      </div>

      {/* Data Source Alert */}
      <Alert className="bg-amber-50 border-amber-200 text-amber-800">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          You're currently viewing sample insights. Connect your Shopify store for real conversion data.
        </AlertDescription>
      </Alert>
      
      {/* Show data source badge */}
      <div className="flex justify-end">
        <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
          <Database className="h-3 w-3 mr-2" />
          Using Sample Data
        </Badge>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Target className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-muted-foreground">Conversion Rate</p>
                <p className="text-2xl font-bold">2.5%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <ShoppingCart className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-muted-foreground">Avg Order Value</p>
                <p className="text-2xl font-bold">{formatCurrency(83)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-muted-foreground">Total Customers</p>
                <p className="text-2xl font-bold">{(1200).toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <TrendingUp className="h-8 w-8 text-orange-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-muted-foreground">Revenue</p>
                <p className="text-2xl font-bold">{formatCurrency(100000)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Products Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Top Converting Products</CardTitle>
            <CardDescription>
              Products with highest conversion rates
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topProducts}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip formatter={(value, name) => [
                    name === 'revenue' ? formatCurrency(value as number) : `${value}%`,
                    name === 'revenue' ? 'Revenue' : 'Conversion Rate'
                  ]} />
                  <Legend />
                  <Bar dataKey="conversionRate" fill="#0967f5" name="Conversion Rate %" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Customer Segments */}
        <Card>
          <CardHeader>
            <CardTitle>Customer Segments</CardTitle>
            <CardDescription>
              Customer value distribution
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={customerSegments}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="count"
                    label={({ segment, percentage }) => `${segment} ${percentage}%`}
                  >
                    {customerSegments.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Conversion Funnel */}
      <Card>
        <CardHeader>
          <CardTitle>Conversion Funnel</CardTitle>
          <CardDescription>
            Customer journey from visitor to purchase
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={funnelData} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="stage" type="category" />
                <Tooltip formatter={(value) => [value.toLocaleString(), 'Count']} />
                <Bar dataKey="count" fill="#6366f1" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle>AI Recommendations</CardTitle>
          <CardDescription>
            Personalized suggestions based on your data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-start space-x-3 p-4 bg-amber-50 rounded-lg">
            <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-amber-900">Connect Your Store</h4>
              <p className="text-sm text-amber-700">Connect your Shopify store to get personalized recommendations based on your actual data.</p>
              <Button size="sm" className="mt-2" onClick={() => window.location.href = '/sources'}>
                Connect Shopify
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
