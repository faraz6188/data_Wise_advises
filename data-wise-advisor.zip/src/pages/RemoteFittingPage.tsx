import { useState, useEffect, useMemo } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Download, Target, TrendingUp, Users, Clock, ShoppingCart, AlertTriangle } from "lucide-react";
import DataSourceSelector from "@/components/ui/data-source-selector";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

import { fetchRemoteFittingData, fetchRemoteFittingDataSources, type RemoteFittingData, type DataSource } from "@/services/remoteFittingService";


const RemoteFittingPage = () => {
  const [dateFilter, setDateFilter] = useState("week");
  const [selectedSubmission, setSelectedSubmission] = useState<string | null>(null);
  const [selectedDataSource, setSelectedDataSource] = useState<DataSource | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submissions, setSubmissions] = useState<RemoteFittingData[]>([]);
  const [summaryData, setSummaryData] = useState({
    totalSubmissions: 0,
    purchaseRate: 0,
    averageTimeToPurchase: 0,
    topPuttingStyle: "-"
  });

  useEffect(() => {
    if (selectedDataSource) {
      loadFittingData(selectedDataSource._id);
    }
  }, [selectedDataSource]);

  const loadFittingData = async (dataSourceId: string) => {
    try {
      setLoading(true);
      const data = await fetchRemoteFittingData(dataSourceId);
      setSubmissions(data);
      
      // Calculate summary data
      const purchased = data.filter(d => d.purchased);
      const purchaseRate = (purchased.length / data.length) * 100;
      const avgTimeToPurchase = purchased.reduce((acc, curr) => acc + (curr.timeToPurchase || 0), 0) / purchased.length;
      
      // Calculate top putting style
      const styles = data.reduce((acc, curr) => {
        acc[curr.puttingStyle] = (acc[curr.puttingStyle] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      const topStyle = Object.entries(styles).sort((a, b) => b[1] - a[1])[0][0];

      setSummaryData({
        totalSubmissions: data.length,
        purchaseRate: Math.round(purchaseRate * 10) / 10,
        averageTimeToPurchase: Math.round(avgTimeToPurchase * 10) / 10,
        topPuttingStyle: topStyle
      });

      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load fitting data');
    } finally {
      setLoading(false);
    }
  };

  const handleDataSourceChange = (dataSourceId: string, dataSource: DataSource | null) => {
    setSelectedDataSource(dataSource);
  };

  // Use the submissions data directly
  const submissionsData = submissions;

  const timeToPurchaseData = useMemo(() => {
    const ranges = {
      "1-2": { min: 1, max: 2, count: 0 },
      "3-5": { min: 3, max: 5, count: 0 },
      "6-10": { min: 6, max: 10, count: 0 },
      "11-15": { min: 11, max: 15, count: 0 },
      "16+": { min: 16, max: Infinity, count: 0 }
    };

    submissions.forEach(submission => {
      if (submission.timeToPurchase) {
        const range = Object.entries(ranges).find(([_, { min, max }]) => 
          submission.timeToPurchase! >= min && submission.timeToPurchase! <= max
        );
        if (range) {
          ranges[range[0]].count++;
        }
      }
    });

    return Object.entries(ranges).map(([days, { count }]) => ({ days, count }));
  }, [submissions]);

  const exportToCSV = () => {
    if (!submissions.length) return;
    
    const headers = ['Date', 'Putting Style', 'Putter Type', 'Length', 'Lie', 'Loft', 'Purchase Status', 'Time to Purchase', 'Customer Email'];
    const csvContent = [
      headers.join(','),
      ...submissions.map(submission => [
        new Date(submission.date).toLocaleDateString(),
        submission.puttingStyle,
        submission.putterType,
        submission.length,
        submission.lie,
        submission.loft,
        submission.purchased ? 'Purchased' : 'No Purchase',
        submission.timeToPurchase || '-',
        submission.customerEmail
      ].map(field => `"${String(field).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `fitting-data-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  if (!selectedDataSource) {
    return (
      <AppLayout>
        <div className="space-y-6">
          <div className="flex flex-col space-y-2">
            <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
              <Target className="h-8 w-8" />
              Remote Fitting Analytics
            </h1>
            <p className="text-muted-foreground">
              Select a data source to view fitting analytics
            </p>
          </div>
          <Card>
            <CardHeader>
              <CardTitle>Select Data Source</CardTitle>
              <CardDescription>Choose a CSV data source containing fitting data</CardDescription>
            </CardHeader>
            <CardContent>
              <DataSourceSelector
                filterTypes={['csv']}
                placeholder="Select fitting data source"
                onDataSourceChange={handleDataSourceChange}
                className="w-[250px]"
              />
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  if (loading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-muted-foreground">Loading fitting data...</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  if (error) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-full">
          <div className="text-center text-red-600">
            <AlertTriangle className="h-12 w-12 mx-auto mb-4" />
            <p>Error loading fitting data: {error}</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => setSelectedDataSource(null)}
            >
              Change Data Source
            </Button>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Target className="h-8 w-8" />
            Remote Fitting Analytics
          </h1>
          <p className="text-muted-foreground">
            Track and analyze fitting data submissions for insights into user behavior and conversion rates.
          </p>
        </div>

        {/* Filter Controls */}
        <Card>
          <CardHeader>
            <CardTitle>Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 items-center flex-wrap">
              <div className="flex items-center gap-2">
                <label className="text-sm font-medium">Data Source:</label>
                <DataSourceSelector
                  filterTypes={['csv']}
                  placeholder="Select fitting data source"
                  onDataSourceChange={handleDataSourceChange}
                  className="w-[250px]"
                />
              </div>
              <div className="flex items-center gap-2">
                <label className="text-sm font-medium">Time Period:</label>
                <Select value={dateFilter} onValueChange={setDateFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="week">Week to Date</SelectItem>
                    <SelectItem value="month">Month to Date</SelectItem>
                    <SelectItem value="year">Year to Date</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={exportToCSV} variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Submissions</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.totalSubmissions}</div>
              <p className="text-xs text-muted-foreground">From selected data source</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Purchase Rate</CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.purchaseRate}%</div>
              <p className="text-xs text-muted-foreground">Conversion rate</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg. Time to Purchase</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.averageTimeToPurchase} days</div>
              <p className="text-xs text-muted-foreground">For converted leads</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Top Putting Style</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{summaryData.topPuttingStyle}</div>
              <p className="text-xs text-muted-foreground">Most common style</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="table" className="space-y-4">
          <TabsList>
            <TabsTrigger value="table">Submissions Data</TabsTrigger>
            <TabsTrigger value="charts">Time to Purchase</TabsTrigger>
          </TabsList>
          
          <TabsContent value="table" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Fitting Submissions</CardTitle>
                <CardDescription>
                  Detailed view of all fitting submissions with sortable columns
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Putting Style</TableHead>
                      <TableHead>Putter Type</TableHead>
                      <TableHead>Length</TableHead>
                      <TableHead>Lie</TableHead>
                      <TableHead>Loft</TableHead>
                      <TableHead>Purchase Status</TableHead>
                      <TableHead>Time to Purchase</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {submissionsData.map((submission) => (
                      <TableRow key={submission.id}>
                        <TableCell>{new Date(submission.date).toLocaleDateString()}</TableCell>
                        <TableCell>{submission.puttingStyle}</TableCell>
                        <TableCell>{submission.putterType}</TableCell>
                        <TableCell>{submission.length}</TableCell>
                        <TableCell>{submission.lie}</TableCell>
                        <TableCell>{submission.loft}</TableCell>
                        <TableCell>
                          <Badge variant={submission.purchased ? "default" : "secondary"}>
                            {submission.purchased ? "Purchased" : "No Purchase"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {submission.timeToPurchase ? `${submission.timeToPurchase} days` : "-"}
                        </TableCell>
                        <TableCell>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => setSelectedSubmission(submission.id)}
                          >
                            View Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="charts" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Time to Purchase Distribution</CardTitle>
                <CardDescription>
                  Analysis of how long customers take to purchase after fitting submission
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={timeToPurchaseData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="days" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default RemoteFittingPage;
