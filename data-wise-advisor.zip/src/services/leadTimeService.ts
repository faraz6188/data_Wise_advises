import axios from 'axios';

const API_BASE_URL = 'https://ba8c11ad2a.nxcli.net/sites/lab-orderexport/api';
const API_KEY = 'nS1JpbKYAyNBeC5pGzCwwz33EuG7Zfv3';

export interface RawLeadTimeOrder {
  id: number;
  store_name: string;
  order_id: number;
  order_number: string;
  order_date: string;
  fulfillment_date: string;
  fulfillment_status: string;
  product_name: string;
  shaft: string;
  shaft_lean: string;
  shaft_length: string;
  putter_color: string;
  grip_selection: string;
  headcover_selection: string;
  putting_style: string;
  hand: string;
  lie_angle: string;
  alignment_mark: string;
  alignment_mark_front: string;
  alignment_mark_back: string;
  head_weight: string;
  putter_build_time: string;
  insert: string;
  player_name: string;
  lead_time: string;
  created_at: string;
  updated_at: string;
}

export interface LeadTimeOrder {
  orderId: string;
  customer: string;
  putterType: string;
  orderDate: string;
  shipDate: string;
  leadTime: number;
  status: 'Delayed' | 'Early' | 'On Time';
  reason?: string;
  productName: string;
  shaftType: string;
  shaftLength: string;
  putterColor: string;
  gripType: string;
  puttingStyle: string;
  hand: string;
  lieAngle: string;
  headWeight: string;
  buildTime: string;
}

export interface LeadTimeSummary {
  averageLeadTime: number;
  medianLeadTime: number;
  longestLeadTime: number;
  shortestLeadTime: number;
  totalOrders: number;
  byProductType: Record<string, number>;
  byPuttingStyle: Record<string, number>;
  byHand: Record<string, number>;
  byBuildTime: Record<string, number>;
}

export interface LeadTimeData {
  category: string;
  averageLeadTime: number;
  medianLeadTime: number;
  orderCount: number;
  delayedOrders: number;
  earlyOrders: number;
}

const parseLeadTime = (leadTimeStr: string): number => {
  const hoursMatch = leadTimeStr.match(/(\d+)\s*hours?/);
  const daysMatch = leadTimeStr.match(/(\d+)\s*days?/);
  
  if (hoursMatch) {
    return parseInt(hoursMatch[1]) / 24; // Convert hours to days
  }
  if (daysMatch) {
    return parseInt(daysMatch[1]);
  }
  return 0;
};

const determineOrderStatus = (leadTime: number): 'Delayed' | 'Early' | 'On Time' => {
  if (leadTime > 1) return 'Delayed';
  if (leadTime < 0.5) return 'Early';
  return 'On Time';
};

const transformOrder = (rawOrder: RawLeadTimeOrder): LeadTimeOrder => {
  const leadTime = parseLeadTime(rawOrder.lead_time);
  
  return {
    orderId: rawOrder.order_number,
    customer: rawOrder.player_name || 'Anonymous',
    putterType: rawOrder.product_name,
    orderDate: rawOrder.order_date,
    shipDate: rawOrder.fulfillment_date,
    leadTime,
    status: determineOrderStatus(leadTime),
    productName: rawOrder.product_name,
    shaftType: rawOrder.shaft,
    shaftLength: rawOrder.shaft_length,
    putterColor: rawOrder.putter_color,
    gripType: rawOrder.grip_selection,
    puttingStyle: rawOrder.putting_style,
    hand: rawOrder.hand,
    lieAngle: rawOrder.lie_angle,
    headWeight: rawOrder.head_weight,
    buildTime: rawOrder.putter_build_time
  };
};

export const fetchLeadTimeData = async (startDate: string, endDate: string) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/ordersleadtime`, {
      params: {
        startDate,
        endDate,
        api_key: API_KEY
      },
      headers: {
        'X-API-KEY': API_KEY
      }
    });
    
    if (response.data?.data) {
      return response.data.data.map(transformOrder);
    }
    return [];
  } catch (error) {
    console.error('Error fetching lead time data:', error);
    return [];
  }
};

export const calculateLeadTimeMetrics = (orders: LeadTimeOrder[]): LeadTimeSummary => {
  if (!orders.length) {
    return {
      averageLeadTime: 0,
      medianLeadTime: 0,
      longestLeadTime: 0,
      shortestLeadTime: 0,
      totalOrders: 0,
      byProductType: {},
      byPuttingStyle: {},
      byHand: {},
      byBuildTime: {}
    };
  }

  const leadTimes = orders.map(order => order.leadTime).sort((a, b) => a - b);
  const totalLeadTime = leadTimes.reduce((sum, time) => sum + time, 0);
  
  // Calculate metrics by category
  const byProductType: Record<string, number> = {};
  const byPuttingStyle: Record<string, number> = {};
  const byHand: Record<string, number> = {};
  const byBuildTime: Record<string, number> = {};

  orders.forEach(order => {
    byProductType[order.productName] = (byProductType[order.productName] || 0) + 1;
    byPuttingStyle[order.puttingStyle] = (byPuttingStyle[order.puttingStyle] || 0) + 1;
    byHand[order.hand] = (byHand[order.hand] || 0) + 1;
    byBuildTime[order.buildTime] = (byBuildTime[order.buildTime] || 0) + 1;
  });

  return {
    averageLeadTime: totalLeadTime / orders.length,
    medianLeadTime: leadTimes[Math.floor(orders.length / 2)],
    longestLeadTime: Math.max(...leadTimes),
    shortestLeadTime: Math.min(...leadTimes),
    totalOrders: orders.length,
    byProductType,
    byPuttingStyle,
    byHand,
    byBuildTime
  };
};

export const groupLeadTimeData = (orders: LeadTimeOrder[], groupBy: string): LeadTimeData[] => {
  const groupedData = new Map<string, LeadTimeOrder[]>();
  
  orders.forEach(order => {
    const key = order[groupBy as keyof LeadTimeOrder] as string;
    if (!groupedData.has(key)) {
      groupedData.set(key, []);
    }
    groupedData.get(key)?.push(order);
  });

  return Array.from(groupedData.entries()).map(([category, categoryOrders]) => {
    const leadTimes = categoryOrders.map(order => order.leadTime);
    const totalLeadTime = leadTimes.reduce((sum, time) => sum + time, 0);
    
    return {
      category,
      averageLeadTime: totalLeadTime / categoryOrders.length,
      medianLeadTime: leadTimes.sort((a, b) => a - b)[Math.floor(categoryOrders.length / 2)],
      orderCount: categoryOrders.length,
      delayedOrders: categoryOrders.filter(order => order.status === 'Delayed').length,
      earlyOrders: categoryOrders.filter(order => order.status === 'Early').length
    };
  });
}; 