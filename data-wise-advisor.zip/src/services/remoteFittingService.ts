import { API_ENDPOINTS } from "@/config/api";

export interface RemoteFittingData {
  id: string;
  date: string;
  puttingStyle: string;
  putterType: string;
  length: string;
  lie: string;
  loft: string;
  purchased: boolean;
  timeToPurchase: number | null;
  customerEmail: string;
}

export interface DataSource {
  _id: string;
  name: string;
  type: string;
  status: 'connected' | 'disconnected' | 'error' | 'pending';
  metadata?: {
    lastUpdated?: string;
    totalRecords?: number;
  };
}

export const fetchRemoteFittingDataSources = async (): Promise<DataSource[]> => {
  const token = localStorage.getItem('token');
  if (!token) {
    throw new Error('Authentication required');
  }

  const response = await fetch(`${API_ENDPOINTS.dataSources}?type=csv`, {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });

  if (!response.ok) {
    throw new Error('Failed to fetch data sources');
  }

  const dataSources = await response.json();
  return dataSources.filter((source: DataSource) => 
    source.name.toLowerCase().includes('fitting') || 
    source.type === 'csv'
  );
};

export const fetchRemoteFittingData = async (dataSourceId: string): Promise<RemoteFittingData[]> => {
  const token = localStorage.getItem('token');
  if (!token) {
    throw new Error('Authentication required');
  }

  const response = await fetch(`${API_ENDPOINTS.dataSources}/${dataSourceId}/data`, {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });

  if (!response.ok) {
    throw new Error('Failed to fetch fitting data');
  }

  return await response.json();
};
