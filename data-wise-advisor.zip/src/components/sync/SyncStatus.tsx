import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Loader2, Play, Pause, Database, Clock, CheckCircle, XCircle, AlertCircle, Calendar, Settings } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DataSource {
  _id: string;
  name: string;
  type: string;
  status: string;
  metadata: {
    lastSyncAt?: string;
    lastSyncStatus?: string;
    totalRecords?: number;
  };
}

interface SyncJob {
  _id: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  progress: {
    totalRecords: number;
    processedRecords: number;
    percentage: number;
  };
  dataTypes: string[];
  startedAt?: string;
  completedAt?: string;
  error?: {
    message: string;
  };
}

interface SyncStatusProps {
  dataSource: DataSource;
  onSyncComplete?: () => void;
}

const DATE_PRESETS = [
  { label: 'Last 7 days', days: 7 },
  { label: 'Last 30 days', days: 30 },
  { label: 'Last 3 months', days: 90 },
  { label: 'Last 6 months', days: 180 },
  { label: 'Last year', days: 365 },
  { label: 'All time', days: null }
];

export const SyncStatus: React.FC<SyncStatusProps> = ({ dataSource, onSyncComplete }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [activeJob, setActiveJob] = useState<SyncJob | null>(null);
  const [dataStats, setDataStats] = useState<any[]>([]);
  const [showSyncOptions, setShowSyncOptions] = useState(false);
  const [syncOptions, setSyncOptions] = useState({
    preset: 'last-30-days',
    startDate: '',
    endDate: '',
    maxRequests: 200
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchActiveJobs();
    fetchDataStats();
  }, [dataSource._id]);

  // Set default date range for last 30 days
  useEffect(() => {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);
    
    setSyncOptions(prev => ({
      ...prev,
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0]
    }));
  }, []);

  // Poll for active job updates every 2 seconds when there's a running job
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (activeJob && activeJob.status === 'running') {
      console.log('🔄 Starting sync progress polling...');
      interval = setInterval(() => {
        console.log('📊 Polling for sync progress updates...');
        fetchActiveJobs();
      }, 2000); // Poll every 2 seconds
    }
    
    return () => {
      if (interval) {
        console.log('⏹️ Stopping sync progress polling');
        clearInterval(interval);
      }
    };
  }, [activeJob?.status]);

  // Call onSyncComplete when job completes
  useEffect(() => {
    if (activeJob?.status === 'completed' && onSyncComplete) {
      console.log('✅ Sync completed, calling onSyncComplete callback');
      onSyncComplete();
      fetchDataStats(); // Refresh data stats
    }
  }, [activeJob?.status, onSyncComplete]);

  const fetchActiveJobs = async () => {
    try {
      const response = await fetch('/api/sync/jobs/active', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });

      if (response.ok) {
        const jobs = await response.json();
        const job = jobs.find((j: any) => j.dataSource._id === dataSource._id);
        
        // Log progress updates for debugging
        if (job && job.status === 'running') {
          console.log(`📊 Sync progress: ${job.progress.processedRecords}/${job.progress.totalRecords} (${job.progress.percentage}%)`);
        }
        
        setActiveJob(job || null);
      }
    } catch (error) {
      console.error('Error fetching active jobs:', error);
    }
  };

  const fetchDataStats = async () => {
    try {
      const response = await fetch(`/api/sync/${dataSource._id}/stats`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setDataStats(data.stats);
      }
    } catch (error) {
      console.error('Error fetching data stats:', error);
    }
  };

  const handlePresetChange = (preset: string) => {
    setSyncOptions(prev => ({ ...prev, preset }));
    
    const endDate = new Date();
    let startDate = new Date();
    
    switch (preset) {
      case 'last-7-days':
        startDate.setDate(startDate.getDate() - 7);
        break;
      case 'last-30-days':
        startDate.setDate(startDate.getDate() - 30);
        break;
      case 'last-3-months':
        startDate.setMonth(startDate.getMonth() - 3);
        break;
      case 'last-6-months':
        startDate.setMonth(startDate.getMonth() - 6);
        break;
      case 'last-year':
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
      case 'all-time':
        startDate = new Date('2020-01-01'); // Set a reasonable start date
        break;
      case 'custom':
        return; // Don't update dates for custom
    }
    
    setSyncOptions(prev => ({
      ...prev,
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0]
    }));
  };

  const triggerSync = async (useOptions = false) => {
    if (isLoading || activeJob) return;

    setIsLoading(true);
    try {
      const requestBody: any = {
        jobType: 'manual_sync'
      };

      if (useOptions) {
        requestBody.startDate = syncOptions.startDate;
        requestBody.endDate = syncOptions.endDate;
        requestBody.maxRequests = syncOptions.maxRequests;
      }

      const response = await fetch(`/api/sync/${dataSource._id}/sync`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(requestBody)
      });

      if (response.ok) {
        const dateRange = useOptions ? 
          ` (${syncOptions.startDate} to ${syncOptions.endDate})` : '';
        
        toast({
          title: 'Sync Started',
          description: `Data synchronization has been initiated${dateRange}`,
        });
        
        setShowSyncOptions(false);
        
        // Start polling immediately after sync starts
        setTimeout(() => {
          fetchActiveJobs();
          console.log('🔄 Sync started, beginning progress monitoring...');
        }, 1000);
      } else {
        const error = await response.json();
        throw new Error(error.message);
      }
    } catch (error) {
      console.error('Error triggering sync:', error);
      toast({
        title: 'Sync Failed',
        description: error instanceof Error ? error.message : 'Failed to start sync',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'running':
        return <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return <Database className="h-4 w-4 text-gray-400" />;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Sync Status - {dataSource.name}
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => triggerSync(false)}
              disabled={isLoading || dataSource.status !== 'connected' || !!activeJob}
              size="sm"
              variant="outline"
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              ) : (
                <Play className="h-4 w-4 mr-1" />
              )}
              Quick Sync
            </Button>
            
            <Dialog open={showSyncOptions} onOpenChange={setShowSyncOptions}>
              <DialogTrigger asChild>
                <Button
                  disabled={isLoading || dataSource.status !== 'connected' || !!activeJob}
                  size="sm"
                >
                  <Settings className="h-4 w-4 mr-1" />
                  Sync Options
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Sync Options
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Date Range</Label>
                    <Select value={syncOptions.preset} onValueChange={handlePresetChange}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="last-7-days">Last 7 days</SelectItem>
                        <SelectItem value="last-30-days">Last 30 days</SelectItem>
                        <SelectItem value="last-3-months">Last 3 months</SelectItem>
                        <SelectItem value="last-6-months">Last 6 months</SelectItem>
                        <SelectItem value="last-year">Last year</SelectItem>
                        <SelectItem value="all-time">All time</SelectItem>
                        <SelectItem value="custom">Custom range</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-2">
                      <Label>Start Date</Label>
                      <Input
                        type="date"
                        value={syncOptions.startDate}
                        onChange={(e) => setSyncOptions(prev => ({ 
                          ...prev, 
                          startDate: e.target.value,
                          preset: 'custom'
                        }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>End Date</Label>
                      <Input
                        type="date"
                        value={syncOptions.endDate}
                        onChange={(e) => setSyncOptions(prev => ({ 
                          ...prev, 
                          endDate: e.target.value,
                          preset: 'custom'
                        }))}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Max API Requests</Label>
                    <Select 
                      value={syncOptions.maxRequests.toString()} 
                      onValueChange={(value) => setSyncOptions(prev => ({ 
                        ...prev, 
                        maxRequests: parseInt(value) 
                      }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="100">100 (up to ~25k records)</SelectItem>
                        <SelectItem value="200">200 (up to ~50k records)</SelectItem>
                        <SelectItem value="400">400 (up to ~100k records)</SelectItem>
                        <SelectItem value="800">800 (up to ~200k records)</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      Higher limits take longer but sync more data
                    </p>
                  </div>
                  
                  <div className="bg-blue-50 p-3 rounded-md">
                    <p className="text-sm text-blue-700">
                      <strong>Tip:</strong> For large stores, start with "Last 30 days" 
                      to sync recent data quickly, then run "All time" during off-hours.
                    </p>
                  </div>
                  
                  <Button 
                    onClick={() => triggerSync(true)} 
                    className="w-full"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Play className="h-4 w-4 mr-2" />
                    )}
                    Start Sync
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Active Job Progress */}
        {activeJob && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Current Sync</span>
              <Badge>
                {getStatusIcon(activeJob.status)}
                <span className="ml-1 capitalize">{activeJob.status}</span>
              </Badge>
            </div>
            {activeJob.status === 'running' && (
              <div className="space-y-1">
                <Progress value={activeJob.progress.percentage} />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{activeJob.progress.processedRecords} / {activeJob.progress.totalRecords} records</span>
                  <span>{activeJob.progress.percentage}%</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Data Statistics */}
        {dataStats.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Synced Data</h4>
            <div className="grid grid-cols-2 gap-2">
              {dataStats.map((stat) => (
                <div key={stat.dataType} className="bg-muted p-2 rounded text-xs">
                  <div className="font-medium capitalize">{stat.dataType}</div>
                  <div className="text-muted-foreground">
                    {stat.count.toLocaleString()} records
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Last Sync Info */}
        {dataSource.metadata.lastSyncAt && (
          <div className="space-y-1">
            <div className="flex items-center justify-between text-sm">
              <span>Last Sync:</span>
              <span className="text-muted-foreground">
                {formatDate(dataSource.metadata.lastSyncAt)}
              </span>
            </div>
            {dataSource.metadata.totalRecords && (
              <div className="flex items-center justify-between text-sm">
                <span>Total Records:</span>
                <span className="text-muted-foreground">
                  {dataSource.metadata.totalRecords.toLocaleString()}
                </span>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}; 