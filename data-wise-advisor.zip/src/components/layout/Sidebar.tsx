import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import {
  Home,
  MessageSquare,
  BarChart,
  Upload,
  Database,
  Settings,
  LogOut,
  User,
  TrendingUp,
  AlertTriangle,
  Activity,
  Target,
  Clock,
  ShoppingBag,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useAuth } from "../../contexts/AuthContext";

const Sidebar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const navItems = [
    {
      name: "Home",
      icon: Home,
      path: "/",
    },
    {
      name: "AI Chat",
      icon: MessageSquare,
      path: "/chat",
    },
    {
      name: "Visualize",
      icon: BarChart,
      path: "/visualize",
    },
    {
      header: "Conversion",
    },
    {
      name: "Insights",
      icon: TrendingUp,
      path: "/insights",
    },
    {
      name: "Alerts",
      icon: AlertTriangle,
      path: "/alerts",
    },
    {
      name: "Opportunities",
      icon: Activity,
      path: "/opportunities",
    },
    {
      header: "Analytics",
    },
    {
      name: "Remote Fitting Analytics",
      icon: Target,
      path: "/remote-fitting",
    },
    {
      name: "Lead Time Analytics",
      icon: Clock,
      path: "/lead-time",
    },
    {
      header: "Data Management",
    },
    {
      name: "Upload Data",
      icon: Upload,
      path: "/upload",
    },
    {
      name: "Data Sources",
      icon: Database,
      path: "/sources",
    },
    {
      name: "Settings",
      icon: Settings,
      path: "/settings",
      position: "bottom",
    },
  ];

  const handleLogout = () => {
    logout();
  };

  // Get user initials for avatar
  const getUserInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <aside className="bg-sidebar w-64 h-screen flex flex-col border-r border-gray-800">
      <div className="p-6">
        <div className="flex items-center space-x-2">
          <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center">
            <span className="font-bold text-white">DW</span>
          </div>
          <h1 className="text-xl font-bold text-white">Data Wise Advisor</h1>
        </div>
      </div>

      <div className="text-xs uppercase text-gray-400 px-6 mb-4">Dashboard</div>

      <nav className="flex-1 px-3 space-y-1">
        {navItems.map((item, index) => {
          if (item.header) {
            return (
              <div key={index} className="text-xs uppercase text-gray-400 px-3 pt-6 pb-2">
                {item.header}
              </div>
            );
          }

          if (item.position === "bottom") {
            return null;
          }

          const isActive = location.pathname === item.path;
          const Icon = item.icon;

          return (
            <Link
              key={index}
              to={item.path}
              className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors",
                isActive
                  ? "bg-sidebar-accent text-white"
                  : "text-gray-300 hover:bg-sidebar-accent/50 hover:text-white"
              )}
            >
              <Icon className="mr-3 h-5 w-5" />
              {item.name}
            </Link>
          );
        })}
      </nav>

      <div className="p-3 mt-auto flex flex-col gap-2">
        {navItems
          .filter((item) => item.position === "bottom")
          .map((item, index) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;

            return (
              <Link
                key={index}
                to={item.path}
                className={cn(
                  "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors",
                  isActive
                    ? "bg-sidebar-accent text-white"
                    : "text-gray-300 hover:bg-sidebar-accent/50 hover:text-white"
                )}
              >
                <Icon className="mr-3 h-5 w-5" />
                {item.name}
              </Link>
            );
          })}
        {/* User dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-md bg-sidebar-accent/80 hover:bg-sidebar-accent text-white transition-colors">
              <Avatar>
                <AvatarFallback>{user ? getUserInitials(user.name) : 'U'}</AvatarFallback>
              </Avatar>
              <span className="flex-1 text-left">{user?.name || 'User'}</span>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel className="flex items-center gap-2">
              <User className="h-4 w-4" />
              {user?.name || 'User'}
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <div className="px-3 py-1 text-xs text-muted-foreground">
              <div>Email: <span className="font-medium">{user?.email}</span></div>
              <div>Role: <span className="font-medium capitalize">{user?.role}</span></div>
              {user?.profile?.company && (
                <div>Company: <span className="font-medium">{user.profile.company}</span></div>
              )}
            </div>
            {user?.shopifyStores && user.shopifyStores.length > 0 && (
              <>
                <DropdownMenuSeparator />
                <div className="px-3 py-1 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1 mb-1">
                    <ShoppingBag className="h-3 w-3" />
                    <span className="font-medium">Shopify Stores:</span>
                  </div>
                  {user.shopifyStores.slice(0, 2).map((store, index) => (
                    <div key={index} className="ml-4 text-xs">
                      • {store.storeName}
                    </div>
                  ))}
                  {user.shopifyStores.length > 2 && (
                    <div className="ml-4 text-xs">
                      ... and {user.shopifyStores.length - 2} more
                    </div>
                  )}
                </div>
              </>
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} className="text-red-600 cursor-pointer">
              <LogOut className="h-4 w-4 mr-2" /> Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </aside>
  );
};

export default Sidebar;
