# Persistent Data Storage System

## Overview

The Data Wise Advisor now includes a comprehensive persistent data storage system that stores synced data from all connected data sources locally in MongoDB. This eliminates the need to fetch data from external APIs every time and provides better performance, offline capabilities, and data preservation.

## Architecture

### Database Models

#### 1. SyncedData Model
Stores the actual synced data from external sources with metadata for tracking and management.

#### 2. SyncJob Model  
Tracks synchronization operations with progress monitoring and error handling.

### Services

#### 1. SyncService
Handles the synchronization process for all data source types.

#### 2. Enhanced EcommerceService
Now supports both API and synced data with smart fallback logic.

## API Endpoints

### Sync Operations
- `POST /api/sync/:dataSourceId/sync` - Trigger sync for a data source
- `GET /api/sync/jobs/:jobId` - Get sync job status
- `GET /api/sync/:dataSourceId/history` - Get sync history
- `GET /api/sync/jobs/active` - Get active sync jobs

### Data Retrieval
- `GET /api/sync/:dataSourceId/data/:dataType` - Get synced data by type
- `GET /api/sync/:dataSourceId/stats` - Get data statistics
- `GET /api/sync/:dataSourceId/metrics` - Get calculated metrics from synced data

## Key Features

1. **Smart Data Fetching** - Prioritizes synced data, falls back to API
2. **Incremental Updates** - Efficient upsert operations
3. **Data Lifecycle Management** - Automatic cleanup and archiving
4. **Performance Optimization** - Efficient indexes and batch processing
5. **Error Handling & Monitoring** - Comprehensive logging and status tracking

## Benefits

- **Performance**: Faster data access and reduced API calls
- **Reliability**: Data availability during API outages
- **Cost Efficiency**: Reduced API costs and bandwidth usage
- **Analytics Capabilities**: Historical data preservation
- **Scalability**: Handles large datasets efficiently

## Configuration

### Environment Variables
```env
MONGODB_URI=mongodb://localhost:27017/data-wise-advisor
```

### Sync Settings (Per Data Source)
- **Sync Frequency**: real_time, hourly, daily, weekly
- **Auto Sync**: Enable/disable automatic synchronization
- **Data Types**: Select which data types to sync
- **Batch Size**: Number of records to process per batch

## Monitoring & Maintenance

### Health Checks
- Monitor sync job success rates
- Track API usage and rate limits
- Database storage usage monitoring

### Data Cleanup
- Automatic archiving of old data (90 days default)
- Manual cleanup commands available
- Storage optimization recommendations

This persistent storage system provides a robust foundation for handling data from any connected source while maintaining performance, reliability, and scalability. 