import fetch from 'node-fetch';
import DataSource from '../models/DataSource.js';
import SyncedData from '../models/SyncedData.js';

const SHOPIFY_API_VERSION = "2023-10";
const BIGCOMMERCE_API_VERSION = "v2";

// Helper function to get user's data source by type
async function getDataSource(userId, type) {
  console.log(`🔍 Looking for ${type} data source for user ${userId}`);
  
  const dataSource = await DataSource.findOne({
    user: userId,
    type: type,
    isActive: true,
    status: 'connected'
  });
  
  if (!dataSource) {
    console.log(`❌ ${type} data source not found for user ${userId}`);
    throw new Error(`${type.charAt(0).toUpperCase() + type.slice(1)} data source not found or not connected. Please connect your ${type} store in Data Sources.`);
  }
  
  console.log(`✅ Found ${type} data source: ${dataSource.name}`);
  return dataSource;
}

// Shopify API helpers
class ShopifyService {
  static async getHeaders(userId) {
    const dataSource = await getDataSource(userId, 'shopify');
    return {
      "X-Shopify-Access-Token": dataSource.credentials.shopifyAccessToken,
      "X-Shopify-API-Key": dataSource.credentials.shopifyApiKey || "",
      "X-Shopify-API-Secret": dataSource.credentials.shopifyApiSecret || ""
    };
  }

  static async getShopUrl(userId) {
    const dataSource = await getDataSource(userId, 'shopify');
    return dataSource.credentials.shopifyDomain;
  }

  static async fetchAll(endpoint, params = {}, userId, maxRequests = 100) {
    const shopUrl = await this.getShopUrl(userId);
    const results = [];
    let pageInfo = null;
    const baseUrl = `https://${shopUrl}/admin/api/${SHOPIFY_API_VERSION}/${endpoint}.json`;
    const seenPageInfos = new Set(); // Track seen page_info tokens to prevent infinite loops
    let requestCount = 0;
    
    console.log(`🛍️ Fetching Shopify ${endpoint} from ${shopUrl} (max ${maxRequests} requests)`);
    
    while (requestCount < maxRequests) {
      requestCount++;
      
      let reqParams;
      if (pageInfo) {
        // Check if we've seen this page_info before (infinite loop detection)
        if (seenPageInfos.has(pageInfo)) {
          console.log(`🔄 Detected pagination loop, breaking at request ${requestCount}`);
          break;
        }
        seenPageInfos.add(pageInfo);
        
        // When using page_info, don't include other parameters per Shopify API requirements
        reqParams = new URLSearchParams({ page_info: pageInfo });
      } else {
        // First request can include all parameters
        reqParams = new URLSearchParams({ ...params });
      }
      
      const url = `${baseUrl}?${reqParams.toString()}`;
      console.log(`📡 Making Shopify API request ${requestCount}/${maxRequests}: ${url.replace(shopUrl, '[SHOP]').substring(0, 100)}...`);
      
      const response = await fetch(url, {
        headers: await this.getHeaders(userId)
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.log(`❌ Shopify API error: ${response.status} - ${errorText}`);
        
        // Handle rate limiting
        if (response.status === 429) {
          console.log(`⏰ Rate limited, waiting 2 seconds before retrying...`);
          await new Promise(resolve => setTimeout(resolve, 2000));
          requestCount--; // Don't count this as a failed request
          continue;
        }
        
        throw new Error(`Shopify API error: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      const key = endpoint.split("/").pop();
      const items = data[key] || [];
      
      console.log(`📦 Received ${items.length} ${key} items on request ${requestCount}/${maxRequests}`);
      
      if (items.length === 0) {
        console.log(`🔚 No more items, stopping pagination`);
        break;
      }
      
      results.push(...items);
      
      // Check for pagination
      const linkHeader = response.headers.get('Link');
      if (linkHeader && linkHeader.includes('rel="next"')) {
        const match = linkHeader.match(/page_info=([^&>]+)/);
        if (match) {
          const newPageInfo = match[1];
          if (newPageInfo === pageInfo) {
            console.log(`🔄 Same page_info returned, breaking to prevent infinite loop`);
            break;
          }
          pageInfo = newPageInfo;
        } else {
          console.log(`🔚 No page_info found in Link header, stopping pagination`);
          break;
        }
      } else {
        console.log(`🔚 No "next" link found, pagination complete`);
        break;
      }
      
      // Add a small delay to be respectful to the API (reduced from 100ms to 50ms for faster sync)
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    
    if (requestCount >= maxRequests) {
      console.log(`⚠️ Hit maximum request limit (${maxRequests}), stopping pagination`);
      console.log(`📊 Consider increasing maxRequests or using date filtering to reduce data volume`);
    }
    
    console.log(`✅ Shopify ${endpoint} fetch complete: ${results.length} total items in ${requestCount} requests`);
    return results;
  }

  static async fetchOrders(userId, params = {}, maxRequests = 100) {
    return this.fetchAll("orders", { status: "any", limit: "250", ...params }, userId, maxRequests);
  }

  static async fetchProducts(userId, params = {}, maxRequests = 100) {
    return this.fetchAll("products", { limit: "250", ...params }, userId, maxRequests);
  }

  static async fetchCustomers(userId, params = {}, maxRequests = 100) {
    return this.fetchAll("customers", { limit: "250", ...params }, userId, maxRequests);
  }
}

// BigCommerce API helpers
class BigCommerceService {
  static async getHeaders(userId) {
    const dataSource = await getDataSource(userId, 'bigcommerce');
    return {
      "X-Auth-Token": dataSource.credentials.bigcommerceAccessToken,
      "Accept": "application/json",
      "Content-Type": "application/json"
    };
  }

  static async getStoreHash(userId) {
    const dataSource = await getDataSource(userId, 'bigcommerce');
    return dataSource.credentials.bigcommerceStoreHash;
  }

  static async fetchAll(endpoint, params = {}, userId) {
    const storeHash = await this.getStoreHash(userId);
    const results = [];
    let page = 1;
    const limit = 250;
    const baseUrl = `https://api.bigcommerce.com/stores/${storeHash}/${BIGCOMMERCE_API_VERSION}/${endpoint}`;
    
    while (true) {
      const reqParams = new URLSearchParams({ 
        limit: limit.toString(),
        page: page.toString(),
        ...params 
      });
      
      const url = `${baseUrl}?${reqParams.toString()}`;
      const response = await fetch(url, {
        headers: await this.getHeaders(userId)
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`BigCommerce API error: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      const items = Array.isArray(data) ? data : [];
      
      if (items.length === 0) {
        break;
      }
      
      results.push(...items);
      
      if (items.length < limit) {
        break;
      }
      
      page++;
    }
    
    return results;
  }

  static async fetchOrders(userId, params = {}) {
    return this.fetchAll("orders", params, userId);
  }

  static async fetchProducts(userId, params = {}) {
    return this.fetchAll("products", params, userId);
  }

  static async fetchCustomers(userId, params = {}) {
    return this.fetchAll("customers", params, userId);
  }
}

// Unified ecommerce service
export class EcommerceService {
  static async fetchDataFromSync(userId, dataSourceId, startDate = null, endDate = null) {
    try {
      console.log(`📂 Fetching synced data for user ${userId}, dataSource ${dataSourceId}, dates: ${startDate} to ${endDate}`);
      
      // Get all synced data without date filtering first
      const ordersData = await SyncedData.getDataByType(userId, dataSourceId, 'orders');
      const productsData = await SyncedData.getDataByType(userId, dataSourceId, 'products');  
      const customersData = await SyncedData.getDataByType(userId, dataSourceId, 'customers');

      console.log(`📦 Raw synced data found: ${ordersData.length} orders, ${productsData.length} products, ${customersData.length} customers`);

      // If there is no synced data at all, fallback to API
      if (ordersData.length === 0 && productsData.length === 0 && customersData.length === 0) {
        console.log(`❌ No synced data found for any type - returning null to fallback to API`);
        return null;
      }

      // Extract the actual data from the synced records
      let orders = ordersData.map(item => item.data);
      let products = productsData.map(item => item.data);
      let customers = customersData.map(item => item.data);

      // Apply date filtering to the business data if dates are provided
      if (startDate || endDate) {
        const startDt = startDate ? new Date(startDate) : null;
        const endDt = endDate ? new Date(endDate) : null;
        
        console.log(`🗓️ Applying date filter: ${startDt} to ${endDt}`);
        
        // Filter orders by their created_at date
        orders = orders.filter(order => {
          const created = order.created_at;
          if (!created) return false;
          const dt = new Date(created);
          if (startDt && dt < startDt) return false;
          if (endDt && dt > endDt) return false;
          return true;
        });
        
        // Filter customers by their created_at date
        customers = customers.filter(customer => {
          const created = customer.created_at;
          if (!created) return false;
          const dt = new Date(created);
          if (startDt && dt < startDt) return false;
          if (endDt && dt > endDt) return false;
          return true;
        });
        
        console.log(`📊 After date filtering: ${orders.length} orders, ${customers.length} customers`);
      }

      console.log(`✅ Returning synced data: ${orders.length} orders, ${products.length} products, ${customers.length} customers`);
      return { orders, products, customers, fromSync: true };
      
    } catch (error) {
      console.error('❌ Error fetching from synced data:', error);
      return null;
    }
  }

  static async fetchData(userId, dataSourceType, startDate = null, endDate = null, preferSync = false, maxRequests = 100) {
    console.log(`🔍 Fetching data for ${dataSourceType}, preferSync: ${preferSync}, maxRequests: ${maxRequests}`);
    
    // If preferSync is true, try to get data from synced storage first
    if (preferSync) {
      console.log(`📂 Checking for existing synced data...`);
      const dataSource = await getDataSource(userId, dataSourceType);
      const syncedData = await this.fetchDataFromSync(userId, dataSource._id, startDate, endDate);
      // Only fallback to API if there is truly no synced data at all
      if (syncedData && (syncedData.orders || syncedData.products || syncedData.customers)) {
        console.log(`✅ Using synced data for ${dataSourceType}: ${syncedData.orders.length} orders`);
        return syncedData;
      }
      console.log(`📡 No synced data found, falling back to API for ${dataSourceType}`);
    } else {
      console.log(`📡 Fetching fresh data from ${dataSourceType} API`);
    }

    // Fall back to API data
    const dateParams = {};
    if (startDate && endDate) {
      if (dataSourceType === 'shopify') {
        dateParams.created_at_min = `${startDate}T00:00:00-00:00`;
        dateParams.created_at_max = `${endDate}T23:59:59-00:00`;
        console.log(`📅 Shopify date filter: ${dateParams.created_at_min} to ${dateParams.created_at_max}`);
      } else if (dataSourceType === 'bigcommerce') {
        dateParams.min_date_created = `${startDate}T00:00:00.000Z`;
        dateParams.max_date_created = `${endDate}T23:59:59.999Z`;
        console.log(`📅 BigCommerce date filter: ${dateParams.min_date_created} to ${dateParams.max_date_created}`);
      }
    } else {
      console.log(`📅 No date filtering applied - fetching all available data`);
    }

    let orders, products, customers;

    console.log(`🔌 Connecting to ${dataSourceType} API...`);
    
    switch (dataSourceType) {
      case 'shopify':
        console.log(`🛍️ Fetching Shopify data with params:`, dateParams);
        orders = await ShopifyService.fetchOrders(userId, dateParams, maxRequests);
        console.log(`📦 Fetched ${orders.length} orders from Shopify`);
        
        // For products and customers, use a smaller maxRequests since they change less frequently
        const productMaxRequests = Math.min(maxRequests, 50);
        const customerMaxRequests = Math.min(maxRequests, 100);
        
        products = await ShopifyService.fetchProducts(userId, {}, productMaxRequests);
        console.log(`🏷️ Fetched ${products.length} products from Shopify`);
        customers = await ShopifyService.fetchCustomers(userId, {}, customerMaxRequests);
        console.log(`👥 Fetched ${customers.length} customers from Shopify`);
        break;
        
      case 'bigcommerce':
        console.log(`🏪 Fetching BigCommerce data with params:`, dateParams);
        orders = await BigCommerceService.fetchOrders(userId, dateParams);
        console.log(`📦 Fetched ${orders.length} orders from BigCommerce`);
        products = await BigCommerceService.fetchProducts(userId);
        console.log(`🏷️ Fetched ${products.length} products from BigCommerce`);
        customers = await BigCommerceService.fetchCustomers(userId);
        console.log(`👥 Fetched ${customers.length} customers from BigCommerce`);
        break;
        
      default:
        console.log(`❌ Unsupported ecommerce platform: ${dataSourceType}`);
        throw new Error(`Unsupported ecommerce platform: ${dataSourceType}`);
    }

    console.log(`✅ API fetch complete for ${dataSourceType}: ${orders.length} orders, ${products.length} products, ${customers.length} customers`);
    return { orders, products, customers, fromSync: false };
  }

  static calculateMetrics(orders, products = [], customers = [], dataSourceType) {
    if (!orders || orders.length === 0) {
      return {
        total_revenue: 0,
        net_sales: 0,
        total_discounts: 0,
        total_shipping: 0,
        total_taxes: 0,
        average_order_value: 0,
        total_orders: 0,
        unique_customers: 0,
        sales_by_product: {},
        sales_by_channel: {},
        conversion_rate: 0,
        returning_customer_rate: 0,
        sales_over_time: {
          current_year: {}
        }
      };
    }

    let totalRevenue = 0;
    let totalDiscounts = 0;
    let totalShipping = 0;
    let totalTaxes = 0;
    const uniqueCustomerIds = new Set();
    const salesByProduct = {};
    const salesByChannel = {};
    const customerEmails = {};
    const salesOverTime = {};

    orders.forEach(order => {
      let orderTotal = 0;
      let orderDiscount = 0;
      let orderTax = 0;
      let orderShipping = 0;
      let customerId = null;
      let customerEmail = null;
      let orderDate = null;
      let salesChannel = 'online'; // default

      if (dataSourceType === 'shopify') {
        orderTotal = parseFloat(order.current_total_price || order.total_price || 0);
        orderDiscount = parseFloat(order.current_total_discounts || order.total_discounts || 0);
        orderTax = parseFloat(order.current_total_tax || order.total_tax || 0);
        orderShipping = parseFloat(order.total_shipping_price_set?.shop_money?.amount || order.shipping_lines?.[0]?.price || 0);
        
        customerId = order.customer?.id;
        customerEmail = order.email;
        orderDate = order.created_at;
        salesChannel = order.source_name || order.referring_site || 'online';

        // Process line items for product sales
        if (order.line_items && Array.isArray(order.line_items)) {
          order.line_items.forEach(item => {
            const productName = item.title || item.name || 'Unknown Product';
            const itemTotal = parseFloat(item.price || 0) * parseInt(item.quantity || 1);
            salesByProduct[productName] = (salesByProduct[productName] || 0) + itemTotal;
          });
        }
      } else if (dataSourceType === 'bigcommerce') {
        orderTotal = parseFloat(order.total_inc_tax || 0);
        orderDiscount = parseFloat(order.discount_amount || 0);
        orderTax = parseFloat(order.total_tax || 0);
        orderShipping = parseFloat(order.shipping_cost_inc_tax || 0);
        
        customerId = order.customer_id;
        customerEmail = order.billing_address?.email;
        orderDate = order.date_created;
        salesChannel = order.order_source || 'online';

        // Process products for BigCommerce (if available)
        if (order.products && order.products.resource && order.products.resource.data) {
          order.products.resource.data.forEach(item => {
            const productName = item.name || 'Unknown Product';
            const itemTotal = parseFloat(item.price || 0) * parseInt(item.quantity || 1);
            salesByProduct[productName] = (salesByProduct[productName] || 0) + itemTotal;
          });
        }
      }

      // Aggregate totals
      totalRevenue += orderTotal;
      totalDiscounts += orderDiscount;
      totalTaxes += orderTax;
      totalShipping += orderShipping;

      // Track unique customers
      if (customerId) {
        uniqueCustomerIds.add(customerId);
      }

      // Track customer emails for returning customer analysis
      if (customerEmail) {
        customerEmails[customerEmail] = (customerEmails[customerEmail] || 0) + 1;
      }

      // Track sales by channel
      const channelKey = salesChannel || 'unknown';
      salesByChannel[channelKey] = (salesByChannel[channelKey] || 0) + orderTotal;

      // Track sales over time (monthly)
      if (orderDate) {
        const date = new Date(orderDate);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        salesOverTime[monthKey] = (salesOverTime[monthKey] || 0) + orderTotal;
      }
    });

    // Calculate derived metrics
    const totalOrders = orders.length;
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
    const netSales = totalRevenue - totalDiscounts;

    // Calculate conversion rate (orders / unique customers)
    const conversionRate = uniqueCustomerIds.size > 0 ? totalOrders / uniqueCustomerIds.size : 0;

    // Calculate returning customer rate
    const returningCustomers = Object.values(customerEmails).filter(count => count > 1).length;
    const totalCustomersWithOrders = Object.keys(customerEmails).length;
    const returningCustomerRate = totalCustomersWithOrders > 0 ? 
      (returningCustomers / totalCustomersWithOrders) : 0;

    // Normalize sales by channel to show percentages
    const totalChannelSales = Object.values(salesByChannel).reduce((sum, value) => sum + value, 0);
    const normalizedSalesByChannel = {};
    Object.keys(salesByChannel).forEach(channel => {
      normalizedSalesByChannel[channel] = totalChannelSales > 0 ? 
        (salesByChannel[channel] / totalChannelSales) * 100 : 0;
    });

    // Sort sales over time and fill missing months
    const sortedSalesOverTime = {};
    const sortedKeys = Object.keys(salesOverTime).sort();
    sortedKeys.forEach(key => {
      sortedSalesOverTime[key] = salesOverTime[key];
    });

    return {
      total_revenue: totalRevenue,
      net_sales: netSales,
      total_discounts: totalDiscounts,
      total_shipping: totalShipping,
      total_taxes: totalTaxes,
      average_order_value: averageOrderValue,
      total_orders: totalOrders,
      unique_customers: uniqueCustomerIds.size,
      sales_by_product: salesByProduct,
      sales_by_channel: normalizedSalesByChannel,
      conversion_rate: conversionRate,
      returning_customer_rate: returningCustomerRate,
      sales_over_time: {
        current_year: sortedSalesOverTime
      },
      // Additional insights
      total_customers_with_orders: totalCustomersWithOrders,
      returning_customers: returningCustomers,
      new_customers: totalCustomersWithOrders - returningCustomers,
      // Time-based metrics
      first_order_date: sortedKeys.length > 0 ? sortedKeys[0] : null,
      last_order_date: sortedKeys.length > 0 ? sortedKeys[sortedKeys.length - 1] : null
    };
  }
}

export { ShopifyService, BigCommerceService }; 