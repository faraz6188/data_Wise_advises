import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fetch from 'node-fetch';
import path from 'path';
import { fileURLToPath } from 'url';
import connectDB from './config/database.js';
import authRoutes from './routes/auth.js';
import dataSourceRoutes from './routes/dataSources.js';
import ecommerceRoutes from './routes/ecommerce.js';
import syncRoutes from './routes/sync.js';
import uploadRoutes from './routes/upload.js';
import DataSource from './models/DataSource.js';
import { EcommerceService } from './services/ecommerceService.js';
import { authenticate, optionalAuth } from './middleware/auth.js';
import mongoose from 'mongoose';
import SyncedData from './models/SyncedData.js';
import { SyncService } from './services/syncService.js';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from parent directory
dotenv.config({ path: path.join(__dirname, '..', '.env') });

// Connect to MongoDB
connectDB();

const app = express();
const PORT = process.env.PORT || 8000;

// Middleware
app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Create uploads directory if it doesn't exist
const uploadsDir = './uploads';
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
  console.log('📁 Created uploads directory');
}

// Auth routes
app.use('/api/auth', authRoutes);

// Data sources routes
app.use('/api/data-sources', dataSourceRoutes);

// Sync routes
app.use('/api/sync', syncRoutes);

// Upload routes
app.use('/api/upload', uploadRoutes);

// Ecommerce routes (unified for Shopify, BigCommerce, etc.)
app.use('/api/ecommerce', ecommerceRoutes);

// Shopify configuration
const SHOPIFY_API_VERSION = "2023-10";

// Helper function to get user's Shopify data source
async function getShopifyDataSource(userId) {
    const dataSource = await DataSource.findOne({
        user: userId,
        type: 'shopify',
        isActive: true,
        status: 'connected'
    });
    
    if (!dataSource) {
        throw new Error('Shopify data source not found or not connected. Please connect your Shopify store in Data Sources.');
    }
    
    return dataSource;
}

// Helper function to get Shopify headers for a user
async function shopifyHeaders(userId) {
    const dataSource = await getShopifyDataSource(userId);
    
    return {
        "X-Shopify-Access-Token": dataSource.credentials.shopifyAccessToken,
        "X-Shopify-API-Key": dataSource.credentials.shopifyApiKey || "",
        "X-Shopify-API-Secret": dataSource.credentials.shopifyApiSecret || ""
    };
}

// Helper function to fetch all pages from Shopify API with pagination
async function fetchAllShopify(endpoint, params = {}, userId) {
    const dataSource = await getShopifyDataSource(userId);
    const shopUrl = dataSource.credentials.shopifyDomain;
    
    const results = [];
    let pageInfo = null;
    const baseUrl = `https://${shopUrl}/admin/api/${SHOPIFY_API_VERSION}/${endpoint}.json`;
    
    while (true) {
        let reqParams;
        if (pageInfo) {
            // When using page_info, don't include other parameters per Shopify API requirements
            reqParams = new URLSearchParams({ page_info: pageInfo });
        } else {
            // First request can include all parameters
            reqParams = new URLSearchParams({ ...params });
        }
        
        const url = `${baseUrl}?${reqParams.toString()}`;
        const response = await fetch(url, {
            headers: await shopifyHeaders(userId)
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Shopify API error: ${response.status} - ${errorText}`);
        }
        
        const data = await response.json();
        const key = endpoint.split("/").pop();
        const items = data[key] || [];
        results.push(...items);
        
        // Check for pagination
        const linkHeader = response.headers.get('Link');
        if (linkHeader && linkHeader.includes('rel="next"')) {
            const match = linkHeader.match(/page_info=([^&>]+)/);
            if (match) {
                pageInfo = match[1];
            } else {
                break;
            }
        } else {
            break;
        }
    }
    
    return results;
}

// Helper function to fetch analytics data
async function fetchAnalyticsData(reportType, queryParams = {}, userId) {
    const dataSource = await getShopifyDataSource(userId);
    const shopUrl = dataSource.credentials.shopifyDomain;
    
    const url = `https://${shopUrl}/admin/api/${SHOPIFY_API_VERSION}/reports/${reportType}.json`;
    const params = new URLSearchParams(queryParams);
    
    const response = await fetch(`${url}?${params.toString()}`, {
        headers: await shopifyHeaders(userId)
    });
    
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Analytics API error: ${response.status} - ${errorText}`);
    }
    
    const data = await response.json();
    return data.report || {};
}

// Helper function to get date range parameters
function getDateRangeParams(startDate, endDate) {
    const params = {};
    if (startDate) {
        params.created_at_min = `${startDate}T00:00:00-00:00`;
    }
    if (endDate) {
        params.created_at_max = `${endDate}T23:59:59-00:00`;
    }
    return params;
}

// Helper function to check if item is in date range
function inDateRange(item, startDate, endDate) {
    const created = item.created_at;
    if (!created) return false;
    
    const dt = new Date(created);
    
    if (startDate && dt < new Date(startDate)) return false;
    if (endDate && dt > new Date(endDate)) return false;
    
    return true;
}

// API Routes

// Get comprehensive Shopify data (protected route) - Now uses synced data for better performance
app.get("/api/shopify/data", authenticate, async (req, res) => {
    try {
        const { start_date, end_date, include_analytics = 'true', force_api = 'false' } = req.query;
        
        console.log(`📊 Data request - start: ${start_date}, end: ${end_date}, force_api: ${force_api}`);
        
        // Get user's primary Shopify data source
        const dataSource = await DataSource.findOne({
            user: req.user.id,
            type: 'shopify',
            isActive: true,
            status: 'connected'
        });
        
        if (!dataSource) {
            return res.status(404).json({ 
                error: "No Shopify data source found. Please connect your Shopify store in Data Sources." 
            });
        }
        
        let orders, products, customers;
        
        // Use synced data by default, fallback to API only if forced or no synced data
        if (force_api === 'true') {
            console.log(`🔌 Force API mode - fetching fresh data from Shopify API`);
            const { orders: apiOrders, products: apiProducts, customers: apiCustomers } = 
                await EcommerceService.fetchData(req.user.id, 'shopify', start_date, end_date, false);
            orders = apiOrders;
            products = apiProducts;
            customers = apiCustomers;
        } else {
            console.log(`📂 Using synced data for faster performance`);
            try {
                const { orders: syncedOrders, products: syncedProducts, customers: syncedCustomers } = 
                    await EcommerceService.fetchDataFromSync(req.user.id, dataSource._id, start_date, end_date);
                
                if (syncedOrders && syncedOrders.length > 0) {
                    orders = syncedOrders;
                    products = syncedProducts;
                    customers = syncedCustomers;
                    console.log(`✅ Using synced data: ${orders.length} orders, ${products.length} products, ${customers.length} customers`);
                } else {
                    console.log(`📡 No synced data found, falling back to API`);
                    const { orders: apiOrders, products: apiProducts, customers: apiCustomers } = 
                        await EcommerceService.fetchData(req.user.id, 'shopify', start_date, end_date, false);
                    orders = apiOrders;
                    products = apiProducts;
                    customers = apiCustomers;
                }
            } catch (error) {
                console.log(`❌ Error accessing synced data, falling back to API:`, error.message);
                const { orders: apiOrders, products: apiProducts, customers: apiCustomers } = 
                    await EcommerceService.fetchData(req.user.id, 'shopify', start_date, end_date, false);
                orders = apiOrders;
                products = apiProducts;
                customers = apiCustomers;
            }
        }
        
        // Filter by date if needed (for synced data that might not be pre-filtered)
        if (start_date || end_date) {
            const startDt = start_date ? new Date(start_date) : null;
            const endDt = end_date ? new Date(end_date) : null;
            
            orders = orders.filter(order => {
                const created = order.created_at;
                if (!created) return false;
                const dt = new Date(created);
                if (startDt && dt < startDt) return false;
                if (endDt && dt > endDt) return false;
                return true;
            });
            
            customers = customers.filter(customer => {
                const created = customer.created_at;
                if (!created) return false;
                const dt = new Date(created);
                if (startDt && dt < startDt) return false;
                if (endDt && dt > endDt) return false;
                return true;
            });
        }
        
        // Calculate metrics
        const grossSales = orders.reduce((sum, order) => sum + parseFloat(order.total_line_items_price || 0), 0);
        const discounts = orders.reduce((sum, order) => sum + parseFloat(order.total_discounts || 0), 0);
        const taxes = orders.reduce((sum, order) => sum + parseFloat(order.total_tax || 0), 0);
        const totalSales = orders.reduce((sum, order) => sum + parseFloat(order.total_price || 0), 0);
        const shipping = orders.reduce((sum, order) => {
            const shippingPrice = order.total_shipping_price_set?.shop_money?.amount || 0;
            return sum + parseFloat(shippingPrice);
        }, 0);
        
        const orderCount = orders.length;
        const ordersFulfilled = orders.filter(order => order.fulfillment_status === "fulfilled").length;
        const aov = orderCount > 0 ? totalSales / orderCount : 0;
        
        // Returning customer rate
        const customerOrders = {};
        orders.forEach(order => {
            const email = order.email;
            if (email) {
                customerOrders[email] = (customerOrders[email] || 0) + 1;
            }
        });
        
        const returningCustomers = Object.values(customerOrders).filter(count => count > 1).length;
        const totalCustomers = Object.keys(customerOrders).length;
        const returningCustomerRate = totalCustomers > 0 ? (returningCustomers / totalCustomers) * 100 : 0;
        
        // Sales by channel
        const salesByChannel = {};
        orders.forEach(order => {
            const channel = order.source_name || "Other";
            salesByChannel[channel] = (salesByChannel[channel] || 0) + parseFloat(order.total_price || 0);
        });
        
        // Sales by product
        const salesByProduct = {};
        orders.forEach(order => {
            order.line_items?.forEach(item => {
                const title = item.title || "Unknown";
                const variantTitle = item.variant_title || "Default Title";
                const productName = variantTitle !== "Default Title" ? `${title} | ${variantTitle}` : `${title} | Default Title`;
                
                const itemTotal = parseFloat(item.price || 0) * parseInt(item.quantity || 1);
                salesByProduct[productName] = (salesByProduct[productName] || 0) + itemTotal;
            });
        });
        
        // Sales over time
        const currentYearData = new Array(12).fill(0);
        const previousYearData = new Array(12).fill(0);
        const currentYear = new Date().getFullYear();
        const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        
        orders.forEach(order => {
            const created = order.created_at;
            if (created) {
                const dt = new Date(created);
                const monthIdx = dt.getMonth();
                const year = dt.getFullYear();
                
                if (year === currentYear) {
                    currentYearData[monthIdx] += parseFloat(order.total_price || 0);
                } else if (year === currentYear - 1) {
                    previousYearData[monthIdx] += parseFloat(order.total_price || 0);
                }
            }
        });
        
        const responseData = {
            data: {
                orders_summary: {
                    count: orderCount,
                    fulfilled: ordersFulfilled,
                    growth_percentage: 11
                },
                sales_summary: {
                    gross_sales: grossSales,
                    growth_percentage: 120,
                    discounts: discounts,
                    returns: 0,
                    net_sales: grossSales - discounts,
                    shipping: shipping,
                    taxes: taxes,
                    total_sales: totalSales
                },
                customer_metrics: {
                    returning_customer_rate: returningCustomerRate,
                    growth_percentage: 66.67
                },
                sales_over_time: {
                    current_year: Object.fromEntries(months.map((month, idx) => [month, currentYearData[idx]])),
                    previous_year: Object.fromEntries(months.map((month, idx) => [month, previousYearData[idx]])),
                    total: totalSales
                },
                average_order_value: {
                    value: aov,
                    growth_percentage: 145,
                    by_month: {
                        current_year: { Jan: 0, Feb: 0, Mar: 618.50, Apr: 1600, May: 2300, 
                                       Jun: 0, Jul: 1400, Aug: 2600, Sep: 0, Oct: 0, Nov: 0, Dec: 0 },
                        previous_year: { Jan: 239, Feb: 781.73 }
                    }
                },
                sessions: {
                    total: 2756,
                    growth_percentage: 310,
                    by_month: {
                        current_year: [35, 552, 328, 364, 293, 475, 368, 161, 21, 26, 132, 1],
                        previous_year: [4, 13, 38, 173, 0, 352, 32, 52, 0, 0, 0, 8]
                    },
                    by_device: {
                        Desktop: 2800,
                        Mobile: 3
                    }
                },
                conversion_rate: {
                    rate: 0.15,
                    growth_percentage: 2
                },
                sales_by_channel: salesByChannel,
                sales_by_product: salesByProduct,
                product_sell_through: {
                    average_rate: 9.4,
                    growth_percentage: 68
                }
            },
            raw_data: {
                orders: orders,
                products: products,
                customers: customers
            }
        };
        
        res.json(responseData);
        
    } catch (error) {
        console.error("Shopify API error:", error);
        res.status(500).json({ 
            error: error.message,
            trace: error.stack
        });
    }
});

// Get available reports
app.get("/api/shopify/reports", authenticate, async (req, res) => {
    try {
        const dataSource = await getShopifyDataSource(req.user.id);
        const shopUrl = dataSource.credentials.shopifyDomain;
        
        const url = `https://${shopUrl}/admin/api/${SHOPIFY_API_VERSION}/reports.json`;
        const response = await fetch(url, {
            headers: await shopifyHeaders(req.user.id)
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Shopify API error: ${response.status} - ${errorText}`);
        }
        
        const data = await response.json();
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get sales analytics
app.get("/api/shopify/sales_analytics", authenticate, async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const dateParams = {};
        
        if (start_date) dateParams.date_min = start_date;
        if (end_date) dateParams.date_max = end_date;
        
        const data = await fetchAnalyticsData("sales", dateParams, req.user.id);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get sessions data
app.get("/api/shopify/sessions", authenticate, async (req, res) => {
    try {
        const { start_date, end_date, group_by = "day" } = req.query;
        const dateParams = {};
        
        if (start_date) dateParams.date_min = start_date;
        if (end_date) dateParams.date_max = end_date;
        if (group_by) dateParams.group_by = group_by;
        
        const data = await fetchAnalyticsData("sessions", dateParams, req.user.id);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get device data
app.get("/api/shopify/device_types", authenticate, async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const dateParams = {};
        
        if (start_date) dateParams.date_min = start_date;
        if (end_date) dateParams.date_max = end_date;
        
        const data = await fetchAnalyticsData("device_types", dateParams, req.user.id);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get top products
app.get("/api/shopify/top_products", authenticate, async (req, res) => {
    try {
        const { start_date, end_date, limit = "10" } = req.query;
        const params = { limit };
        
        if (start_date) params.date_min = start_date;
        if (end_date) params.date_max = end_date;
        
        const data = await fetchAnalyticsData("top_products", params, req.user.id);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get customer cohorts
app.get("/api/shopify/customer_cohorts", authenticate, async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const params = {};
        
        if (start_date) params.date_min = start_date;
        if (end_date) params.date_max = end_date;
        
        const data = await fetchAnalyticsData("customer_cohorts", params, req.user.id);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get Shopify metrics (protected route) - Now uses synced data for better performance
app.get("/api/shopify/metrics", authenticate, async (req, res) => {
    try {
        let { start, end, force_api = 'false' } = req.query;
        
        // Default to last 30 days if not provided
        if (!start || !end) {
            const today = new Date();
            end = end || today.toISOString().split('T')[0];
            const thirtyDaysAgo = new Date(today.getTime() - (29 * 24 * 60 * 60 * 1000));
            start = start || thirtyDaysAgo.toISOString().split('T')[0];
        }
        
        console.log(`📊 Metrics request - start: ${start}, end: ${end}, force_api: ${force_api}`);
        
        // Get user's primary Shopify data source
        const dataSource = await DataSource.findOne({
            user: req.user.id,
            type: 'shopify',
            isActive: true,
            status: 'connected'
        });
        
        if (!dataSource) {
            return res.status(404).json({ 
                error: "No Shopify data source found. Please connect your Shopify store in Data Sources." 
            });
        }
        
        let orders;
        
        // Use synced data by default for much faster metrics
        if (force_api === 'true') {
            console.log(`🔌 Force API mode - fetching fresh metrics from Shopify API`);
            const { orders: apiOrders } = await EcommerceService.fetchData(req.user.id, 'shopify', start, end, false);
            orders = apiOrders;
        } else {
            console.log(`📂 Using synced data for faster metrics calculation`);
            try {
                const { orders: syncedOrders } = await EcommerceService.fetchDataFromSync(req.user.id, dataSource._id, start, end);
                
                if (syncedOrders && syncedOrders.length > 0) {
                    orders = syncedOrders;
                    console.log(`✅ Using synced data for metrics: ${orders.length} orders`);
                } else {
                    console.log(`📡 No synced data found for metrics, falling back to API`);
                    const { orders: apiOrders } = await EcommerceService.fetchData(req.user.id, 'shopify', start, end, false);
                    orders = apiOrders;
                }
            } catch (error) {
                console.log(`❌ Error accessing synced data for metrics, falling back to API:`, error.message);
                const { orders: apiOrders } = await EcommerceService.fetchData(req.user.id, 'shopify', start, end, false);
                orders = apiOrders;
            }
        }
        
        // Calculate metrics
        const totalRevenue = orders.reduce((sum, order) => sum + parseFloat(order.current_total_price || 0), 0);
        const totalDiscounts = orders.reduce((sum, order) => sum + parseFloat(order.current_total_discounts || 0), 0);
        const totalTaxes = orders.reduce((sum, order) => sum + parseFloat(order.current_total_tax || 0), 0);
        const totalShipping = orders.reduce((sum, order) => {
            const shippingPrice = order.total_shipping_price_set?.shop_money?.amount || 0;
            return sum + parseFloat(shippingPrice);
        }, 0);
        const totalOrders = orders.length;
        const totalItemsSold = orders.reduce((sum, order) => {
            return sum + (order.line_items || []).reduce((itemSum, item) => itemSum + (item.quantity || 0), 0);
        }, 0);
        const uniqueCustomers = new Set(orders.filter(order => order.customer).map(order => order.customer.id)).size;
        const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
        const netSales = totalRevenue - totalDiscounts;
        
        res.json({
            total_revenue: totalRevenue,
            total_discounts: totalDiscounts,
            total_taxes: totalTaxes,
            total_shipping: totalShipping,
            total_orders: totalOrders,
            total_items_sold: totalItemsSold,
            unique_customers: uniqueCustomers,
            average_order_value: averageOrderValue,
            net_sales: netSales,
            data_source: force_api === 'true' ? 'api' : 'synced',
            date_range: { start, end }
        });
        
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Health check endpoint
app.get("/health", (req, res) => {
    res.json({ status: "ok", message: "Node.js Shopify API server is running" });
});

const router = express.Router();

router.post('/api/chat/ask', authenticate, async (req, res) => {
  const { question, dataSources } = req.body;
  const userId = req.user?.id || req.user?._id; // Adjust as needed for your auth
  if (!userId) return res.status(401).json({ error: 'Unauthorized' });

  try {
    // 1. Aggregate data from all connected sources
    let allData = [];
    for (const source of dataSources) {
      const dataTypes = SyncService.getDataTypesForSource(source.type);
      let sourceData = {};
      for (const dataType of dataTypes) {
        // Fetch up to 10 most recent records for each data type
        const records = await SyncedData.getDataByType(userId, source.id, dataType, { limit: 10 });
        sourceData[dataType] = records.map(r => r.data);
      }
      allData.push({
        name: source.name,
        type: source.type,
        data: sourceData
      });
    }

    // 2. Build prompt for the AI
    let prompt = `You are a business data assistant. Here is the user's question: "${question}"\n\n`;
    prompt += `Here is the latest data from the user's connected sources:\n`;
    for (const src of allData) {
      prompt += `\nSource: ${src.name} (${src.type})\n`;
      for (const [dataType, records] of Object.entries(src.data)) {
        prompt += `  ${dataType}:\n`;
        if (records.length === 0) {
          prompt += '    No recent data.\n';
        } else {
          for (const rec of records) {
            prompt += `    - ${JSON.stringify(rec).slice(0, 300)}\n`;
          }
        }
      }
    }
    prompt += '\nPlease answer the user question using only the data above. If the answer is not possible, say so.';

    // 3. Call the AI (replace with your actual AI service call)
    // const aiAnswer = await geminiService.sendMessage(prompt);
    const aiAnswer = `AI would answer here based on the following prompt:\n\n${prompt}`;

    res.json({ answer: aiAnswer });
  } catch (err) {
    console.error('Error in /api/chat/ask:', err);
    res.status(500).json({ error: 'Failed to process question.' });
  }
});

app.use(router);

// Global error handler - ensures all errors return JSON instead of HTML
app.use((err, req, res, next) => {
  console.error('Global error handler:', err);
  
  // Check if response already sent
  if (res.headersSent) {
    return next(err);
  }
  
  // Return JSON error response
  res.status(err.status || 500).json({
    message: err.message || 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? err.stack : 'Something went wrong'
  });
});

// Handle 404 routes
app.use((req, res) => {
  res.status(404).json({
    message: 'Route not found',
    error: 'NOT_FOUND'
  });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Node.js Shopify API server is running on port ${PORT}`);
    console.log(`📊 API endpoints available at http://localhost:${PORT}/api/shopify/`);
}); 