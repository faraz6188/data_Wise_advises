import express from 'express';
import rateLimit from 'express-rate-limit';
import User from '../models/User.js';
import { generateToken, authenticate, authRateLimit } from '../middleware/auth.js';

const router = express.Router();

// Apply rate limiting to auth routes
const limiter = rateLimit(authRateLimit);

// @route   POST /api/auth/register
// @desc    Register a new user
// @access  Public
router.post('/register', limiter, async (req, res) => {
  try {
    const { name, email, password, company, phone } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User already exists with this email'
      });
    }

    // Create new user
    const user = await User.create({
      name,
      email,
      password,
      profile: {
        company: company || '',
        phone: phone || ''
      }
    });

    // Generate token
    const token = generateToken(user._id);

    // Update login info
    await user.updateLoginInfo();

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      token,
      user: user.toJSON()
    });

  } catch (error) {
    console.error('Registration error:', error);
    
    // Handle validation errors
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: messages
      });
    }

    res.status(500).json({
      success: false,
      message: 'Server error during registration'
    });
  }
});

// @route   POST /api/auth/login
// @desc    Login user
// @access  Public
router.post('/login', limiter, async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate input
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and password'
      });
    }

    // Find user and include password
    const user = await User.findOne({ email }).select('+password');
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check if account is active
    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Account is inactive. Please contact support.'
      });
    }

    // Verify password
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Generate token
    const token = generateToken(user._id);

    // Update login info
    await user.updateLoginInfo();

    res.json({
      success: true,
      message: 'Login successful',
      token,
      user: user.toJSON()
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during login'
    });
  }
});

// @route   GET /api/auth/me
// @desc    Get current user profile
// @access  Private
router.get('/me', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    
    res.json({
      success: true,
      user: user.toJSON()
    });
  } catch (error) {
    console.error('Profile fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching profile'
    });
  }
});

// @route   PUT /api/auth/profile
// @desc    Update user profile
// @access  Private
router.put('/profile', authenticate, async (req, res) => {
  try {
    const { name, profile } = req.body;
    const user = await User.findById(req.user._id);

    if (name) user.name = name;
    if (profile) {
      user.profile = {
        ...user.profile,
        ...profile
      };
    }

    await user.save();

    res.json({
      success: true,
      message: 'Profile updated successfully',
      user: user.toJSON()
    });

  } catch (error) {
    console.error('Profile update error:', error);
    
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: messages
      });
    }

    res.status(500).json({
      success: false,
      message: 'Server error updating profile'
    });
  }
});

// @route   PUT /api/auth/password
// @desc    Change user password
// @access  Private
router.put('/password', authenticate, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Please provide current and new password'
      });
    }

    const user = await User.findById(req.user._id).select('+password');
    
    // Verify current password
    const isCurrentPasswordValid = await user.comparePassword(currentPassword);
    if (!isCurrentPasswordValid) {
      return res.status(400).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }

    // Update password
    user.password = newPassword;
    await user.save();

    res.json({
      success: true,
      message: 'Password updated successfully'
    });

  } catch (error) {
    console.error('Password update error:', error);
    
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: messages
      });
    }

    res.status(500).json({
      success: false,
      message: 'Server error updating password'
    });
  }
});

// @route   POST /api/auth/shopify/connect
// @desc    Connect Shopify store to user account
// @access  Private
router.post('/shopify/connect', authenticate, async (req, res) => {
  try {
    const { storeName, shopifyDomain, accessToken } = req.body;

    if (!storeName || !shopifyDomain || !accessToken) {
      return res.status(400).json({
        success: false,
        message: 'Please provide store name, domain, and access token'
      });
    }

    const user = await User.findById(req.user._id);
    
    await user.addShopifyStore({
      storeName,
      shopifyDomain,
      accessToken
    });

    res.json({
      success: true,
      message: 'Shopify store connected successfully',
      user: user.toJSON()
    });

  } catch (error) {
    console.error('Shopify connect error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error connecting Shopify store'
    });
  }
});

// @route   DELETE /api/auth/shopify/:domain
// @desc    Disconnect Shopify store from user account
// @access  Private
router.delete('/shopify/:domain', authenticate, async (req, res) => {
  try {
    const { domain } = req.params;
    const user = await User.findById(req.user._id);
    
    await user.removeShopifyStore(domain);

    res.json({
      success: true,
      message: 'Shopify store disconnected successfully',
      user: user.toJSON()
    });

  } catch (error) {
    console.error('Shopify disconnect error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error disconnecting Shopify store'
    });
  }
});

// @route   POST /api/auth/logout
// @desc    Logout user (client-side token removal)
// @access  Private
router.post('/logout', authenticate, (req, res) => {
  res.json({
    success: true,
    message: 'Logout successful'
  });
});

export default router; 