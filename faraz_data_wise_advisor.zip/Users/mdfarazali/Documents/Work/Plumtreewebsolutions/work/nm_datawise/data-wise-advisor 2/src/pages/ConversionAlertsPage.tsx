import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, Mail, FlaskRound, Package, Clock, TrendingUp, AlertTriangle, Activity, Target, Database } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ConversionAlertsPage() {
  return (
    <AppLayout>
      <ConversionAlertsPageContent />
    </AppLayout>
  );
}

function ConversionAlertsPageContent() {
  // Initialize state to reflect sample data usage and no checking
  const [hasShopify] = useState<boolean>(false);
  const [checkingConnections] = useState(false);

  // Sample alerts data (already present)
  const alerts = [
    {
      id: 1,
      type: "abandoned_checkouts",
      title: "Spike in abandoned checkouts",
      description: "Checkout abandonment increased by 15% in the last 24 hours",
      action: "Send email campaign",
      severity: "high",
      icon: Mail,
      color: "bg-orange-500",
      timestamp: "2 hours ago"
    },
    {
      id: 2,
      type: "low_conversion_sku",
      title: "Low conversion on top SKU",
      description: "Best-selling product has 23% lower conversion than usual",
      action: "Run A/B test",
      severity: "medium",
      icon: FlaskRound,
      color: "bg-red-500",
      timestamp: "4 hours ago"
    },
    {
      id: 3,
      type: "slow_moving_skus",
      title: "Slow-moving SKUs",
      description: "12 products haven't sold in the past 7 days",
      action: "Bundle suggestion or exit-intent promo",
      severity: "medium",
      icon: Package,
      color: "bg-yellow-500",
      timestamp: "6 hours ago"
    },
    {
      id: 4,
      type: "high_lead_time",
      title: "High lead time warning",
      description: "Average order fulfillment time increased to 5+ days",
      action: "Flag ops team",
      severity: "low",
      icon: Clock,
      color: "bg-blue-500",
      timestamp: "1 day ago"
    }
  ];

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case "high":
        return <Badge className="bg-red-100 text-red-700 border-red-200">High Priority</Badge>;
      case "medium":
        return <Badge className="border-orange-200 text-orange-700 bg-orange-50">Medium Priority</Badge>;
      case "low":
        return <Badge className="border-blue-200 text-blue-700 bg-blue-50">Low Priority</Badge>;
      default:
        return <Badge className="border-gray-200 text-gray-700 bg-gray-50">Unknown</Badge>;
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Alerts</h1>
        <p className="text-muted-foreground">
          Automated alerts triggered by changes in your store performance
        </p>
      </div>

      {/* Data Source Alert */}
      <Alert className="bg-amber-50 border-amber-200 text-amber-800">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          You're currently viewing sample alerts. Connect your Shopify store for real-time alerts.
        </AlertDescription>
      </Alert>
      
      {/* Show data source badge */}
      <div className="flex justify-end">
        <Badge className="bg-amber-50 text-amber-700 border-amber-200">
          <Database className="h-3 w-3 mr-2" />
          Using Sample Data
        </Badge>
      </div>

      {/* Error display - Removed as no real data fetching */}

      {/* Alerts List */}
      <div className="space-y-4">
        {alerts.map((alert) => (
          <Card key={alert.id} className="relative">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${alert.color}`}></div>
                  <div>
                    <CardTitle className="text-lg">{alert.title}</CardTitle>
                    <CardDescription className="mt-1">
                      {alert.description}
                    </CardDescription>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  {getSeverityBadge(alert.severity)}
                  <span className="text-xs text-muted-foreground">{alert.timestamp}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <alert.icon className="h-4 w-4" />
                  <span>Recommended Action: {alert.action}</span>
                </div>
                <div className="flex gap-2">
                  <Button className="border border-gray-200 hover:bg-gray-100">
                    Dismiss
                  </Button>
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                    Take Action
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Summary Card */}
      <Card>
        <CardHeader>
          <CardTitle>Alert Summary</CardTitle>
          <CardDescription>
            Recent alert activity and trends
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">2</div>
              <div className="text-sm text-muted-foreground">High Priority</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">1</div>
              <div className="text-sm text-muted-foreground">Medium Priority</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">1</div>
              <div className="text-sm text-muted-foreground">Low Priority</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
