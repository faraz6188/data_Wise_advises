import express from 'express';
import DataSource from '../models/DataSource.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// Get all data sources for the authenticated user
router.get('/', authenticate, async (req, res) => {
  try {
    const dataSources = await DataSource.find({ 
      user: req.user.id, 
      isActive: true 
    }).sort({ createdAt: -1 });
    
    res.json(dataSources);
  } catch (error) {
    console.error('Error fetching data sources:', error);
    res.status(500).json({ message: 'Server error while fetching data sources' });
  }
});

// Get required fields for a data source type
router.get('/fields/:type', authenticate, async (req, res) => {
  try {
    const { type } = req.params;
    const fields = DataSource.getRequiredFields(type);
    
    if (!fields.length) {
      return res.status(400).json({ message: 'Invalid data source type' });
    }
    
    res.json({ fields });
  } catch (error) {
    console.error('Error fetching field requirements:', error);
    res.status(500).json({ message: 'Server error while fetching field requirements' });
  }
});

// Create a new data source
router.post('/', authenticate, async (req, res) => {
  try {
    const { name, type, credentials, settings } = req.body;
    
    // Validate required fields
    if (!name || !type) {
      return res.status(400).json({ message: 'Name and type are required' });
    }
    
    // Check if user already has this type of data source
    const existingDataSource = await DataSource.findOne({
      user: req.user.id,
      type,
      isActive: true
    });
    
    if (existingDataSource) {
      return res.status(400).json({ 
        message: `You already have a ${type} data source connected. Please update the existing one or delete it first.` 
      });
    }
    
    // Create new data source
    const dataSource = new DataSource({
      user: req.user.id,
      name,
      type,
      credentials,
      settings: {
        syncFrequency: settings?.syncFrequency || 'daily',
        autoSync: settings?.autoSync !== undefined ? settings.autoSync : true,
        dataTypes: settings?.dataTypes || []
      }
    });
    
    await dataSource.save();
    
    // Test connection after creation
    try {
      await dataSource.testConnection();
    } catch (testError) {
      console.error('Connection test failed:', testError);
      // Don't fail the creation, just log the error
    }
    
    res.status(201).json(dataSource);
  } catch (error) {
    console.error('Error creating data source:', error);
    res.status(500).json({ message: 'Server error while creating data source' });
  }
});

// Update a data source
router.put('/:id', authenticate, async (req, res) => {
  try {
    const { name, credentials, settings } = req.body;
    
    const dataSource = await DataSource.findOne({
      _id: req.params.id,
      user: req.user.id
    });
    
    if (!dataSource) {
      return res.status(404).json({ message: 'Data source not found' });
    }
    
    // Update fields
    if (name) dataSource.name = name;
    if (credentials) {
      // Merge credentials (don't replace completely to preserve existing values)
      dataSource.credentials = { ...dataSource.credentials, ...credentials };
    }
    if (settings) {
      dataSource.settings = { ...dataSource.settings, ...settings };
    }
    
    await dataSource.save();
    
    // Test connection after update
    try {
      await dataSource.testConnection();
    } catch (testError) {
      console.error('Connection test failed:', testError);
    }
    
    res.json(dataSource);
  } catch (error) {
    console.error('Error updating data source:', error);
    res.status(500).json({ message: 'Server error while updating data source' });
  }
});

// Test connection for a data source
router.post('/:id/test', authenticate, async (req, res) => {
  try {
    const dataSource = await DataSource.findOne({
      _id: req.params.id,
      user: req.user.id
    });
    
    if (!dataSource) {
      return res.status(404).json({ message: 'Data source not found' });
    }
    
    const isConnected = await dataSource.testConnection();
    
    res.json({
      success: isConnected,
      status: dataSource.status,
      lastSyncAt: dataSource.metadata.lastSyncAt,
      lastSyncError: dataSource.metadata.lastSyncError
    });
  } catch (error) {
    console.error('Error testing connection:', error);
    res.status(500).json({ message: 'Server error while testing connection' });
  }
});

// Delete a data source
router.delete('/:id', authenticate, async (req, res) => {
  try {
    const dataSource = await DataSource.findOne({
      _id: req.params.id,
      user: req.user.id
    });
    
    if (!dataSource) {
      return res.status(404).json({ message: 'Data source not found' });
    }
    
    // Soft delete by setting isActive to false
    dataSource.isActive = false;
    dataSource.status = 'disconnected';
    await dataSource.save();
    
    res.json({ message: 'Data source deleted successfully' });
  } catch (error) {
    console.error('Error deleting data source:', error);
    res.status(500).json({ message: 'Server error while deleting data source' });
  }
});

// Get data source by type for current user
router.get('/type/:type', authenticate, async (req, res) => {
  try {
    const dataSource = await DataSource.findOne({
      user: req.user.id,
      type: req.params.type,
      isActive: true
    });
    
    if (!dataSource) {
      return res.status(404).json({ message: 'Data source not found' });
    }
    
    res.json(dataSource);
  } catch (error) {
    console.error('Error fetching data source by type:', error);
    res.status(500).json({ message: 'Server error while fetching data source' });
  }
});

// Get connection status for all data sources
router.get('/status', authenticate, async (req, res) => {
  try {
    const dataSources = await DataSource.find({
      user: req.user.id,
      isActive: true
    }).select('type name status metadata.lastSyncAt metadata.lastSyncError');
    
    const statusSummary = dataSources.map(ds => ({
      id: ds._id,
      type: ds.type,
      name: ds.name,
      status: ds.status,
      lastSyncAt: ds.metadata.lastSyncAt,
      lastSyncError: ds.metadata.lastSyncError,
      isHealthy: ds.isHealthy
    }));
    
    res.json(statusSummary);
  } catch (error) {
    console.error('Error fetching data source status:', error);
    res.status(500).json({ message: 'Server error while fetching status' });
  }
});

export default router; 