import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fetch from 'node-fetch';
import path from 'path';
import { fileURLToPath } from 'url';
import connectDB from './config/database.js';
import authRoutes from './routes/auth.js';
import dataSourceRoutes from './routes/dataSources.js';
import ecommerceRoutes from './routes/ecommerce.js';
import syncRoutes from './routes/sync.js';
import uploadRoutes from './routes/upload.js';
import DataSource from './models/DataSource.js';
import { EcommerceService } from './services/ecommerceService.js';
import { authenticate, optionalAuth } from './middleware/auth.js';
import mongoose from 'mongoose';
import SyncedData from './models/SyncedData.js';
import { SyncService } from './services/syncService.js';
import fs from 'fs';
import { GoogleGenerativeAI } from '@google/generative-ai';
import * as csvParse from 'csv-parse/sync';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from parent directory
dotenv.config({ path: path.join(__dirname, '..', '.env') });

// Connect to MongoDB
connectDB();

// === AI Chat Data Format Helpers ===
function formatOrder(order) {
  return `Order #${order.id} | Date: ${order.created_at?.split('T')[0] || 'N/A'} | Customer: ${order.customer?.first_name || order.email || 'N/A'} | Total: $${order.total_price || order.current_total_price || 'N/A'} | Status: ${order.financial_status || order.fulfillment_status || 'N/A'}`;
}

function formatProduct(product) {
  return `Product: ${product.title} | Price: $${product.variants?.[0]?.price || product.price || 'N/A'} | Inventory: ${product.variants?.[0]?.inventory_quantity || product.inventory_quantity || 'N/A'}`;
}

function formatCustomer(customer) {
  return `Customer: ${customer.first_name || ''} ${customer.last_name || ''} | Email: ${customer.email || 'N/A'} | Orders: ${customer.orders_count || 0} | Total Spent: $${customer.total_spent || 0}`;
}

function formatRecords(dataType, records) {
  if (!records || records.length === 0) return '  No recent data.\n';
  let formatter;
  if (dataType === 'orders') formatter = formatOrder;
  else if (dataType === 'products') formatter = formatProduct;
  else if (dataType === 'customers') formatter = formatCustomer;
  else formatter = (rec) => JSON.stringify(rec, null, 2).slice(0, 200); // fallback

  return records.slice(0, 5).map(rec => '  - ' + formatter(rec)).join('\n') + '\n';
}

const app = express();
const PORT = process.env.PORT || 8000;

// Middleware
app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Create uploads directory if it doesn't exist
const uploadsDir = './uploads';
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
  console.log('📁 Created uploads directory');
}

// Auth routes
app.use('/api/auth', authRoutes);

// Data sources routes
app.use('/api/data-sources', dataSourceRoutes);

// Sync routes
app.use('/api/sync', syncRoutes);

// Upload routes
app.use('/api/upload', uploadRoutes);

// Remote Fitting CSV endpoints
app.get('/api/remote-fitting/files', (req, res) => {
  try {
    console.log('📁 Remote fitting files endpoint called');
    const uploadsDir = path.join(__dirname, '..', 'uploads');
    console.log('📁 Uploads directory path:', uploadsDir);
    
    if (!fs.existsSync(uploadsDir)) {
      console.log('❌ Uploads directory does not exist');
      return res.status(404).json({ error: 'Uploads directory not found' });
    }
    
    const allFiles = fs.readdirSync(uploadsDir);
    console.log('📁 All files in uploads directory:', allFiles);
    
    const csvFiles = allFiles.filter(file => file.endsWith('.csv'));
    console.log('📁 CSV files found:', csvFiles);
    
    const files = csvFiles.map(file => {
      const filePath = path.join(uploadsDir, file);
      const stats = fs.statSync(filePath);
      return {
        id: file,
        name: file,
        type: 'csv',
        size: stats.size,
        lastModified: stats.mtime,
        path: file
      };
    });
    
    console.log('📁 Returning files:', files);
    res.json(files);
  } catch (error) {
    console.error('❌ Error reading uploads directory:', error);
    res.status(500).json({ error: 'Failed to read CSV files', details: error.message });
  }
});

app.get('/api/remote-fitting/files/:filename', (req, res) => {
  try {
    const { filename } = req.params;
    const filePath = path.join(__dirname, '..', 'uploads', filename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    // Read and parse CSV
    const csvContent = fs.readFileSync(filePath, 'utf-8');
    const lines = csvContent.split('\n');
    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const data = lines.slice(1)
      .filter(line => line.trim())
      .map(line => {
        const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
        const row = {};
        headers.forEach((header, index) => {
          row[header] = values[index] || '';
        });
        return row;
      });
    
    res.json({
      filename,
      headers,
      data: data.slice(0, 1000), // Limit to first 1000 rows for performance
      totalRows: data.length
    });
  } catch (error) {
    console.error('Error reading CSV file:', error);
    res.status(500).json({ error: 'Failed to read CSV file' });
  }
});

// Combine all CSVs in uploads into a single dataset by fittingId/fitting_id/id
app.get('/api/remote-fitting/combined', async (req, res) => {
  try {
    const uploadsDir = path.join(__dirname, '..', 'uploads');
    if (!fs.existsSync(uploadsDir)) {
      return res.status(404).json({ error: 'Uploads directory not found' });
    }
    
    // Get pagination parameters
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 1000; // Default 1000 records per page
    const skip = (page - 1) * limit;
    
    const allFiles = fs.readdirSync(uploadsDir).filter(f => f.endsWith('.csv'));
    const allRows = [];
    
    for (const file of allFiles) {
      try {
        const filePath = path.join(uploadsDir, file);
        const csvContent = fs.readFileSync(filePath, 'utf-8');
        
        // Use more robust CSV parsing options
        const records = csvParse.parse(csvContent, {
          columns: true,
          skip_empty_lines: true,
          trim: true,
          relax_quotes: true,
          relax_column_count: true,
          skip_records_with_error: true,
          from_line: 1
        });
        
        allRows.push({ file, records });
        console.log(`✅ Successfully parsed ${file}: ${records.length} records`);
      } catch (fileError) {
        console.error(`❌ Error parsing file ${file}:`, fileError.message);
        
        // Fallback: try simple CSV parsing
        try {
          const filePath = path.join(uploadsDir, file);
          const csvContent = fs.readFileSync(filePath, 'utf-8');
          const lines = csvContent.split('\n').filter(line => line.trim());
          
          if (lines.length > 1) {
            const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
            const records = lines.slice(1).map(line => {
              const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
              const row = {};
              headers.forEach((header, index) => {
                row[header] = values[index] || '';
              });
              return row;
            });
            
            allRows.push({ file, records });
            console.log(`✅ Fallback parsing successful for ${file}: ${records.length} records`);
          }
        } catch (fallbackError) {
          console.error(`❌ Fallback parsing also failed for ${file}:`, fallbackError.message);
          // Skip this file entirely
          continue;
        }
      }
    }
    
    // Merge by fittingId/fitting_id/id and transform to expected format
    const merged = {};
    for (const { file, records } of allRows) {
      for (const row of records) {
        const key = row.fittingId || row.fitting_id || row.id;
        if (!key) continue;
        if (!merged[key]) merged[key] = { fittingId: key };
        Object.assign(merged[key], row);
      }
    }
    
    // Transform to expected RemoteFittingData format
    const transformedData = Object.values(merged).map(record => {
      // Helper function to handle NULL values
      const cleanValue = (value) => {
        if (value === 'NULL' || value === null || value === undefined || value === '') {
          return null;
        }
        return value;
      };
      
      // Map CSV fields to expected frontend fields
      return {
        id: cleanValue(record.fittingId || record.fitting_id || record.id || record.fittingID) || '',
        date: cleanValue(record.created_at || record.createdAt || record.date) || new Date().toISOString(),
        puttingStyle: cleanValue(record.fittingStyle || record.puttingStyle || record.classifier_decision) || 'Unknown',
        putterType: cleanValue(record.model || record.putterType) || 'Standard',
        length: cleanValue(record.clubMeasurement || record.length) || '34',
        lie: cleanValue(record.lie_angle || record.lie) || 'Standard',
        loft: cleanValue(record.loft) || 'Standard',
        purchased: record.status === 'Close' || cleanValue(record.orderId || record.orderNumber || record.alreadyOrder) === 'true',
        timeToPurchase: cleanValue(record.timeToPurchase) ? parseInt(record.timeToPurchase) : null,
        customerEmail: cleanValue(record.email || record.customerEmail) || '',
        // Additional fields for context
        firstName: cleanValue(record.first_name || record.firstName) || '',
        lastName: cleanValue(record.last_name || record.lastName) || '',
        playerHeight: cleanValue(record.playersHeight || record.playerHeight) || '',
        reviewStatus: cleanValue(record.reviewstatus || record.reviewStatus) || '',
        status: cleanValue(record.status) || '',
        orderId: cleanValue(record.orderId || record.orderNumber) || '',
        video: cleanValue(record.video) || '',
        shopifyCustomerId: cleanValue(record.shopifyCustomerID || record.shopifyCustomerId) || ''
      };
    });
    
    // Apply pagination
    const totalRecords = transformedData.length;
    const paginatedData = transformedData.slice(skip, skip + limit);
    
    console.log(`✅ Combined ${totalRecords} unique records from ${allRows.length} files`);
    console.log(`📊 Returning page ${page} with ${paginatedData.length} records`);
    console.log(`📊 Sample record:`, paginatedData[0]);
    
    res.json({
      data: paginatedData,
      pagination: {
        page,
        limit,
        totalRecords,
        totalPages: Math.ceil(totalRecords / limit),
        hasNext: skip + limit < totalRecords,
        hasPrev: page > 1
      }
    });
  } catch (error) {
    console.error('Error combining CSVs:', error);
    res.status(500).json({ error: 'Failed to combine CSVs', details: error.message });
  }
});

// Ecommerce routes (unified for Shopify, BigCommerce, etc.)
app.use('/api/ecommerce', ecommerceRoutes);

// Shopify configuration
const SHOPIFY_API_VERSION = "2023-10";

// Helper function to get user's Shopify data source
async function getShopifyDataSource(userId) {
    const dataSource = await DataSource.findOne({
        user: userId,
        type: 'shopify',
        isActive: true,
        status: 'connected'
    });
    
    if (!dataSource) {
        throw new Error('Shopify data source not found or not connected. Please connect your Shopify store in Data Sources.');
    }
    
    return dataSource;
}

// Helper function to get Shopify headers for a user
async function shopifyHeaders(userId) {
    const dataSource = await getShopifyDataSource(userId);
    
    return {
        "X-Shopify-Access-Token": dataSource.credentials.shopifyAccessToken,
        "X-Shopify-API-Key": dataSource.credentials.shopifyApiKey || "",
        "X-Shopify-API-Secret": dataSource.credentials.shopifyApiSecret || ""
    };
}

// Helper function to fetch all pages from Shopify API with pagination
async function fetchAllShopify(endpoint, params = {}, userId) {
    const dataSource = await getShopifyDataSource(userId);
    const shopUrl = dataSource.credentials.shopifyDomain;
    
    const results = [];
    let pageInfo = null;
    const baseUrl = `https://${shopUrl}/admin/api/${SHOPIFY_API_VERSION}/${endpoint}.json`;
    
    while (true) {
        let reqParams;
        if (pageInfo) {
            // When using page_info, don't include other parameters per Shopify API requirements
            reqParams = new URLSearchParams({ page_info: pageInfo });
        } else {
            // First request can include all parameters
            reqParams = new URLSearchParams({ ...params });
        }
        
        const url = `${baseUrl}?${reqParams.toString()}`;
        const response = await fetch(url, {
            headers: await shopifyHeaders(userId)
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Shopify API error: ${response.status} - ${errorText}`);
        }
        
        const data = await response.json();
        const key = endpoint.split("/").pop();
        const items = data[key] || [];
        results.push(...items);
        
        // Check for pagination
        const linkHeader = response.headers.get('Link');
        if (linkHeader && linkHeader.includes('rel="next"')) {
            const match = linkHeader.match(/page_info=([^&>]+)/);
            if (match) {
                pageInfo = match[1];
            } else {
                break;
            }
        } else {
            break;
        }
    }
    
    return results;
}

// Helper function to fetch analytics data
async function fetchAnalyticsData(reportType, queryParams = {}, userId) {
    const dataSource = await getShopifyDataSource(userId);
    const shopUrl = dataSource.credentials.shopifyDomain;
    
    const url = `https://${shopUrl}/admin/api/${SHOPIFY_API_VERSION}/reports/${reportType}.json`;
    const params = new URLSearchParams(queryParams);
    
    const response = await fetch(`${url}?${params.toString()}`, {
        headers: await shopifyHeaders(userId)
    });
    
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Analytics API error: ${response.status} - ${errorText}`);
    }
    
    const data = await response.json();
    return data.report || {};
}

// Helper function to get date range parameters
function getDateRangeParams(startDate, endDate) {
    const params = {};
    if (startDate) {
        params.created_at_min = `${startDate}T00:00:00-00:00`;
    }
    if (endDate) {
        params.created_at_max = `${endDate}T23:59:59-00:00`;
    }
    return params;
}

// Helper function to check if item is in date range
function inDateRange(item, startDate, endDate) {
    const created = item.created_at;
    if (!created) return false;
    
    const dt = new Date(created);
    
    if (startDate && dt < new Date(startDate)) return false;
    if (endDate && dt > new Date(endDate)) return false;
    
    return true;
}

// API Routes

// Get comprehensive Shopify data (protected route) - Now uses synced data for better performance
app.get("/api/shopify/data", authenticate, async (req, res) => {
    try {
        const { start_date, end_date, include_analytics = 'true', force_api = 'false' } = req.query;
        
        console.log(`📊 Data request - start: ${start_date}, end: ${end_date}, force_api: ${force_api}`);
        
        // Get user's primary Shopify data source
        const dataSource = await DataSource.findOne({
            user: req.user.id,
            type: 'shopify',
            isActive: true,
            status: 'connected'
        });
        
        if (!dataSource) {
            return res.status(404).json({ 
                error: "No Shopify data source found. Please connect your Shopify store in Data Sources." 
            });
        }
        
        let orders, products, customers;
        
        // Use synced data by default, fallback to API only if forced or no synced data
        if (force_api === 'true') {
            console.log(`🔌 Force API mode - fetching fresh data from Shopify API`);
            const { orders: apiOrders, products: apiProducts, customers: apiCustomers } = 
                await EcommerceService.fetchData(req.user.id, 'shopify', start_date, end_date, false);
            orders = apiOrders;
            products = apiProducts;
            customers = apiCustomers;
        } else {
            console.log(`📂 Using synced data for faster performance`);
            try {
                const { orders: syncedOrders, products: syncedProducts, customers: syncedCustomers } = 
                    await EcommerceService.fetchDataFromSync(req.user.id, dataSource._id, start_date, end_date);
                
                if (syncedOrders && syncedOrders.length > 0) {
                    orders = syncedOrders;
                    products = syncedProducts;
                    customers = syncedCustomers;
                    console.log(`✅ Using synced data: ${orders.length} orders, ${products.length} products, ${customers.length} customers`);
                } else {
                    console.log(`📡 No synced data found, falling back to API`);
                    const { orders: apiOrders, products: apiProducts, customers: apiCustomers } = 
                        await EcommerceService.fetchData(req.user.id, 'shopify', start_date, end_date, false);
                    orders = apiOrders;
                    products = apiProducts;
                    customers = apiCustomers;
                }
            } catch (error) {
                console.log(`❌ Error accessing synced data, falling back to API:`, error.message);
                const { orders: apiOrders, products: apiProducts, customers: apiCustomers } = 
                    await EcommerceService.fetchData(req.user.id, 'shopify', start_date, end_date, false);
                orders = apiOrders;
                products = apiProducts;
                customers = apiCustomers;
            }
        }
        
        // Filter by date if needed (for synced data that might not be pre-filtered)
        if (start_date || end_date) {
            const startDt = start_date ? new Date(start_date) : null;
            const endDt = end_date ? new Date(end_date) : null;
            
            orders = orders.filter(order => {
                const created = order.created_at;
                if (!created) return false;
                const dt = new Date(created);
                if (startDt && dt < startDt) return false;
                if (endDt && dt > endDt) return false;
                return true;
            });
            
            customers = customers.filter(customer => {
                const created = customer.created_at;
                if (!created) return false;
                const dt = new Date(created);
                if (startDt && dt < startDt) return false;
                if (endDt && dt > endDt) return false;
                return true;
            });
        }
        
        // Calculate metrics
        const grossSales = orders.reduce((sum, order) => sum + parseFloat(order.total_line_items_price || 0), 0);
        const discounts = orders.reduce((sum, order) => sum + parseFloat(order.total_discounts || 0), 0);
        const taxes = orders.reduce((sum, order) => sum + parseFloat(order.total_tax || 0), 0);
        const totalSales = orders.reduce((sum, order) => sum + parseFloat(order.total_price || 0), 0);
        const shipping = orders.reduce((sum, order) => {
            const shippingPrice = order.total_shipping_price_set?.shop_money?.amount || 0;
            return sum + parseFloat(shippingPrice);
        }, 0);
        
        const orderCount = orders.length;
        const ordersFulfilled = orders.filter(order => order.fulfillment_status === "fulfilled").length;
        const aov = orderCount > 0 ? totalSales / orderCount : 0;
        
        // Returning customer rate
        const customerOrders = {};
        orders.forEach(order => {
            const email = order.email;
            if (email) {
                customerOrders[email] = (customerOrders[email] || 0) + 1;
            }
        });
        
        const returningCustomers = Object.values(customerOrders).filter(count => count > 1).length;
        const totalCustomers = Object.keys(customerOrders).length;
        const returningCustomerRate = totalCustomers > 0 ? (returningCustomers / totalCustomers) * 100 : 0;
        
        // Sales by channel
        const salesByChannel = {};
        orders.forEach(order => {
            const channel = order.source_name || "Other";
            salesByChannel[channel] = (salesByChannel[channel] || 0) + parseFloat(order.total_price || 0);
        });
        
        // Sales by product
        const salesByProduct = {};
        orders.forEach(order => {
            order.line_items?.forEach(item => {
                const title = item.title || "Unknown";
                const variantTitle = item.variant_title || "Default Title";
                const productName = variantTitle !== "Default Title" ? `${title} | ${variantTitle}` : `${title} | Default Title`;
                
                const itemTotal = parseFloat(item.price || 0) * parseInt(item.quantity || 1);
                salesByProduct[productName] = (salesByProduct[productName] || 0) + itemTotal;
            });
        });
        
        // Sales over time
        const currentYearData = new Array(12).fill(0);
        const previousYearData = new Array(12).fill(0);
        const currentYear = new Date().getFullYear();
        const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        
        orders.forEach(order => {
            const created = order.created_at;
            if (created) {
                const dt = new Date(created);
                const monthIdx = dt.getMonth();
                const year = dt.getFullYear();
                
                if (year === currentYear) {
                    currentYearData[monthIdx] += parseFloat(order.total_price || 0);
                } else if (year === currentYear - 1) {
                    previousYearData[monthIdx] += parseFloat(order.total_price || 0);
                }
            }
        });
        
        const responseData = {
            data: {
                orders_summary: {
                    count: orderCount,
                    fulfilled: ordersFulfilled,
                    growth_percentage: 11
                },
                sales_summary: {
                    gross_sales: grossSales,
                    growth_percentage: 120,
                    discounts: discounts,
                    returns: 0,
                    net_sales: grossSales - discounts,
                    shipping: shipping,
                    taxes: taxes,
                    total_sales: totalSales
                },
                customer_metrics: {
                    returning_customer_rate: returningCustomerRate,
                    growth_percentage: 66.67
                },
                sales_over_time: {
                    current_year: Object.fromEntries(months.map((month, idx) => [month, currentYearData[idx]])),
                    previous_year: Object.fromEntries(months.map((month, idx) => [month, previousYearData[idx]])),
                    total: totalSales
                },
                average_order_value: {
                    value: aov,
                    growth_percentage: 145,
                    by_month: {
                        current_year: { Jan: 0, Feb: 0, Mar: 618.50, Apr: 1600, May: 2300, 
                                       Jun: 0, Jul: 1400, Aug: 2600, Sep: 0, Oct: 0, Nov: 0, Dec: 0 },
                        previous_year: { Jan: 239, Feb: 781.73 }
                    }
                },
                sessions: {
                    total: 2756,
                    growth_percentage: 310,
                    by_month: {
                        current_year: [35, 552, 328, 364, 293, 475, 368, 161, 21, 26, 132, 1],
                        previous_year: [4, 13, 38, 173, 0, 352, 32, 52, 0, 0, 0, 8]
                    },
                    by_device: {
                        Desktop: 2800,
                        Mobile: 3
                    }
                },
                conversion_rate: {
                    rate: 0.15,
                    growth_percentage: 2
                },
                sales_by_channel: salesByChannel,
                sales_by_product: salesByProduct,
                product_sell_through: {
                    average_rate: 9.4,
                    growth_percentage: 68
                }
            },
            raw_data: {
                orders: orders,
                products: products,
                customers: customers
            }
        };
        
        res.json(responseData);
        
    } catch (error) {
        console.error("Shopify API error:", error);
        res.status(500).json({ 
            error: error.message,
            trace: error.stack
        });
    }
});

// Get available reports
app.get("/api/shopify/reports", authenticate, async (req, res) => {
    try {
        const dataSource = await getShopifyDataSource(req.user.id);
        const shopUrl = dataSource.credentials.shopifyDomain;
        
        const url = `https://${shopUrl}/admin/api/${SHOPIFY_API_VERSION}/reports.json`;
        const response = await fetch(url, {
            headers: await shopifyHeaders(req.user.id)
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Shopify API error: ${response.status} - ${errorText}`);
        }
        
        const data = await response.json();
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get sales analytics
app.get("/api/shopify/sales_analytics", authenticate, async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const dateParams = {};
        
        if (start_date) dateParams.date_min = start_date;
        if (end_date) dateParams.date_max = end_date;
        
        const data = await fetchAnalyticsData("sales", dateParams, req.user.id);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get sessions data
app.get("/api/shopify/sessions", authenticate, async (req, res) => {
    try {
        const { start_date, end_date, group_by = "day" } = req.query;
        const dateParams = {};
        
        if (start_date) dateParams.date_min = start_date;
        if (end_date) dateParams.date_max = end_date;
        if (group_by) dateParams.group_by = group_by;
        
        const data = await fetchAnalyticsData("sessions", dateParams, req.user.id);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get device data
app.get("/api/shopify/device_types", authenticate, async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const dateParams = {};
        
        if (start_date) dateParams.date_min = start_date;
        if (end_date) dateParams.date_max = end_date;
        
        const data = await fetchAnalyticsData("device_types", dateParams, req.user.id);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get top products
app.get("/api/shopify/top_products", authenticate, async (req, res) => {
    try {
        const { start_date, end_date, limit = "10" } = req.query;
        const params = { limit };
        
        if (start_date) params.date_min = start_date;
        if (end_date) params.date_max = end_date;
        
        const data = await fetchAnalyticsData("top_products", params, req.user.id);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get customer cohorts
app.get("/api/shopify/customer_cohorts", authenticate, async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const params = {};
        
        if (start_date) params.date_min = start_date;
        if (end_date) params.date_max = end_date;
        
        const data = await fetchAnalyticsData("customer_cohorts", params, req.user.id);
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get Shopify metrics (protected route) - Now uses synced data for better performance
app.get("/api/shopify/metrics", authenticate, async (req, res) => {
    try {
        let { start, end, force_api = 'false' } = req.query;
        
        // Default to last 30 days if not provided
        if (!start || !end) {
            const today = new Date();
            end = end || today.toISOString().split('T')[0];
            const thirtyDaysAgo = new Date(today.getTime() - (29 * 24 * 60 * 60 * 1000));
            start = start || thirtyDaysAgo.toISOString().split('T')[0];
        }
        
        console.log(`📊 Metrics request - start: ${start}, end: ${end}, force_api: ${force_api}`);
        
        // Get user's primary Shopify data source
        const dataSource = await DataSource.findOne({
            user: req.user.id,
            type: 'shopify',
            isActive: true,
            status: 'connected'
        });
        
        if (!dataSource) {
            return res.status(404).json({ 
                error: "No Shopify data source found. Please connect your Shopify store in Data Sources." 
            });
        }
        
        let orders;
        
        // Use synced data by default for much faster metrics
        if (force_api === 'true') {
            console.log(`🔌 Force API mode - fetching fresh metrics from Shopify API`);
            const { orders: apiOrders } = await EcommerceService.fetchData(req.user.id, 'shopify', start, end, false);
            orders = apiOrders;
        } else {
            console.log(`📂 Using synced data for faster metrics calculation`);
            try {
                const { orders: syncedOrders } = await EcommerceService.fetchDataFromSync(req.user.id, dataSource._id, start, end);
                
                if (syncedOrders && syncedOrders.length > 0) {
                    orders = syncedOrders;
                    console.log(`✅ Using synced data for metrics: ${orders.length} orders`);
                } else {
                    console.log(`📡 No synced data found for metrics, falling back to API`);
                    const { orders: apiOrders } = await EcommerceService.fetchData(req.user.id, 'shopify', start, end, false);
                    orders = apiOrders;
                }
            } catch (error) {
                console.log(`❌ Error accessing synced data for metrics, falling back to API:`, error.message);
                const { orders: apiOrders } = await EcommerceService.fetchData(req.user.id, 'shopify', start, end, false);
                orders = apiOrders;
            }
        }
        
        // Calculate metrics
        const totalRevenue = orders.reduce((sum, order) => sum + parseFloat(order.current_total_price || 0), 0);
        const totalDiscounts = orders.reduce((sum, order) => sum + parseFloat(order.current_total_discounts || 0), 0);
        const totalTaxes = orders.reduce((sum, order) => sum + parseFloat(order.current_total_tax || 0), 0);
        const totalShipping = orders.reduce((sum, order) => {
            const shippingPrice = order.total_shipping_price_set?.shop_money?.amount || 0;
            return sum + parseFloat(shippingPrice);
        }, 0);
        const totalOrders = orders.length;
        const totalItemsSold = orders.reduce((sum, order) => {
            return sum + (order.line_items || []).reduce((itemSum, item) => itemSum + (item.quantity || 0), 0);
        }, 0);
        const uniqueCustomers = new Set(orders.filter(order => order.customer).map(order => order.customer.id)).size;
        const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
        const netSales = totalRevenue - totalDiscounts;
        
        res.json({
            total_revenue: totalRevenue,
            total_discounts: totalDiscounts,
            total_taxes: totalTaxes,
            total_shipping: totalShipping,
            total_orders: totalOrders,
            total_items_sold: totalItemsSold,
            unique_customers: uniqueCustomers,
            average_order_value: averageOrderValue,
            net_sales: netSales,
            data_source: force_api === 'true' ? 'api' : 'synced',
            date_range: { start, end }
        });
        
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Lead Time Analytics endpoint - uses synced Shopify data
app.get("/api/lead-time/data", authenticate, async (req, res) => {
  try {
    const { start_date, end_date } = req.query;
    
    console.log(`⏱️ Lead Time request - start: ${start_date}, end: ${end_date}`);
    
    // Get user's primary Shopify data source - be more flexible
    let dataSource = await DataSource.findOne({
      user: req.user.id,
      type: 'shopify',
      isActive: true,
      status: 'connected'
    });
    
    // If no active Shopify source, try to find any Shopify source
    if (!dataSource) {
      dataSource = await DataSource.findOne({
        user: req.user.id,
        type: 'shopify'
      });
    }
    
    if (!dataSource) {
      return res.status(404).json({ 
        error: "No Shopify data source found. Please connect your Shopify store in Data Sources.",
        debug: {
          userId: req.user.id,
          availableSources: await DataSource.find({ user: req.user.id }).select('name type status isActive')
        }
      });
    }
    
    console.log(`📊 Using data source: ${dataSource.name} (${dataSource.status})`);
    
    // Fetch orders from synced data
    let orders = [];
    try {
      const { orders: syncedOrders } = await EcommerceService.fetchDataFromSync(
        req.user.id, 
        dataSource._id, 
        start_date, 
        end_date
      );
      
      if (syncedOrders && syncedOrders.length > 0) {
        orders = syncedOrders;
        console.log(`✅ Using synced orders for lead time: ${orders.length} orders`);
      } else {
        console.log(`📡 No synced orders found, fetching from API`);
        const { orders: apiOrders } = await EcommerceService.fetchData(
          req.user.id, 
          'shopify', 
          start_date, 
          end_date, 
          false
        );
        orders = apiOrders;
      }
    } catch (error) {
      console.log(`❌ Error accessing synced data, falling back to API:`, error.message);
      const { orders: apiOrders } = await EcommerceService.fetchData(
        req.user.id, 
        'shopify', 
        start_date, 
        end_date, 
        false
      );
      orders = apiOrders;
    }
    
    console.log(`📊 Total orders fetched: ${orders.length}`);
    
    // Filter by date if needed
    if (start_date || end_date) {
      const startDt = start_date ? new Date(start_date) : null;
      const endDt = end_date ? new Date(end_date) : null;
      
      orders = orders.filter(order => {
        const created = order.created_at;
        if (!created) return false;
        const dt = new Date(created);
        if (startDt && dt < startDt) return false;
        if (endDt && dt > endDt) return false;
        return true;
      });
      
      console.log(`📊 Orders after date filtering: ${orders.length}`);
    }
    
    // Log order status distribution for debugging
    const statusCounts = {};
    const fulfillmentCounts = {};
    orders.forEach(order => {
      statusCounts[order.financial_status] = (statusCounts[order.financial_status] || 0) + 1;
      fulfillmentCounts[order.fulfillment_status] = (fulfillmentCounts[order.fulfillment_status] || 0) + 1;
    });
    console.log(`📊 Order status distribution:`, statusCounts);
    console.log(`📊 Fulfillment status distribution:`, fulfillmentCounts);
    
    // Transform orders to lead time format - handle paid but unfulfilled orders
    const leadTimeOrders = orders
      .filter(order => {
        // Include orders that are paid (even if not fulfilled)
        const isPaid = order.financial_status === 'paid';
        const isFulfilled = order.fulfillment_status === 'fulfilled' || order.fulfillments?.length > 0;
        const hasFulfillmentData = order.fulfillments && order.fulfillments.length > 0;
        
        console.log(`Order ${order.id}: fulfilled=${isFulfilled}, paid=${isPaid}, hasFulfillmentData=${hasFulfillmentData}`);
        
        // Include paid orders even if not fulfilled (common for digital products or custom orders)
        return isPaid || isFulfilled || hasFulfillmentData;
      })
      .map(order => {
        const orderDate = new Date(order.created_at);
        let fulfillmentDate = null;
        
        // Find the first fulfillment date
        if (order.fulfillments && order.fulfillments.length > 0) {
          fulfillmentDate = new Date(order.fulfillments[0].created_at);
        } else if (order.fulfillment_status === 'fulfilled') {
          // If fulfilled but no fulfillment records, use updated_at as approximation
          fulfillmentDate = new Date(order.updated_at);
        } else if (order.financial_status === 'paid') {
          // For paid orders without fulfillment, use updated_at as the "completion" date
          // This represents when the order was processed/completed
          fulfillmentDate = new Date(order.updated_at);
        }
        
        if (!fulfillmentDate) return null;
        
        const leadTimeDays = (fulfillmentDate.getTime() - orderDate.getTime()) / (1000 * 60 * 60 * 24);
        
        // Determine status based on lead time - adjust thresholds for your business
        let status = 'On Time';
        if (leadTimeDays > 14) status = 'Delayed'; // Increased threshold for custom orders
        else if (leadTimeDays < 1) status = 'Early';
        
        return {
          orderId: order.id.toString(),
          orderNumber: order.order_number || order.name || order.id.toString(),
          customer: order.customer?.first_name && order.customer?.last_name 
            ? `${order.customer.first_name} ${order.customer.last_name}`
            : order.customer?.email || 'Anonymous',
          putterType: order.line_items?.[0]?.product_title || 'Unknown',
          orderDate: order.created_at,
          shipDate: fulfillmentDate.toISOString(),
          leadTime: Math.round(leadTimeDays * 10) / 10, // Round to 1 decimal
          status,
          productName: order.line_items?.[0]?.product_title || 'Unknown',
          shaftType: order.line_items?.[0]?.properties?.find(p => p.name?.toLowerCase().includes('shaft'))?.value || 'Standard',
          shaftLength: order.line_items?.[0]?.properties?.find(p => p.name?.toLowerCase().includes('length'))?.value || 'Standard',
          putterColor: order.line_items?.[0]?.properties?.find(p => p.name?.toLowerCase().includes('color'))?.value || 'Standard',
          gripType: order.line_items?.[0]?.properties?.find(p => p.name?.toLowerCase().includes('grip'))?.value || 'Standard',
          puttingStyle: order.line_items?.[0]?.properties?.find(p => p.name?.toLowerCase().includes('style'))?.value || 'Standard',
          hand: order.line_items?.[0]?.properties?.find(p => p.name?.toLowerCase().includes('hand'))?.value || 'Right',
          lieAngle: order.line_items?.[0]?.properties?.find(p => p.name?.toLowerCase().includes('lie'))?.value || 'Standard',
          headWeight: order.line_items?.[0]?.properties?.find(p => p.name?.toLowerCase().includes('weight'))?.value || 'Standard',
          buildTime: order.line_items?.[0]?.properties?.find(p => p.name?.toLowerCase().includes('build'))?.value || 'Standard',
          // Additional context
          totalPrice: order.total_price,
          currency: order.currency,
          financialStatus: order.financial_status,
          fulfillmentStatus: order.fulfillment_status,
          tags: order.tags,
          note: order.note
        };
      })
      .filter(order => order !== null); // Remove null entries
    
    console.log(`📊 Lead Time Analysis: ${leadTimeOrders.length} orders processed`);
    
    res.json({
      data: leadTimeOrders,
      summary: {
        totalOrders: leadTimeOrders.length,
        averageLeadTime: leadTimeOrders.length > 0 
          ? leadTimeOrders.reduce((sum, order) => sum + order.leadTime, 0) / leadTimeOrders.length 
          : 0,
        medianLeadTime: leadTimeOrders.length > 0 
          ? leadTimeOrders.sort((a, b) => a.leadTime - b.leadTime)[Math.floor(leadTimeOrders.length / 2)].leadTime 
          : 0,
        longestLeadTime: leadTimeOrders.length > 0 
          ? Math.max(...leadTimeOrders.map(order => order.leadTime)) 
          : 0,
        shortestLeadTime: leadTimeOrders.length > 0 
          ? Math.min(...leadTimeOrders.map(order => order.leadTime)) 
          : 0
      },
      debug: {
        totalOrdersFetched: orders.length,
        ordersWithLeadTime: leadTimeOrders.length,
        dataSourceUsed: dataSource.name,
        dateRange: { start_date, end_date }
      }
    });
    
  } catch (error) {
    console.error('Error fetching lead time data:', error);
    res.status(500).json({ error: 'Failed to fetch lead time data', details: error.message });
  }
});

// Sample lead time data for demonstration when no real data is available
app.get("/api/lead-time/sample", async (req, res) => {
  try {
    const sampleData = [
      {
        orderId: "1001",
        orderNumber: "#1001",
        customer: "John Smith",
        putterType: "DF3",
        orderDate: "2024-01-15T10:30:00Z",
        shipDate: "2024-01-18T14:20:00Z",
        leadTime: 3.2,
        status: "On Time",
        productName: "DF3 Putter",
        shaftType: "Steel",
        shaftLength: "34\"",
        putterColor: "Black",
        gripType: "Standard",
        puttingStyle: "Arms Lock",
        hand: "Right",
        lieAngle: "70°",
        headWeight: "350g",
        buildTime: "3 days",
        totalPrice: "299.99",
        currency: "USD",
        financialStatus: "paid",
        fulfillmentStatus: "fulfilled"
      },
      {
        orderId: "1002",
        orderNumber: "#1002",
        customer: "Sarah Johnson",
        putterType: "MEZZ.1",
        orderDate: "2024-01-20T09:15:00Z",
        shipDate: "2024-01-25T16:45:00Z",
        leadTime: 5.3,
        status: "On Time",
        productName: "MEZZ.1 Putter",
        shaftType: "Graphite",
        shaftLength: "35\"",
        putterColor: "White",
        gripType: "Oversize",
        puttingStyle: "Conventional",
        hand: "Left",
        lieAngle: "72°",
        headWeight: "360g",
        buildTime: "5 days",
        totalPrice: "349.99",
        currency: "USD",
        financialStatus: "paid",
        fulfillmentStatus: "fulfilled"
      },
      {
        orderId: "1003",
        orderNumber: "#1003",
        customer: "Mike Davis",
        putterType: "LINK.1",
        orderDate: "2024-01-10T11:00:00Z",
        shipDate: "2024-01-20T10:30:00Z",
        leadTime: 9.8,
        status: "Delayed",
        productName: "LINK.1 Putter",
        shaftType: "Steel",
        shaftLength: "33\"",
        putterColor: "Red",
        gripType: "Standard",
        puttingStyle: "Arms Lock",
        hand: "Right",
        lieAngle: "68°",
        headWeight: "340g",
        buildTime: "8 days",
        totalPrice: "279.99",
        currency: "USD",
        financialStatus: "paid",
        fulfillmentStatus: "fulfilled"
      },
      {
        orderId: "1004",
        orderNumber: "#1004",
        customer: "Lisa Wilson",
        putterType: "OZ.1",
        orderDate: "2024-01-25T14:20:00Z",
        shipDate: "2024-01-26T09:15:00Z",
        leadTime: 0.8,
        status: "Early",
        productName: "OZ.1 Putter",
        shaftType: "Graphite",
        shaftLength: "34.5\"",
        putterColor: "Blue",
        gripType: "Oversize",
        puttingStyle: "Conventional",
        hand: "Right",
        lieAngle: "71°",
        headWeight: "355g",
        buildTime: "1 day",
        totalPrice: "399.99",
        currency: "USD",
        financialStatus: "paid",
        fulfillmentStatus: "fulfilled"
      },
      {
        orderId: "1005",
        orderNumber: "#1005",
        customer: "Tom Brown",
        putterType: "DF 2.1",
        orderDate: "2024-01-30T16:45:00Z",
        shipDate: "2024-02-05T11:30:00Z",
        leadTime: 5.8,
        status: "On Time",
        productName: "DF 2.1 Putter",
        shaftType: "Steel",
        shaftLength: "35\"",
        putterColor: "Black",
        gripType: "Standard",
        puttingStyle: "Arms Lock",
        hand: "Right",
        lieAngle: "69°",
        headWeight: "345g",
        buildTime: "5 days",
        totalPrice: "249.99",
        currency: "USD",
        financialStatus: "paid",
        fulfillmentStatus: "fulfilled"
      }
    ];
    
    const summary = {
      totalOrders: sampleData.length,
      averageLeadTime: sampleData.reduce((sum, order) => sum + order.leadTime, 0) / sampleData.length,
      medianLeadTime: 5.3,
      longestLeadTime: 9.8,
      shortestLeadTime: 0.8
    };
    
    res.json({
      data: sampleData,
      summary,
      debug: {
        message: "Using sample data for demonstration",
        note: "Connect your Shopify store to see real data"
      }
    });
    
  } catch (error) {
    console.error('Error generating sample data:', error);
    res.status(500).json({ error: 'Failed to generate sample data' });
  }
});

// Test endpoint to check data sources and Shopify data
app.get("/api/debug/data-sources", async (req, res) => {
  try {
    // Get all data sources
    const dataSources = await DataSource.find({});
    
    // Get some sample synced data
    const sampleSyncedData = await SyncedData.find({}).limit(5);
    
    // Get sample orders if any exist
    let sampleOrders = [];
    if (dataSources.length > 0) {
      const firstDataSource = dataSources[0];
      try {
        const { orders } = await EcommerceService.fetchDataFromSync(
          firstDataSource.user, 
          firstDataSource._id, 
          '2024-01-01', 
          '2024-12-31'
        );
        sampleOrders = orders.slice(0, 3); // Get first 3 orders
      } catch (error) {
        console.log('Error fetching sample orders:', error.message);
      }
    }
    
    res.json({
      dataSources: dataSources.map(ds => ({
        id: ds._id,
        name: ds.name,
        type: ds.type,
        status: ds.status,
        isActive: ds.isActive,
        user: ds.user
      })),
      sampleSyncedData: sampleSyncedData.map(sd => ({
        id: sd._id,
        dataSource: sd.dataSource,
        dataType: sd.dataType,
        recordCount: sd.recordCount,
        lastSynced: sd.lastSynced
      })),
      sampleOrders: sampleOrders.map(order => ({
        id: order.id,
        order_number: order.order_number,
        fulfillment_status: order.fulfillment_status,
        financial_status: order.financial_status,
        created_at: order.created_at,
        updated_at: order.updated_at,
        line_items_count: order.line_items?.length || 0,
        fulfillments_count: order.fulfillments?.length || 0
      }))
    });
  } catch (error) {
    console.error('Debug endpoint error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Simple test endpoint to check order data without authentication
app.get("/api/test/orders", async (req, res) => {
  try {
    // Get any data source
    const dataSource = await DataSource.findOne({ type: 'shopify' });
    
    if (!dataSource) {
      return res.json({ 
        error: "No Shopify data source found",
        message: "Please connect a Shopify store first"
      });
    }
    
    // Try to get some orders
    let orders = [];
    try {
      const { orders: syncedOrders } = await EcommerceService.fetchDataFromSync(
        dataSource.user, 
        dataSource._id, 
        '2024-01-01', 
        '2024-12-31'
      );
      orders = syncedOrders || [];
    } catch (error) {
      console.log('Error fetching orders:', error.message);
    }
    
    // Analyze order statuses
    const statusAnalysis = {
      totalOrders: orders.length,
      financialStatus: {},
      fulfillmentStatus: {},
      sampleOrders: orders.slice(0, 5).map(order => ({
        id: order.id,
        order_number: order.order_number,
        financial_status: order.financial_status,
        fulfillment_status: order.fulfillment_status,
        created_at: order.created_at,
        updated_at: order.updated_at,
        has_fulfillments: order.fulfillments && order.fulfillments.length > 0,
        line_items_count: order.line_items?.length || 0
      }))
    };
    
    orders.forEach(order => {
      statusAnalysis.financialStatus[order.financial_status] = (statusAnalysis.financialStatus[order.financial_status] || 0) + 1;
      statusAnalysis.fulfillmentStatus[order.fulfillment_status] = (statusAnalysis.fulfillmentStatus[order.fulfillment_status] || 0) + 1;
    });
    
    res.json(statusAnalysis);
    
  } catch (error) {
    console.error('Test endpoint error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Health check endpoint
app.get("/health", (req, res) => {
    res.json({ status: "ok", message: "Node.js Shopify API server is running" });
});

const router = express.Router();

// === Gemini AI Service ===
const GEMINI_API_KEY = "AIzaSyBh_UYfnfKqRVeKkwh1bdxX-q0vmrrZm8c";
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
const geminiModel = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

async function callGeminiAI(prompt) {
  try {
    const result = await geminiModel.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Error calling Gemini AI:', error);
    throw new Error('Failed to get AI response');
  }
}

router.post('/api/chat/ask', authenticate, async (req, res) => {
  const { question, dataSources } = req.body;
  const userId = req.user?.id || req.user?._id; // Adjust as needed for your auth
  if (!userId) return res.status(401).json({ error: 'Unauthorized' });

  try {
    // 1. Aggregate data from all connected sources
    let allData = [];
    for (const source of dataSources) {
      const dataTypes = SyncService.getDataTypesForSource(source.type);
      let sourceData = {};
      for (const dataType of dataTypes) {
        // Fetch up to 10 most recent records for each data type
        const records = await SyncedData.getDataByType(userId, source.id, dataType, { limit: 10 });
        sourceData[dataType] = records.map(r => r.data);
      }
      allData.push({
        name: source.name,
        type: source.type,
        data: sourceData
      });
    }

    // 2. Build prompt for the AI (now with formatted summaries)
    let prompt = `You are a business data assistant. Here is the user's question: "${question}"
\n`;
    prompt += `Here is the latest data from the user's connected sources:\n`;
    for (const src of allData) {
      prompt += `\nSource: ${src.name} (${src.type})\n`;
      for (const [dataType, records] of Object.entries(src.data)) {
        prompt += `${dataType}:\n`;
        prompt += formatRecords(dataType, records);
      }
    }
    prompt += '\nPlease answer the user question using only the data above. If the answer is not possible, say so.';

    // 3. Call the actual Gemini AI
    const aiAnswer = await callGeminiAI(prompt);

    res.json({ answer: aiAnswer });
  } catch (err) {
    console.error('Error in /api/chat/ask:', err);
    res.status(500).json({ error: 'Failed to process question.' });
  }
});

app.use(router);

// Global error handler - ensures all errors return JSON instead of HTML
app.use((err, req, res, next) => {
  console.error('Global error handler:', err);
  
  // Check if response already sent
  if (res.headersSent) {
    return next(err);
  }
  
  // Return JSON error response
  res.status(err.status || 500).json({
    message: err.message || 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? err.stack : 'Something went wrong'
  });
});

// Handle 404 routes
app.use((req, res) => {
  res.status(404).json({
    message: 'Route not found',
    error: 'NOT_FOUND'
  });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Node.js Shopify API server is running on port ${PORT}`);
    console.log(`📊 API endpoints available at http://localhost:${PORT}/api/shopify/`);
}); 