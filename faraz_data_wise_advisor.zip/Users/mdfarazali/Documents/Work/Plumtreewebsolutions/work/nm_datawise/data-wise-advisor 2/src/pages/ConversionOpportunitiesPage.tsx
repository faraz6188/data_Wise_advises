import { useState, useEffect } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, TrendingUp, MousePointer, DollarSign, Eye, Database } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

export default function ConversionOpportunitiesPage() {
  return (
    <AppLayout>
      <ConversionOpportunitiesPageContent />
    </AppLayout>
  );
}

function ConversionOpportunitiesPageContent() {
  const [hasShopify, setHasShopify] = useState<boolean>(false);
  const [checkingConnections, setCheckingConnections] = useState(false);

  // Check for Shopify connections on component mount
  // useEffect(() => {
  //   async function checkShopifyConnection() {
  //     try {
  //       setCheckingConnections(true);
  //       const { data: connections, error } = await supabase
  //         .from('service_connections')
  //         .select('id')
  //         .eq('service_type', 'shopify')
  //         .eq('is_active', true)
  //         .limit(1);
          
  //       if (error) throw error;
        
  //       setHasShopify(connections && connections.length > 0);
  //     } catch (err) {
  //       console.error('Error checking Shopify connections:', err);
  //       setHasShopify(false);
  //     } finally {
  //       setCheckingConnections(false);
  //     }
  //   }
    
  //   checkShopifyConnection();
  // }, []); // Commented out due to missing supabase client

  // Generate opportunities based on real data
  const getOpportunities = () => {
    // Always return sample data since real data fetching is commented out
    return {
      lowConvertingPages: [
        { page: "Product Category: Electronics", traffic: 2500, conversionRate: 1.2, potential: 45 },
        { page: "Landing Page: Summer Sale", traffic: 1800, conversionRate: 0.8, potential: 32 },
        { page: "Product: Wireless Headphones", traffic: 1200, conversionRate: 2.1, potential: 28 }
      ],
      priceOpportunities: [
        { segment: "Orders $50-100", abandonment: 35, discount: 10, lift: 25 },
        { segment: "Orders $100-200", abandonment: 28, discount: 15, lift: 18 },
        { segment: "Orders $200+", abandonment: 45, discount: 20, lift: 35 }
      ],
      uxIssues: [
        { issue: "High rage clicks on checkout", severity: "high", impact: "Block 12% of conversions" },
        { issue: "Mobile scroll depth issues", severity: "medium", impact: "Affects 8% of mobile users" },
        { issue: "Slow loading product images", severity: "high", impact: "Increases bounce rate by 15%" }
      ]
    };
  };

  const { lowConvertingPages, priceOpportunities, uxIssues } = getOpportunities();

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200";
      case "medium":
        return "bg-orange-100 text-orange-800 border-orange-200";
      case "low":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Conversion Opportunities</h1>
        <p className="text-muted-foreground">
          Identify and optimize conversion improvement opportunities
        </p>
      </div>

      {/* Data Source Alert */}
      {!checkingConnections && !hasShopify && (
        <Alert className="bg-amber-50 border-amber-200 text-amber-800">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            You're currently viewing sample opportunities. Connect your Shopify store for real conversion opportunities.
          </AlertDescription>
        </Alert>
      )}
      
      {/* Show data source badge */}
      <div className="flex justify-end">
        {/* Always show sample data badge as real data fetching is commented out */}
        <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
          <Database className="h-3 w-3 mr-2" />
          Using Sample Data
        </Badge>
      </div>

      {/* Error display */}
      {/* Removed error display as error variable is undefined */}

      {/* Low-Converting Landing Pages */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Low-Converting Pages
          </CardTitle>
          <CardDescription>
            High traffic pages with conversion optimization potential
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {lowConvertingPages.map((page, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="font-medium">{page.page}</h4>
                    <p className="text-sm text-muted-foreground">
                      {page.traffic.toLocaleString()} monthly visitors
                    </p>
                  </div>
                  <Badge variant="outline" className="bg-red-50 text-red-700">
                    {page.conversionRate.toFixed(1)}% conversion
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Optimization Potential</span>
                    <span>{page.potential}% improvement possible</span>
                  </div>
                  <Progress value={page.potential} className="h-2" />
                </div>
                <div className="flex gap-2 mt-3">
                  <Button size="sm" variant="outline">Auto-flag for review</Button>
                  <Button size="sm">Start A/B Test</Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Price Sensitivity Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Price Sensitivity Insights
          </CardTitle>
          <CardDescription>
            Cart abandonment patterns by order value and discount impact
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {priceOpportunities.map((opportunity, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <h4 className="font-medium">{opportunity.segment}</h4>
                    <p className="text-sm text-muted-foreground">Order value tier</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-red-600">{opportunity.abandonment}%</p>
                    <p className="text-sm text-muted-foreground">Cart abandonment</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-blue-600">{opportunity.discount}%</p>
                    <p className="text-sm text-muted-foreground">Suggested discount</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-green-600">+{opportunity.lift}%</p>
                    <p className="text-sm text-muted-foreground">Expected conversion lift</p>
                  </div>
                </div>
                <div className="flex gap-2 mt-4">
                  <Button size="sm" variant="outline">Create Bundle Offer</Button>
                  <Button size="sm">Set Exit-Intent Promo</Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* UX Issues Detection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MousePointer className="h-5 w-5" />
            UX Issues Detection
          </CardTitle>
          <CardDescription>
            User experience problems affecting conversions
            <span className="ml-2 text-amber-600">(Session heatmaps require integration)</span>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {uxIssues.map((issue, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="font-medium">{issue.issue}</h4>
                    <p className="text-sm text-muted-foreground">{issue.impact}</p>
                  </div>
                  <Badge variant="outline" className={getSeverityColor(issue.severity)}>
                    {issue.severity} priority
                  </Badge>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button size="sm" variant="outline">View Heatmap</Button>
                  <Button size="sm">Create Experiment</Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Action Items Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Suggested Experiments</CardTitle>
          <CardDescription>
            Recommended tests based on identified opportunities
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {/* Always show connect message as real data fetching is commented out */}
            <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
              <div>
                <h4 className="font-medium">Connect Your Store for Real Experiments</h4>
                <p className="text-sm text-muted-foreground">Get personalized experiment recommendations</p>
              </div>
              <Button size="sm" onClick={() => window.location.href = '/sources'}>
                Connect Shopify
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
