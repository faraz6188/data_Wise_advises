import { EcommerceService } from './ecommerceService.js';
import SyncedData from '../models/SyncedData.js';
import SyncJob from '../models/SyncJob.js';
import DataSource from '../models/DataSource.js';

export class SyncService {
  static async syncDataSource(userId, dataSourceId, options = {}) {
    let job = null;
    
    try {
      console.log(`🔄 Starting sync for user ${userId}, dataSource ${dataSourceId}`);
      
      const dataSource = await DataSource.findOne({
        _id: dataSourceId,
        user: userId,
        isActive: true,
        status: 'connected'
      });

      if (!dataSource) {
        console.log(`❌ Data source not found or not connected for user ${userId}`);
        throw new Error('Data source not found or not connected');
      }

      console.log(`✅ Found data source: ${dataSource.name} (${dataSource.type})`);

      const dataTypes = this.getDataTypesForSource(dataSource.type);
      console.log(`📊 Data types to sync: ${JSON.stringify(dataTypes)}`);
      
      job = await SyncJob.createJob(
        userId,
        dataSourceId,
        options.jobType || 'manual_sync',
        dataTypes,
        options
      );

      console.log(`📝 Created sync job: ${job._id}`);
      await job.start();
      console.log(`🚀 Started sync job: ${job._id}`);

      let syncResult;
      console.log(`🔍 Syncing data for type: ${dataSource.type}`);
      switch (dataSource.type) {
        case 'shopify':
        case 'bigcommerce':
          syncResult = await this.syncEcommerceData(userId, dataSource, job, options);
          break;
        default:
          console.log(`❌ Unsupported data source type: ${dataSource.type}`);
          throw new Error(`Unsupported data source type: ${dataSource.type}`);
      }

      console.log(`✅ Sync completed successfully. Records synced: ${syncResult.totalRecords}`);
      
      await DataSource.findByIdAndUpdate(dataSourceId, {
        'metadata.lastSyncAt': new Date(),
        'metadata.lastSyncStatus': 'success',
        'metadata.totalRecords': syncResult.totalRecords
      });

      await job.complete();
      console.log(`🎉 Sync job completed: ${job._id}`);
      
      return {
        success: true,
        jobId: job._id,
        syncResult
      };

    } catch (error) {
      console.error('Sync error:', error);
      
      if (job) {
        await job.fail(error);
      }

      await DataSource.findByIdAndUpdate(dataSourceId, {
        'metadata.lastSyncAt': new Date(),
        'metadata.lastSyncStatus': 'failed',
        'metadata.lastSyncError': error.message
      });

      throw error;
    }
  }

  static async syncEcommerceData(userId, dataSource, job, options = {}) {
    const { startDate, endDate, maxRequests = 100 } = options;
    
    try {
      console.log(`🛒 Fetching ecommerce data for ${dataSource.type} with maxRequests: ${maxRequests}...`);
      const { orders, products, customers } = await EcommerceService.fetchData(
        userId,
        dataSource.type,
        startDate,
        endDate,
        false, // preferSync = false for manual sync
        maxRequests
      );

      console.log(`📦 Fetched data: ${orders.length} orders, ${products.length} products, ${customers.length} customers`);
      
      const totalRecords = orders.length + products.length + customers.length;
      await job.setTotalRecords(totalRecords);
      console.log(`📊 Total records to process: ${totalRecords}`);

      let processedRecords = 0;
      let successfulRecords = 0;

      job.addLog('info', `Syncing ${orders.length} orders`);
      console.log(`💾 Starting to process ${orders.length} orders...`);
      
      for (const order of orders) {
        try {
          const externalId = order.id?.toString() || order.order_id?.toString();
          if (externalId) {
            await SyncedData.upsertData(
              userId,
              dataSource._id,
              'orders',
              externalId,
              order,
              order.updated_at || order.date_modified
            );
            successfulRecords++;
          }
        } catch (error) {
          job.addLog('error', `Failed to sync order ${order.id}`, { error: error.message });
        }
        
        processedRecords++;
        if (processedRecords % 50 === 0) {
          console.log(`📈 Progress update: ${processedRecords}/${totalRecords} processed (${Math.round((processedRecords/totalRecords)*100)}%)`);
          await job.updateProgress(processedRecords, successfulRecords);
        }
      }
      
      console.log(`✅ Completed processing ${orders.length} orders`);
      await job.updateProgress(processedRecords, successfulRecords);

      job.addLog('info', `Syncing ${products.length} products`);
      console.log(`💾 Starting to process ${products.length} products...`);
      
      for (const product of products) {
        try {
          const externalId = product.id?.toString();
          if (externalId) {
            await SyncedData.upsertData(
              userId,
              dataSource._id,
              'products',
              externalId,
              product,
              product.updated_at || product.date_modified
            );
            successfulRecords++;
          }
        } catch (error) {
          job.addLog('error', `Failed to sync product ${product.id}`, { error: error.message });
        }
        
        processedRecords++;
        if (processedRecords % 50 === 0) {
          console.log(`📈 Progress update: ${processedRecords}/${totalRecords} processed (${Math.round((processedRecords/totalRecords)*100)}%)`);
          await job.updateProgress(processedRecords, successfulRecords);
        }
      }
      
      console.log(`✅ Completed processing ${products.length} products`);
      await job.updateProgress(processedRecords, successfulRecords);

      job.addLog('info', `Syncing ${customers.length} customers`);
      console.log(`💾 Starting to process ${customers.length} customers...`);
      
      for (const customer of customers) {
        try {
          const externalId = customer.id?.toString() || customer.customer_id?.toString();
          if (externalId) {
            await SyncedData.upsertData(
              userId,
              dataSource._id,
              'customers',
              externalId,
              customer,
              customer.updated_at || customer.date_modified
            );
            successfulRecords++;
          }
        } catch (error) {
          job.addLog('error', `Failed to sync customer ${customer.id}`, { error: error.message });
        }
        
        processedRecords++;
        if (processedRecords % 50 === 0) {
          console.log(`📈 Progress update: ${processedRecords}/${totalRecords} processed (${Math.round((processedRecords/totalRecords)*100)}%)`);
          await job.updateProgress(processedRecords, successfulRecords);
        }
      }
      
      console.log(`✅ Completed processing ${customers.length} customers`);
      await job.updateProgress(processedRecords, successfulRecords);

      console.log(`🎯 Final progress update: ${processedRecords}/${totalRecords} processed (${successfulRecords} successful)`);
      await job.updateProgress(processedRecords, successfulRecords);

      return {
        totalRecords: processedRecords,
        successfulRecords,
        failedRecords: processedRecords - successfulRecords,
        dataTypes: ['orders', 'products', 'customers']
      };

    } catch (error) {
      job.addLog('error', 'Ecommerce sync failed', { error: error.message });
      throw error;
    }
  }

  static getDataTypesForSource(sourceType) {
    const dataTypeMap = {
      'shopify': ['orders', 'products', 'customers'],
      'bigcommerce': ['orders', 'products', 'customers'],
      'google_analytics': ['traffic', 'conversions'],
      'meta_ads': ['campaigns', 'ads'],
      'klaviyo': ['email_campaigns', 'profiles'],
      'custom': ['custom']
    };

    return dataTypeMap[sourceType] || ['custom'];
  }

  static async getSyncedData(userId, dataSourceId, dataType, options = {}) {
    try {
      const data = await SyncedData.getDataByType(userId, dataSourceId, dataType, options);
      return data.map(item => ({
        id: item._id,
        externalId: item.externalId,
        data: item.data,
        lastUpdated: item.metadata.lastUpdated,
        syncedAt: item.metadata.syncedAt
      }));
    } catch (error) {
      console.error('Error fetching synced data:', error);
      throw error;
    }
  }

  static async getDataStats(userId, dataSourceId) {
    try {
      return await SyncedData.getDataStats(userId, dataSourceId);
    } catch (error) {
      console.error('Error fetching data stats:', error);
      throw error;
    }
  }

  static async calculateMetricsFromSyncedData(userId, dataSourceId, options = {}) {
    try {
      const orders = await this.getSyncedData(userId, dataSourceId, 'orders', options);
      const products = await this.getSyncedData(userId, dataSourceId, 'products', options);
      const customers = await this.getSyncedData(userId, dataSourceId, 'customers', options);
      
      if (orders.length === 0 && products.length === 0 && customers.length === 0) {
        return {
          total_revenue: 0,
          net_sales: 0,
          total_discounts: 0,
          total_shipping: 0,
          total_taxes: 0,
          average_order_value: 0,
          total_orders: 0,
          unique_customers: 0,
          sales_by_product: {},
          sales_by_channel: {},
          conversion_rate: 0,
          returning_customer_rate: 0,
          sales_over_time: {
            current_year: {}
          }
        };
      }

      const dataSource = await DataSource.findById(dataSourceId);
      const orderData = orders.map(o => o.data);
      const productData = products.map(p => p.data);
      const customerData = customers.map(c => c.data);
      
      return EcommerceService.calculateMetrics(orderData, productData, customerData, dataSource.type);
    } catch (error) {
      console.error('Error calculating metrics from synced data:', error);
      throw error;
    }
  }
} 