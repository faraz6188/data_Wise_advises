import React, { useState, useEffect } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle, Clock, XCircle } from "lucide-react";
import axios from "axios";

interface DataSource {
  _id: string;
  name: string;
  type: string;
  status: 'connected' | 'disconnected' | 'error' | 'pending';
}

interface DataSourceSelectorProps {
  onDataSourceChange: (dataSourceId: string, dataSource: DataSource | null) => void;
  selectedDataSourceId?: string;
  filterTypes?: string[]; // Filter to only show specific data source types
  placeholder?: string;
  className?: string;
}

const dataSourceIcons: Record<string, string> = {
  shopify: '🛍️',
  bigcommerce: '🏪',
  google_analytics: '📊',
  meta_ads: '📱',
  klaviyo: '📧',
  custom: '🔗'
};

const DataSourceSelector = ({ 
  onDataSourceChange, 
  selectedDataSourceId, 
  filterTypes,
  placeholder = "Select data source",
  className = ""
}: DataSourceSelectorProps) => {
  const [dataSources, setDataSources] = useState<DataSource[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDataSources();
  }, []);

  // Auto-select if only one data source and none selected
  useEffect(() => {
    if (dataSources.length === 1 && !selectedDataSourceId) {
      const singleSource = dataSources[0];
      onDataSourceChange(singleSource._id, singleSource);
    }
  }, [dataSources, selectedDataSourceId, onDataSourceChange]);

  const fetchDataSources = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/data-sources');
      let sources = response.data.filter((ds: DataSource) => ds.status === 'connected');
      
      // Filter by types if specified
      if (filterTypes && filterTypes.length > 0) {
        sources = sources.filter((ds: DataSource) => filterTypes.includes(ds.type));
      }
      
      setDataSources(sources);
    } catch (error) {
      console.error('Error fetching data sources:', error);
      setDataSources([]);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return <CheckCircle className="w-3 h-3 text-green-500" />;
      case 'error': return <XCircle className="w-3 h-3 text-red-500" />;
      case 'pending': return <Clock className="w-3 h-3 text-yellow-500" />;
      default: return <AlertCircle className="w-3 h-3 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'bg-green-100 text-green-800';
      case 'error': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleValueChange = (dataSourceId: string) => {
    const selectedDataSource = dataSources.find(ds => ds._id === dataSourceId) || null;
    onDataSourceChange(dataSourceId, selectedDataSource);
  };

  if (loading) {
    return (
      <Select disabled>
        <SelectTrigger className={className}>
          <SelectValue placeholder="Loading data sources..." />
        </SelectTrigger>
      </Select>
    );
  }

  if (dataSources.length === 0) {
    return (
      <Select disabled>
        <SelectTrigger className={className}>
          <SelectValue placeholder="No connected data sources" />
        </SelectTrigger>
      </Select>
    );
  }

  return (
    <Select value={selectedDataSourceId} onValueChange={handleValueChange}>
      <SelectTrigger className={className}>
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {dataSources.map((dataSource) => (
          <SelectItem key={dataSource._id} value={dataSource._id}>
            <div className="flex items-center space-x-2 w-full">
              <span className="text-sm">{dataSourceIcons[dataSource.type] || '🔗'}</span>
              <span className="flex-1">{dataSource.name}</span>
              <div className="flex items-center space-x-1">
                {getStatusIcon(dataSource.status)}
                <Badge className={`${getStatusColor(dataSource.status)} text-xs`} variant="outline">
                  {dataSource.type}
                </Badge>
              </div>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

export default DataSourceSelector; 