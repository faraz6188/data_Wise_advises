import { GoogleGenerativeAI } from "@google/generative-ai";

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

if (!API_KEY) {
  throw new Error("Missing Gemini API key. Please add VITE_GEMINI_API_KEY to your .env file.");
}

const genAI = new GoogleGenerativeAI(API_KEY);

const SYSTEM_PROMPT = [
  "You are a persistent, intelligent AI Business Analyst trained on this company's business context. You ONLY analyze and answer questions about these metrics:",
  "- Total Sales",
  "- Net Sales",
  "- Discounts",
  "- Shipping",
  "- Taxes",
  "- AOV (Average Order Value)",
  "- Total Orders",
  "- Total Customers",
  "",
  "Do NOT mention or analyze any other metrics (such as revenue, conversion rate, profit, etc).",
  "Always use clear, structured, business-friendly language.",
  "Respond in this format:",
  "Performance Snapshot: (list the 8 metrics)",
  "Insight: (main story)",
  "Recommendation: (next steps)",
  "",
  "Now respond to this query using only the allowed metrics:",
  "",
  "👉 **{user_query}**"
].join("\n");

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export class GeminiService {
  private model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  private chat = this.model.startChat({
    history: [],
    generationConfig: {
      maxOutputTokens: 2048,
      temperature: 0.7,
    },
  });

  async sendMessage(message: string): Promise<string> {
    try {
      const prompt = SYSTEM_PROMPT.replace("{user_query}", message);
      const result = await this.chat.sendMessage(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error("Error sending message to Gemini:", error);
      throw new Error("Failed to get response from AI");
    }
  }

  async analyzeFile(file: File): Promise<string> {
    try {
      const fileContent = await this.readFileContent(file);
      const prompt = SYSTEM_PROMPT.replace("{user_query}", `Analyze the following business data and provide insights:\n\n${fileContent}`);
      const result = await this.chat.sendMessage(prompt);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error("Error analyzing file:", error);
      throw new Error("Failed to analyze file");
    }
  }

  private async readFileContent(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        resolve(content);
      };
      reader.onerror = (e) => reject(e);
      reader.readAsText(file);
    });
  }
}

export const geminiService = new GeminiService(); 