import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    maxLength: [50, 'Name cannot be more than 50 characters']
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [
      /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
      'Please enter a valid email'
    ]
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minLength: [6, 'Password must be at least 6 characters'],
    select: false // Don't include password in queries by default
  },
  role: {
    type: String,
    enum: ['user', 'admin', 'manager'],
    default: 'user'
  },
  isActive: {
    type: Boolean,
    default: true
  },
  profile: {
    company: String,
    phone: String,
    timezone: {
      type: String,
      default: 'UTC'
    },
    preferences: {
      dashboardLayout: {
        type: String,
        enum: ['grid', 'list'],
        default: 'grid'
      },
      notifications: {
        email: { type: Boolean, default: true },
        push: { type: Boolean, default: true }
      },
      theme: {
        type: String,
        enum: ['light', 'dark', 'system'],
        default: 'system'
      }
    }
  },
  shopifyStores: [{
    storeName: String,
    shopifyDomain: String,
    accessToken: String,
    connectedAt: {
      type: Date,
      default: Date.now
    },
    isActive: {
      type: Boolean,
      default: true
    }
  }],
  lastLogin: Date,
  loginCount: {
    type: Number,
    default: 0
  },
  resetPasswordToken: String,
  resetPasswordExpire: Date,
  emailVerificationToken: String,
  isEmailVerified: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

// Index for better query performance
userSchema.index({ email: 1 });
userSchema.index({ 'shopifyStores.shopifyDomain': 1 });

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(12);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Compare password method
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Get user's active Shopify stores
userSchema.methods.getActiveStores = function() {
  return this.shopifyStores.filter(store => store.isActive);
};

// Add or update Shopify store
userSchema.methods.addShopifyStore = function(storeData) {
  const existingStore = this.shopifyStores.find(
    store => store.shopifyDomain === storeData.shopifyDomain
  );
  
  if (existingStore) {
    existingStore.accessToken = storeData.accessToken;
    existingStore.storeName = storeData.storeName;
    existingStore.connectedAt = new Date();
    existingStore.isActive = true;
  } else {
    this.shopifyStores.push(storeData);
  }
  
  return this.save();
};

// Remove Shopify store
userSchema.methods.removeShopifyStore = function(shopifyDomain) {
  this.shopifyStores = this.shopifyStores.filter(
    store => store.shopifyDomain !== shopifyDomain
  );
  return this.save();
};

// Update last login
userSchema.methods.updateLoginInfo = function() {
  this.lastLogin = new Date();
  this.loginCount += 1;
  return this.save();
};

// Transform output (remove sensitive fields)
userSchema.methods.toJSON = function() {
  const userObject = this.toObject();
  delete userObject.password;
  delete userObject.resetPasswordToken;
  delete userObject.resetPasswordExpire;
  delete userObject.emailVerificationToken;
  
  // Remove access tokens from shopify stores in public responses
  if (userObject.shopifyStores) {
    userObject.shopifyStores = userObject.shopifyStores.map(store => ({
      storeName: store.storeName,
      shopifyDomain: store.shopifyDomain,
      connectedAt: store.connectedAt,
      isActive: store.isActive,
      _id: store._id
    }));
  }
  
  return userObject;
};

const User = mongoose.model('User', userSchema);

export default User; 