import mongoose from 'mongoose';

const syncedDataSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  dataSource: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'DataSource',
    required: true,
    index: true
  },
  dataType: {
    type: String,
    required: true,
    enum: [
      // Ecommerce data types
      'orders', 'products', 'customers', 'inventory',
      // Analytics data types
      'traffic', 'conversions', 'demographics', 'sessions',
      // Marketing data types
      'campaigns', 'ads', 'insights', 'audiences',
      // Email marketing data types
      'email_campaigns', 'flows', 'profiles', 'events',
      // Custom data types
      'custom'
    ],
    index: true
  },
  externalId: {
    type: String,
    required: true,
    index: true
  },
  data: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  metadata: {
    lastUpdated: {
      type: Date,
      default: Date.now
    },
    syncedAt: {
      type: Date,
      default: Date.now
    },
    version: {
      type: Number,
      default: 1
    },
    sourceLastModified: Date,
    tags: [String],
    status: {
      type: String,
      enum: ['active', 'archived', 'deleted'],
      default: 'active'
    }
  }
}, {
  timestamps: true
});

// Compound indexes for efficient querying
syncedDataSchema.index({ user: 1, dataSource: 1, dataType: 1 });
syncedDataSchema.index({ user: 1, dataType: 1, 'metadata.lastUpdated': -1 });
syncedDataSchema.index({ dataSource: 1, externalId: 1, dataType: 1 }, { unique: true });
syncedDataSchema.index({ 'metadata.syncedAt': 1 });
syncedDataSchema.index({ 'metadata.status': 1 });

// TTL index for automatic cleanup of old data (optional - 2 years)
syncedDataSchema.index({ 'metadata.syncedAt': 1 }, { expireAfterSeconds: 63072000 });

// Virtual for data freshness
syncedDataSchema.virtual('isFresh').get(function() {
  const hoursSinceUpdate = (Date.now() - this.metadata.lastUpdated.getTime()) / (1000 * 60 * 60);
  return hoursSinceUpdate <= 24; // Consider fresh if updated within 24 hours
});

// Static methods for data operations
syncedDataSchema.statics.upsertData = async function(userId, dataSourceId, dataType, externalId, data, sourceLastModified = null) {
  const filter = {
    user: userId,
    dataSource: dataSourceId,
    dataType: dataType,
    externalId: externalId
  };

  const update = {
    data: data,
    'metadata.lastUpdated': new Date(),
    'metadata.syncedAt': new Date(),
    'metadata.status': 'active'
  };

  if (sourceLastModified) {
    update['metadata.sourceLastModified'] = new Date(sourceLastModified);
  }

  const options = {
    upsert: true,
    new: true,
    runValidators: true
  };

  return this.findOneAndUpdate(filter, update, options);
};

syncedDataSchema.statics.getDataByType = async function(userId, dataSourceId, dataType, options = {}) {
  const filter = {
    user: userId,
    dataSource: dataSourceId,
    dataType: dataType,
    'metadata.status': 'active'
  };

  // Add date range filtering if provided
  if (options.startDate || options.endDate) {
    filter['metadata.lastUpdated'] = {};
    if (options.startDate) {
      filter['metadata.lastUpdated']['$gte'] = new Date(options.startDate);
    }
    if (options.endDate) {
      filter['metadata.lastUpdated']['$lte'] = new Date(options.endDate);
    }
  }

  let query = this.find(filter);

  // Apply sorting
  if (options.sortBy) {
    const sortOrder = options.sortOrder === 'asc' ? 1 : -1;
    query = query.sort({ [options.sortBy]: sortOrder });
  } else {
    query = query.sort({ 'metadata.lastUpdated': -1 });
  }

  // Apply pagination
  if (options.limit) {
    query = query.limit(parseInt(options.limit));
  }
  if (options.skip) {
    query = query.skip(parseInt(options.skip));
  }

  return query.exec();
};

syncedDataSchema.statics.getDataStats = async function(userId, dataSourceId) {
  const pipeline = [
    {
      $match: {
        user: new mongoose.Types.ObjectId(userId),
        dataSource: new mongoose.Types.ObjectId(dataSourceId),
        'metadata.status': 'active'
      }
    },
    {
      $group: {
        _id: '$dataType',
        count: { $sum: 1 },
        lastUpdated: { $max: '$metadata.lastUpdated' },
        totalSize: { $sum: { $bsonSize: '$data' } }
      }
    },
    {
      $project: {
        dataType: '$_id',
        count: 1,
        lastUpdated: 1,
        totalSizeKB: { $round: [{ $divide: ['$totalSize', 1024] }, 2] },
        _id: 0
      }
    }
  ];

  return this.aggregate(pipeline);
};

syncedDataSchema.statics.cleanupOldData = async function(userId, dataSourceId, dataType, daysOld = 90) {
  const cutoffDate = new Date(Date.now() - (daysOld * 24 * 60 * 60 * 1000));
  
  return this.updateMany(
    {
      user: userId,
      dataSource: dataSourceId,
      dataType: dataType,
      'metadata.lastUpdated': { $lt: cutoffDate },
      'metadata.status': 'active'
    },
    {
      $set: { 'metadata.status': 'archived' }
    }
  );
};

// Instance methods
syncedDataSchema.methods.markAsDeleted = function() {
  this.metadata.status = 'deleted';
  return this.save();
};

syncedDataSchema.methods.updateData = function(newData, sourceLastModified = null) {
  this.data = newData;
  this.metadata.lastUpdated = new Date();
  this.metadata.version += 1;
  
  if (sourceLastModified) {
    this.metadata.sourceLastModified = new Date(sourceLastModified);
  }
  
  return this.save();
};

// Transform output to remove internal metadata
syncedDataSchema.methods.toJSON = function() {
  const obj = this.toObject();
  
  // Remove sensitive or internal fields if needed
  delete obj.__v;
  
  return obj;
};

const SyncedData = mongoose.model('SyncedData', syncedDataSchema);

export default SyncedData; 