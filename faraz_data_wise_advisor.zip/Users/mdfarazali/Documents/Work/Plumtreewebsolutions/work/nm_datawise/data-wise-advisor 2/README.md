# Data Wise Advisor - Shopify Analytics Dashboard

A comprehensive analytics dashboard for Shopify stores with AI-powered insights and real-time data visualization.

## Features

- 📊 Comprehensive Shopify data analytics
- 🤖 AI-powered insights and recommendations
- 📈 Real-time charts and visualizations
- 🎯 Customer behavior analysis
- 💰 Sales performance tracking
- 📱 Responsive design for all devices

## Project info

**URL**: https://lovable.dev/projects/7be0e44a-2c7d-4a12-8a9b-0f4c723e9afb

## Architecture

This application uses a unified Node.js stack:
- **Frontend**: React + TypeScript + Vite
- **Backend**: Node.js + Express
- **API Integration**: Shopify Admin API
- **AI**: Google Gemini API

## How can I edit this code?

There are several ways of editing your application.

**Use Lovable**

Simply visit the [Lovable Project](https://lovable.dev/projects/7be0e44a-2c7d-4a12-8a9b-0f4c723e9afb) and start prompting.

Changes made via Lovable will be committed automatically to this repo.

**Use your preferred IDE**

If you want to work locally using your own IDE, you can clone this repo and push changes. Pushed changes will also be reflected in Lovable.

The only requirement is having Node.js & npm installed - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

Follow these steps:

```sh
# Step 1: Clone the repository using the project's Git URL.
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory.
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Start both backend and frontend servers
npm run dev:full

# Alternative: Run servers separately
npm run server  # Backend API server (port 8000)
npm run dev     # Frontend development server (port 8080)

# For full-stack development (frontend + backend):
npm run dev:full
```

**Edit a file directly in GitHub**

- Navigate to the desired file(s).
- Click the "Edit" button (pencil icon) at the top right of the file view.
- Make your changes and commit the changes.

**Use GitHub Codespaces**

- Navigate to the main page of your repository.
- Click on the "Code" button (green button) near the top right.
- Select the "Codespaces" tab.
- Click on "New codespace" to launch a new Codespace environment.
- Edit files directly within the Codespace and commit and push your changes once you're done.

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## How can I deploy this project?

Simply open [Lovable](https://lovable.dev/projects/7be0e44a-2c7d-4a12-8a9b-0f4c723e9afb) and click on Share -> Publish.

## Can I connect a custom domain to my Lovable project?

Yes, you can!

To connect a domain, navigate to Project > Settings > Domains and click Connect Domain.

Read more here: [Setting up a custom domain](https://docs.lovable.dev/tips-tricks/custom-domain#step-by-step-guide)


Mongodb Atlas
Un : naimmunshi380
pw : Y5FGzBhONcpta0dK

connection string : mongodb+srv://naimmunshi380:Y5FGzBhONcpta0dK@cluster0.mjg0xwc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0