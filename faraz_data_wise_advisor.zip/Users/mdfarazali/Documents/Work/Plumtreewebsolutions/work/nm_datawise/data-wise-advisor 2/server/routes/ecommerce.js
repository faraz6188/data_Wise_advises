import express from 'express';
import { authenticate } from '../middleware/auth.js';
import { EcommerceService } from '../services/ecommerceService.js';
import DataSource from '../models/DataSource.js';
import NodeCache from 'node-cache';

const router = express.Router();
const statsCache = new NodeCache({ stdTTL: 300 }); // 5 minutes

// Get metrics for a specific data source
router.get('/metrics/:dataSourceId', authenticate, async (req, res) => {
  try {
    const { dataSourceId } = req.params;
    const { start, end } = req.query;
    const cacheKey = `${req.user.id}:${dataSourceId}:${start}:${end}`;
    const cached = statsCache.get(cacheKey);
    if (cached) {
      return res.json(cached);
    }
    
    // Verify the data source belongs to the user
    const dataSource = await DataSource.findOne({
      _id: dataSourceId,
      user: req.user.id,
      isActive: true,
      status: 'connected'
    });
    
    if (!dataSource) {
      return res.status(404).json({ message: 'Data source not found or not accessible' });
    }
    
    // Only support ecommerce platforms for now
    if (!['shopify', 'bigcommerce'].includes(dataSource.type)) {
      return res.status(400).json({ message: 'Data source type not supported for metrics' });
    }
    
    // Use synced data by default for better performance  
    console.log(`📊 Fetching metrics for ${dataSource.type} - preferring synced data`);
    const { orders, products, customers } = await EcommerceService.fetchData(
      req.user.id, 
      dataSource.type, 
      start, 
      end, 
      true // preferSync = true
    );
    
    const metrics = EcommerceService.calculateMetrics(orders, products, customers, dataSource.type);
    
    const result = {
      dataSource: {
        id: dataSource._id,
        name: dataSource.name,
        type: dataSource.type
      },
      metrics,
      dateRange: { start, end },
      recordCount: orders.length,
      meta: {
        total_orders: orders.length,
        total_products: products.length,
        total_customers: customers.length
      }
    };
    
    statsCache.set(cacheKey, result);
    res.json(result);
    
  } catch (error) {
    console.error('Error fetching ecommerce metrics:', error);
    res.status(500).json({ 
      message: 'Failed to fetch metrics',
      error: error.message 
    });
  }
});

// Get comprehensive data for a specific data source
router.get('/data/:dataSourceId', authenticate, async (req, res) => {
  try {
    const { dataSourceId } = req.params;
    const { start_date, end_date } = req.query;
    
    // Verify the data source belongs to the user
    const dataSource = await DataSource.findOne({
      _id: dataSourceId,
      user: req.user.id,
      isActive: true,
      status: 'connected'
    });
    
    if (!dataSource) {
      return res.status(404).json({ message: 'Data source not found or not accessible' });
    }
    
    // Only support ecommerce platforms for now
    if (!['shopify', 'bigcommerce'].includes(dataSource.type)) {
      return res.status(400).json({ message: 'Data source type not supported for comprehensive data' });
    }
    
    // Use synced data by default for better performance
    console.log(`📊 Fetching data for ${dataSource.type} - preferring synced data`);
    const { orders, products, customers } = await EcommerceService.fetchData(
      req.user.id, 
      dataSource.type, 
      start_date, 
      end_date,
      true // Prefer synced data
    );
    
    // Calculate additional analytics
    const metrics = EcommerceService.calculateMetrics(orders, products, customers, dataSource.type);
    
    // Sales by product
    const salesByProduct = {};
    orders.forEach(order => {
      const lineItems = dataSource.type === 'shopify' ? order.line_items : order.products?.resource?.data || [];
      if (lineItems) {
        lineItems.forEach(item => {
          const productName = item.title || item.name || 'Unknown Product';
          const itemTotal = parseFloat(item.price || 0) * parseInt(item.quantity || 1);
          salesByProduct[productName] = (salesByProduct[productName] || 0) + itemTotal;
        });
      }
    });
    
    // Customer metrics
    const customerEmails = {};
    orders.forEach(order => {
      const email = dataSource.type === 'shopify' ? order.email : order.billing_address?.email;
      if (email) {
        customerEmails[email] = (customerEmails[email] || 0) + 1;
      }
    });
    
    const returningCustomers = Object.values(customerEmails).filter(count => count > 1).length;
    const totalCustomersWithOrders = Object.keys(customerEmails).length;
    const returningCustomerRate = totalCustomersWithOrders > 0 ? 
      (returningCustomers / totalCustomersWithOrders) * 100 : 0;
    
    const responseData = {
      dataSource: {
        id: dataSource._id,
        name: dataSource.name,
        type: dataSource.type
      },
      data: {
        metrics: {
          ...metrics,
          returning_customer_rate: returningCustomerRate
        },
        sales_by_product: salesByProduct,
        orders_summary: {
          count: orders.length,
          fulfilled: orders.filter(order => 
            dataSource.type === 'shopify' ? order.fulfillment_status === 'fulfilled' :
            order.status_id === 2 // BigCommerce shipped status
          ).length
        }
      },
      raw_data: {
        orders: orders.slice(0, 100), // Limit for performance
        products: products.slice(0, 100),
        customers: customers.slice(0, 100)
      },
      meta: {
        total_orders: orders.length,
        total_products: products.length,
        total_customers: customers.length,
        date_range: { start_date, end_date }
      }
    };
    
    res.json(responseData);
    
  } catch (error) {
    console.error('Error fetching ecommerce data:', error);
    res.status(500).json({ 
      message: 'Failed to fetch data',
      error: error.message 
    });
  }
});

// Get available ecommerce data sources for the user
router.get('/sources', authenticate, async (req, res) => {
  try {
    const dataSources = await DataSource.find({
      user: req.user.id,
      type: { $in: ['shopify', 'bigcommerce'] },
      isActive: true,
      status: 'connected'
    }).select('_id name type status metadata.lastSyncAt');
    
    res.json(dataSources);
  } catch (error) {
    console.error('Error fetching ecommerce sources:', error);
    res.status(500).json({ message: 'Failed to fetch data sources' });
  }
});

export default router; 