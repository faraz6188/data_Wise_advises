import React, { useState, useEffect } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import FileUploader from "@/components/upload/FileUploader";
import { SyncStatus } from "@/components/sync/SyncStatus";
import { AlertCircle, CheckCircle, Clock, XCircle, Plus, Settings, Trash2, Eye, EyeOff } from "lucide-react";
import axios from "axios";

interface DataSource {
  _id: string;
  name: string;
  type: string;
  status: 'connected' | 'disconnected' | 'error' | 'pending';
  credentials: any;
  settings: {
    syncFrequency: string;
    autoSync: boolean;
    dataTypes: string[];
  };
  metadata: {
    lastSyncAt?: string;
    lastSyncError?: string;
    totalRecords?: number;
  };
  createdAt: string;
  updatedAt: string;
}

interface FormField {
  name: string;
  label: string;
  type: string;
  placeholder: string;
  required: boolean;
  options?: string[];
}

const dataSourceTypes = [
  {
    type: 'shopify',
    name: 'Shopify',
    description: 'Ecommerce platform',
    icon: '🛍️',
    color: 'bg-green-100 text-green-800',
    features: ['Orders', 'Products', 'Customers', 'Analytics']
  },
  {
    type: 'bigcommerce',
    name: 'BigCommerce',
    description: 'Ecommerce platform',
    icon: '🏪',
    color: 'bg-blue-100 text-blue-800',
    features: ['Orders', 'Products', 'Customers', 'Analytics']
  },
  {
    type: 'google_analytics',
    name: 'Google Analytics',
    description: 'Web analytics platform',
    icon: '📊',
    color: 'bg-blue-100 text-blue-800',
    features: ['Traffic', 'Conversions', 'Demographics', 'Behavior']
  },
  {
    type: 'meta_ads',
    name: 'Meta Ads',
    description: 'Social media advertising',
    icon: '📱',
    color: 'bg-purple-100 text-purple-800',
    features: ['Campaigns', 'Ad Performance', 'Audiences', 'Insights']
  },
  {
    type: 'klaviyo',
    name: 'Klaviyo',
    description: 'Email marketing platform',
    icon: '📧',
    color: 'bg-orange-100 text-orange-800',
    features: ['Email Campaigns', 'Flows', 'Customer Profiles', 'Segmentation']
  },
  {
    type: 'custom',
    name: 'Custom API',
    description: 'Connect any custom data source',
    icon: '🔗',
    color: 'bg-gray-100 text-gray-800',
    features: ['Custom Endpoints', 'Flexible Auth', 'Any Data Type']
  }
];

const SourcesPage = () => {
  const [dataSources, setDataSources] = useState<DataSource[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<string | null>(null);
  const [formFields, setFormFields] = useState<FormField[]>([]);
  const [formData, setFormData] = useState<any>({});
  const [editingSource, setEditingSource] = useState<DataSource | null>(null);
  const [error, setError] = useState<string>("");
  const [success, setSuccess] = useState<string>("");
  const [showPasswords, setShowPasswords] = useState<{[key: string]: boolean}>({});
  const [testingConnection, setTestingConnection] = useState<string | null>(null);

  // Fetch data sources on component mount
  useEffect(() => {
    fetchDataSources();
  }, []);

  const fetchDataSources = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/data-sources');
      setDataSources(response.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch data sources');
    } finally {
      setLoading(false);
    }
  };

  const openModal = async (type: string, source?: DataSource) => {
    try {
      setError("");
      setSuccess("");
      setEditingSource(source || null);
      
      // Fetch required fields for this data source type
      const response = await axios.get(`/api/data-sources/fields/${type}`);
      setFormFields(response.data.fields);
      
      // Pre-fill form data if editing
      if (source) {
        const credentials = { ...source.credentials };
        // Don't pre-fill password fields for security
        Object.keys(credentials).forEach(key => {
          if (key.toLowerCase().includes('token') || key.toLowerCase().includes('secret') || key.toLowerCase().includes('key')) {
            credentials[key] = '';
          }
        });
        setFormData({
          name: source.name,
          ...credentials,
          syncFrequency: source.settings.syncFrequency,
          autoSync: source.settings.autoSync,
          dataTypes: source.settings.dataTypes
        });
      } else {
        setFormData({
          name: `${dataSourceTypes.find(ds => ds.type === type)?.name} Connection`,
          syncFrequency: 'daily',
          autoSync: true,
          dataTypes: []
        });
      }
      
      setModal(type);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to load form fields');
    }
  };

  const handleSubmit = async () => {
    try {
      setError("");
      setSuccess("");
      
      const payload = {
        name: formData.name,
        type: modal,
        credentials: {},
        settings: {
          syncFrequency: formData.syncFrequency,
          autoSync: formData.autoSync,
          dataTypes: formData.dataTypes || []
        }
      };
      
      // Extract credentials from form data
      formFields.forEach(field => {
        if (formData[field.name] && field.name !== 'name') {
          payload.credentials[field.name] = formData[field.name];
        }
      });
      
      if (editingSource) {
        // Update existing data source
        await axios.put(`/api/data-sources/${editingSource._id}`, payload);
        setSuccess("Data source updated successfully!");
      } else {
        // Create new data source
        await axios.post('/api/data-sources', payload);
        setSuccess("Data source connected successfully!");
      }
      
      // Refresh data sources list
      await fetchDataSources();
      
      setTimeout(() => {
        setModal(null);
        setFormData({});
        setEditingSource(null);
      }, 1500);
      
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to save data source');
    }
  };

  const testConnection = async (sourceId: string) => {
    try {
      setTestingConnection(sourceId);
      const response = await axios.post(`/api/data-sources/${sourceId}/test`);
      
      if (response.data.success) {
        setSuccess("Connection test successful!");
      } else {
        setError(`Connection test failed: ${response.data.lastSyncError || 'Unknown error'}`);
      }
      
      // Refresh the data source to get updated status
      await fetchDataSources();
      
    } catch (err: any) {
      setError(err.response?.data?.message || 'Connection test failed');
    } finally {
      setTestingConnection(null);
    }
  };

  const deleteDataSource = async (sourceId: string) => {
    if (!confirm('Are you sure you want to delete this data source?')) {
      return;
    }
    
    try {
      await axios.delete(`/api/data-sources/${sourceId}`);
      setSuccess("Data source deleted successfully!");
      await fetchDataSources();
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to delete data source');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'error': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'pending': return <Clock className="w-4 h-4 text-yellow-500" />;
      default: return <AlertCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'bg-green-100 text-green-800';
      case 'error': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const connectedSources = dataSources.filter(source => source.status === 'connected');
  const totalSources = dataSourceTypes.length;

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Data Sources</h1>
          <p className="text-muted-foreground">
            Connect and manage your business data sources ({connectedSources.length}/{totalSources} connected)
          </p>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="data-sources">
          <TabsList>
            <TabsTrigger value="data-sources">Data Sources</TabsTrigger>
            <TabsTrigger value="connected">Connected Sources ({connectedSources.length})</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
          </TabsList>
          
          <TabsContent value="data-sources" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {dataSourceTypes.map((sourceType) => {
                const connectedSource = dataSources.find(ds => ds.type === sourceType.type);
                const isConnected = connectedSource?.status === 'connected';
                
                return (
                  <Card key={sourceType.type} className={isConnected ? "border-green-200" : ""}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <span className="text-2xl">{sourceType.icon}</span>
                          <div>
                            <CardTitle>{sourceType.name}</CardTitle>
                            <CardDescription>{sourceType.description}</CardDescription>
                          </div>
                        </div>
                        {connectedSource && (
                          <div className="flex items-center space-x-1">
                            {getStatusIcon(connectedSource.status)}
                            <Badge className={getStatusColor(connectedSource.status)}>
                              {connectedSource.status}
                            </Badge>
                          </div>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex flex-wrap gap-1">
                        {sourceType.features.map((feature) => (
                          <Badge key={feature} variant="outline" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                      
                      {connectedSource && (
                        <div className="text-sm text-muted-foreground space-y-1">
                          <div>Name: {connectedSource.name}</div>
                          {connectedSource.metadata.lastSyncAt && (
                            <div>Last sync: {new Date(connectedSource.metadata.lastSyncAt).toLocaleString()}</div>
                          )}
                          {connectedSource.metadata.totalRecords && (
                            <div>Records: {connectedSource.metadata.totalRecords.toLocaleString()}</div>
                          )}
                        </div>
                      )}
                      
                      <div className="flex space-x-2">
                        <Button 
                          className="flex-1" 
                          variant={isConnected ? "secondary" : "default"} 
                          onClick={() => openModal(sourceType.type, connectedSource)}
                        >
                          {isConnected ? "Update" : "Connect"}
                        </Button>
                        
                        {connectedSource && (
                          <>
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => testConnection(connectedSource._id)}
                              disabled={testingConnection === connectedSource._id}
                              title="Test connection"
                            >
                              {testingConnection === connectedSource._id ? (
                                <Clock className="w-4 h-4 animate-spin" />
                              ) : (
                                <Settings className="w-4 h-4" />
                              )}
                            </Button>
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => deleteDataSource(connectedSource._id)}
                              title="Delete connection"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
          
          <TabsContent value="connected" className="space-y-6">
            {connectedSources.length === 0 ? (
              <div className="text-center py-12">
                <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Connected Data Sources</h3>
                <p className="text-muted-foreground mb-4">
                  Connect your first data source to start analyzing your business data.
                </p>
                <Button onClick={() => setModal('shopify')}>
                  <Plus className="w-4 h-4 mr-2" />
                  Connect Shopify
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {connectedSources.map((source) => {
                  const sourceType = dataSourceTypes.find(ds => ds.type === source.type);
                  return (
                    <Card key={source._id}>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <span className="text-2xl">{sourceType?.icon}</span>
                            <div>
                              <CardTitle>{source.name}</CardTitle>
                              <CardDescription>{sourceType?.name}</CardDescription>
                            </div>
                          </div>
                          <Badge className={getStatusColor(source.status)}>
                            {source.status}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="text-sm space-y-2">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Sync Frequency:</span>
                            <span className="capitalize">{source.settings.syncFrequency}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Auto Sync:</span>
                            <span>{source.settings.autoSync ? 'Enabled' : 'Disabled'}</span>
                          </div>
                          {source.metadata.lastSyncAt && (
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Last Sync:</span>
                              <span>{new Date(source.metadata.lastSyncAt).toLocaleDateString()}</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="flex space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => openModal(source.type, source)}
                          >
                            <Settings className="w-4 h-4 mr-2" />
                            Configure
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => testConnection(source._id)}
                            disabled={testingConnection === source._id}
                          >
                            {testingConnection === source._id ? (
                              <Clock className="w-4 h-4 mr-2 animate-spin" />
                            ) : (
                              <CheckCircle className="w-4 h-4 mr-2" />
                            )}
                            Test
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}

            {/* Sync Status Section */}
            {connectedSources.length > 0 && (
              <div className="mt-8">
                <h3 className="text-lg font-semibold mb-4">Data Synchronization</h3>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {connectedSources.map((source) => (
                    <SyncStatus
                      key={`sync-${source._id}`}
                      dataSource={source}
                      onSyncComplete={fetchDataSources}
                    />
                  ))}
                </div>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="documents">
            <Card>
              <CardHeader>
                <CardTitle>Upload Business Documents</CardTitle>
                <CardDescription>
                  Upload documents, spreadsheets, PDFs, or data exports to supplement your connected data sources
                </CardDescription>
              </CardHeader>
              <CardContent>
                <FileUploader />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Connection Modal */}
        {modal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold">
                  {editingSource ? 'Update' : 'Connect'} {dataSourceTypes.find(ds => ds.type === modal)?.name}
                </h2>
                <Button variant="ghost" onClick={() => setModal(null)}>×</Button>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Connection Name</Label>
                  <Input
                    id="name"
                    value={formData.name || ''}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Enter a name for this connection"
                  />
                </div>

                <Separator />

                {/* Dynamic form fields based on data source type */}
                {formFields.map((field) => (
                  <div key={field.name}>
                    <Label htmlFor={field.name}>
                      {field.label} {field.required && <span className="text-red-500">*</span>}
                    </Label>
                    {field.type === 'select' ? (
                      <Select
                        value={formData[field.name] || ''}
                        onValueChange={(value) => setFormData({...formData, [field.name]: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder={field.placeholder} />
                        </SelectTrigger>
                        <SelectContent>
                          {field.options?.map((option) => (
                            <SelectItem key={option} value={option}>
                              {option.replace('_', ' ').toUpperCase()}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <div className="relative">
                        <Input
                          id={field.name}
                          type={field.type === 'password' && !showPasswords[field.name] ? 'password' : 'text'}
                          value={formData[field.name] || ''}
                          onChange={(e) => setFormData({...formData, [field.name]: e.target.value})}
                          placeholder={field.placeholder}
                        />
                        {field.type === 'password' && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="absolute right-0 top-0 h-full px-3"
                            onClick={() => setShowPasswords({
                              ...showPasswords,
                              [field.name]: !showPasswords[field.name]
                            })}
                          >
                            {showPasswords[field.name] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                ))}

                <Separator />

                {/* Settings */}
                <div className="space-y-4">
                  <h3 className="font-medium">Sync Settings</h3>
                  
                  <div>
                    <Label htmlFor="syncFrequency">Sync Frequency</Label>
                    <Select
                      value={formData.syncFrequency || 'daily'}
                      onValueChange={(value) => setFormData({...formData, syncFrequency: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="real_time">Real Time</SelectItem>
                        <SelectItem value="hourly">Hourly</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      id="autoSync"
                      checked={formData.autoSync !== false}
                      onCheckedChange={(checked) => setFormData({...formData, autoSync: checked})}
                    />
                    <Label htmlFor="autoSync">Enable automatic synchronization</Label>
                  </div>
                </div>
              </div>

              {error && (
                <Alert variant="destructive" className="mt-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {success && (
                <Alert className="mt-4">
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>{success}</AlertDescription>
                </Alert>
              )}

              <div className="flex gap-2 mt-6">
                <Button onClick={handleSubmit} className="flex-1">
                  {editingSource ? 'Update Connection' : 'Connect Data Source'}
                </Button>
                <Button variant="outline" onClick={() => setModal(null)} className="flex-1">
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default SourcesPage;
