import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageSquare } from "lucide-react";
import { geminiService } from "@/lib/gemini";

interface AiInsightCardProps {
  stats: {
    total_revenue?: number;
    net_sales?: number;
    total_discounts?: number;
    total_shipping?: number;
    total_taxes?: number;
    average_order_value?: number;
    total_orders?: number;
    unique_customers?: number;
  };
  dataSource?: { name: string; type: string };
  dateRange?: { start: string; end: string };
}

const AI_PROMPT_TEMPLATE = `You are an expert AI Business Analyst.

You are provided with key business metrics for a business using {sourceName} ({sourceType}) for the period {dateRange}. Your goal is to:
- Give a concise, actionable, and executive-level summary.
- Highlight the most important trends, risks, and opportunities.
- Use clear headings (not markdown bold or asterisks), just plain text.
- Add a "Key Opportunities" or "Risks" section if relevant.
- Use this format:

Performance Snapshot:
- Total Sales: ...
- Net Sales: ...
- Discounts: ...
- Shipping: ...
- Taxes: ...
- AOV: ...
- Total Orders: ...
- Total Customers: ...

Insight:
<one or two sentences with the main story>

Recommendation:
<one or two specific next steps>

{extraSection}

Here are the latest metrics:
{metrics}
`;

const AiInsightCard = ({ stats, dataSource, dateRange }: AiInsightCardProps) => {
  const [summary, setSummary] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const dashboardMetrics = `
Total Sales: $${stats.total_revenue?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
Net Sales: $${stats.net_sales?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
Discounts: $${stats.total_discounts?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
Shipping: $${stats.total_shipping?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
Taxes: $${stats.total_taxes?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
AOV: $${stats.average_order_value?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
Total Orders: ${stats.total_orders}
Total Customers: ${stats.unique_customers}
`;

  const sourceName = dataSource?.name || "Unknown Source";
  const sourceType = dataSource?.type || "Unknown Type";
  const dateRangeStr = dateRange ? `${dateRange.start} to ${dateRange.end}` : "(date range not specified)";
  const extraSection = "Add a section called 'Key Opportunities' or 'Risks' if you see any.";

  const handleQuickAnalysis = async () => {
    setLoading(true);
    setSummary(null);
    try {
      const prompt = AI_PROMPT_TEMPLATE
        .replace("{sourceName}", sourceName)
        .replace("{sourceType}", sourceType)
        .replace("{dateRange}", dateRangeStr)
        .replace("{metrics}", dashboardMetrics)
        .replace("{extraSection}", extraSection);
      const aiResponse = await geminiService.sendMessage(prompt);
      setSummary(aiResponse);
    } catch (err) {
      setSummary("Sorry, I couldn't generate a summary at this time.");
    }
    setLoading(false);
  };
  
  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-bizoracle-blue" /> AI Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="pb-6">
        <div className="space-y-4">
          <p className="text-sm">
            Click analyze to get AI insights about your:
          </p>
          <ul className="space-y-2">
            <li className="flex gap-2 items-start">
              <span className="bg-bizoracle-blue text-white rounded-full h-5 w-5 flex items-center justify-center shrink-0 text-xs">•</span>
              <span className="text-sm">Store data for the selected date range (MTD)</span>
            </li>
          </ul>
          <div className="flex gap-4 mt-6">
            <Button 
              variant="default" 
              size="sm" 
              className="bg-bizoracle-blue hover:bg-bizoracle-blue/90"
              onClick={handleQuickAnalysis}
              disabled={loading}
            >
              {loading ? "Analyzing..." : "Quick Analysis"}
            </Button>
          </div>
          {summary && (
            <div className="mt-4 p-4 bg-blue-50 border border-blue-100 rounded text-sm">
              <div className="mt-2 whitespace-pre-line">{summary}</div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default AiInsightCard;
