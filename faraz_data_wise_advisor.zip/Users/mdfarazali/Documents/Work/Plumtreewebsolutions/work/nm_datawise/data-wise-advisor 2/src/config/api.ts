export const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

export const API_ENDPOINTS = {
  upload: `${API_BASE_URL}/upload`,
  auth: `${API_BASE_URL}/auth`,
  dataSources: `${API_BASE_URL}/data-sources`,
  sync: `${API_BASE_URL}/sync`,
  ecommerce: `${API_BASE_URL}/ecommerce`,
};
