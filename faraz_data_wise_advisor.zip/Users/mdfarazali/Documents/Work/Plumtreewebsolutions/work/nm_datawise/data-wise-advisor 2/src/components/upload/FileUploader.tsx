import React, { useState, useRef } from "react";
import { Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { API_ENDPOINTS } from "@/config/api";

interface FileUploaderProps {
  compact?: boolean;
  onAnalysisComplete?: (analysis: string, filename: string) => void;
  onFileUpload?: (file: File) => void;
}

const FileUploader = ({ compact = false, onAnalysisComplete, onFileUpload }: FileUploaderProps) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };
  
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFileUpload(files);
  };
  
  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    console.log('File input change event triggered');
    const files = e.target.files;
    if (!files || files.length === 0) {
      console.log('No files selected');
      return;
    }
    
    console.log('Files selected:', Array.from(files).map(f => f.name));
    handleFileUpload(Array.from(files));
    
    // Reset the input value to allow selecting the same file again
    e.target.value = '';
  };
  
  const handleFileUpload = async (files: File[]) => {
    if (files.length === 0) return;
    
    setIsUploading(true);
    
    // Check file types and sizes on frontend for immediate feedback
    const validFileTypes = [
      'text/csv', 
      'application/pdf', 
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-excel',
      'application/json', 
      'text/plain'
    ];
    const maxSizeMB = 50;
    
    const invalidFiles = files.filter(file => {
      return !validFileTypes.includes(file.type) || file.size > maxSizeMB * 1024 * 1024;
    });
    
    if (invalidFiles.length > 0) {
      toast({
        title: "Invalid files",
        description: `${invalidFiles.length} files were rejected due to invalid format or size exceeding ${maxSizeMB}MB`,
        variant: "destructive"
      });
      setIsUploading(false);
      return;
    }
    
    try {
      // Create FormData for file upload
      const formData = new FormData();
      files.forEach(file => {
        formData.append('files', file);
      });
      
      // Get auth token
      const token = localStorage.getItem('token');
      if (!token) {
        toast({
          title: "Authentication Error",
          description: "Please log in to upload files.",
          variant: "destructive"
        });
        setIsUploading(false);
        return;
      }
      
      console.log('Attempting upload with token:', token);
      
      console.log('Uploading to:', API_ENDPOINTS.upload);
      
      // Upload to backend
      const response = await fetch(API_ENDPOINTS.upload, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/json'
        },
        credentials: 'include',
        body: formData
      });

      console.log('Upload response status:', response.status);
      const responseText = await response.text();
      console.log('Response text:', responseText);

      if (!response.ok) {
        throw new Error(`Upload failed: ${response.status} ${responseText}`);
      }
      
      const result = responseText ? JSON.parse(responseText) : {};      // Process results
      result.files.forEach((fileResult: any) => {
        if (onAnalysisComplete && fileResult.analysis) {
          onAnalysisComplete(fileResult.analysis, fileResult.filename);
        }
        if (onFileUpload) {
          // Create a mock file object for the callback
          const mockFile = new File([''], fileResult.filename, { 
            type: fileResult.mimetype 
          });
          onFileUpload(mockFile);
        }
      });
      
      toast({
        title: "Upload successful",
        description: result.message,
      });
      
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload files. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      
      // Reset file input
      const fileInput = document.getElementById('file-input') as HTMLInputElement;
      if (fileInput) {
        fileInput.value = '';
      }
    }
  };
  
  const openFileBrowser = (e: React.MouseEvent) => {
    console.log('Open file browser clicked');
    e.preventDefault();
    e.stopPropagation();
    if (fileInputRef.current) {
      console.log('Triggering file input click');
      fileInputRef.current.click();
    } else {
      console.log('File input ref is null');
    }
  };
  
  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={cn(
        "border-2 border-dashed rounded-lg flex flex-col items-center justify-center w-full transition-colors cursor-pointer",
        isDragOver ? "border-bizoracle-blue bg-blue-50" : "border-gray-300",
        isUploading ? "opacity-70 cursor-not-allowed" : "opacity-100",
        compact ? "p-4" : "p-10"
      )}
    >
      <input 
        ref={fileInputRef}
        type="file" 
        multiple 
        className="hidden" 
        onChange={handleFileInput} 
        accept=".csv,.pdf,.xlsx,.xls,.json,.txt"
        disabled={isUploading}
      />
      
      <Upload className={cn(
        "text-gray-400",
        compact ? "h-10 w-10 mb-2" : "h-16 w-16 mb-4"
      )} />
      
      <div className="text-center">
        <p className={cn(
          "font-medium",
          compact ? "text-sm" : "text-base"
        )}>
          {isUploading ? "Uploading files..." : "Drag files here or click to browse"}
        </p>
        <p className={cn(
          "text-muted-foreground",
          compact ? "text-xs mt-1" : "text-sm mt-2"
        )}>
          Supports CSV, PDF, XLSX, JSON, and TXT files (up to 50MB)
        </p>
        {isUploading && (
          <div className="mt-3 flex items-center justify-center">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-bizoracle-blue"></div>
          </div>
        )}
      </div>
      
      {!compact && !isUploading && (
        <Button 
          type="button"
          onClick={(e) => {
            e.stopPropagation(); // Stop event from bubbling up
            console.log('Button clicked');
            if (fileInputRef.current) {
              fileInputRef.current.click();
            }
          }}
          className="mt-6"
        >
          Select Files
        </Button>
      )}
    </div>
  );
};

export default FileUploader;
